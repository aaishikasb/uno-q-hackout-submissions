
from robot_client import MiniAutoRobot

robot = MiniAutoRobot()

print("Sensors:", robot.read_sensors())

if robot.is_running():
    print("Testing forward movement")
    robot.drive(
        command="forward",
        speed=200,
        ms=500,
    )
    print("Motor test completed")
else:
    print("Press BOOT to enable the robot")
