from collections import deque
from statistics import median
import time


class GoalFollower:
    """Bounded search, approach, presumed capture, goal alignment, push."""

    def __init__(self, ball_confidence=0.50, goal_confidence=0.40,
                 smoothing_window=3, push_duration=5.0,
                 ball_lost_timeout=1.5):
        self.ball_confidence = ball_confidence
        self.goal_confidence = goal_confidence
        self.history = deque(maxlen=smoothing_window)
        self.push_duration = push_duration
        self.ball_lost_timeout = ball_lost_timeout
        self.reset()

    def reset(self):
        self.history.clear()
        self.state = 'SEARCH_BALL'
        self.last_ball = None
        self.last_ball_time = None
        self.approach_pulses = 0
        self.last_goal_center = None
        self.last_goal_time = None
        self.capture_time = None
        self.push_start = None
        self.search_goal_start = None
        self.goal_aligned_frames = 0
        self.search_direction = 'TURN_LEFT'
        self.search_steps = 0
        self.complete = False

    def decide(self, detections):
        now = time.monotonic()
        balls = [d for d in detections if d.get('label') == 'soccerball'
                 and d.get('confidence', 0) >= self.ball_confidence]
        goals = [d for d in detections if d.get('label') == 'goal'
                 and d.get('confidence', 0) >= self.goal_confidence]
        info = {'state': self.state, 'ball_count': len(balls), 'goal_count': len(goals)}

        # Only two separated posts provide a usable goal center.
        if len(goals) >= 2:
            gs = sorted(goals, key=lambda d: d['center_normalized'][0])
            left = float(gs[0]['center_normalized'][0])
            right = float(gs[-1]['center_normalized'][0])
            if right - left >= 0.08:
                self.last_goal_center = (left + right) / 2
                self.last_goal_time = now
                info['goal_center'] = round(self.last_goal_center, 3)

        if self.complete:
            info['state'] = 'PUSH_COMPLETE'
            return 'STOP', info

        # During presumed capture, ignore ball detections: ball may be obscured
        # and intermittent detections must not reset the committed maneuver.
        if self.state in ('BALL_CAPTURED', 'SEARCH_GOAL', 'ALIGN_GOAL', 'PUSH_GOAL'):
            if self.capture_time is not None and now - self.capture_time > 15.0:
                self.complete = True
                info['state'] = 'CAPTURE_TIMEOUT'
                return 'STOP', info

            if self.state == 'PUSH_GOAL':
                if now - self.push_start >= self.push_duration:
                    self.complete = True
                    info['state'] = 'PUSH_COMPLETE'
                    return 'STOP', info
                info['state'] = 'PUSH_GOAL'
                info['remaining_s'] = round(self.push_duration - (now - self.push_start), 1)
                return 'FORWARD', info

            # Goal is currently visible or was seen very recently.
            goal_fresh = (self.last_goal_center is not None
                          and self.last_goal_time is not None
                          and now - self.last_goal_time < 1.2)
            if goal_fresh:
                err = self.last_goal_center - 0.5
                info['goal_error'] = round(err, 3)
                if abs(err) <= 0.13:
                    self.goal_aligned_frames += 1
                    if self.goal_aligned_frames >= 2:
                        self.state = 'PUSH_GOAL'
                        self.push_start = now
                        info['state'] = 'PUSH_GOAL'
                        return 'FORWARD', info
                    self.state = 'ALIGN_GOAL'
                    info['state'] = 'ALIGN_GOAL_VERIFY'
                    return 'STOP', info
                self.goal_aligned_frames = 0
                self.state = 'ALIGN_GOAL'
                info['state'] = 'ALIGN_GOAL'
                return ('TURN_LEFT' if err < 0 else 'TURN_RIGHT'), info

            self.state = 'SEARCH_GOAL'
            self.goal_aligned_frames = 0
            if self.search_goal_start is None:
                self.search_goal_start = now
            if now - self.search_goal_start >= 6.0:
                # No goal: do not drive blind indefinitely. Resume ball search.
                self.reset()
                info['state'] = 'GOAL_SEARCH_TIMEOUT'
                return 'STOP', info
            info['state'] = 'SEARCH_GOAL'
            return self._search_turn(), info

        if balls:
            ball = max(balls, key=lambda d: d['confidence'])
            bx = float(ball['center_normalized'][0])
            by = float(ball['center_normalized'][1])
            self.history.append(bx)
            bx = median(self.history)
            self.last_ball = (bx, by)
            self.last_ball_time = now
            info.update(ball_x=round(bx, 3), ball_y=round(by, 3))
            if bx < 0.38:
                self.state = 'ALIGN_BALL'
                self.approach_pulses = 0
                info['state'] = self.state
                return 'TURN_LEFT', info
            if bx > 0.62:
                self.state = 'ALIGN_BALL'
                self.approach_pulses = 0
                info['state'] = self.state
                return 'TURN_RIGHT', info
            self.state = 'APPROACH_BALL'
            self.approach_pulses += 1
            info['state'] = self.state
            info['approach_pulses'] = self.approach_pulses
            return 'FORWARD', info

        # Ball vanished after sustained, centered, close approach.
        if (self.state == 'APPROACH_BALL'
                and self.last_ball is not None
                and self.last_ball_time is not None
                and now - self.last_ball_time <= self.ball_lost_timeout
                and 0.38 <= self.last_ball[0] <= 0.62
                and self.last_ball[1] >= 0.65
                and self.approach_pulses >= 2):
            self.state = 'BALL_CAPTURED'
            self.capture_time = now
            self.search_goal_start = now
            info['state'] = 'BALL_CAPTURED'
            info['reason'] = 'close centered ball lost after forward approach'
            # A short forward pulse seats the ball against the bumper.
            return 'FORWARD', info

        self.history.clear()
        self.state = 'SEARCH_BALL'
        self.approach_pulses = 0
        info['state'] = self.state
        return self._search_turn(), info

    def _search_turn(self):
        self.search_steps += 1
        if self.search_steps % 12 == 0:
            self.search_direction = ('TURN_RIGHT' if self.search_direction == 'TURN_LEFT'
                                     else 'TURN_LEFT')
        return self.search_direction


def execute_goal_action(robot, action, speed=150):
    commands = {
        'FORWARD': ('forward', 150),
        'TURN_LEFT': ('rotate_left', 65),
        'TURN_RIGHT': ('rotate_right', 65),
        'BACKWARD': ('backward', 100),
    }
    if action == 'STOP':
        print('[MOTOR] STOP: no new pulse', flush=True)
        return
    if action not in commands:
        raise ValueError(f'Unknown action: {action}')
    command, duration_ms = commands[action]
    motor_speed = min(speed, 100) if action.startswith('TURN') else speed
    print(f'[MOTOR] {action} speed={motor_speed} duration={duration_ms}ms', flush=True)
    robot.drive(command=command, speed=motor_speed, ms=duration_ms)
