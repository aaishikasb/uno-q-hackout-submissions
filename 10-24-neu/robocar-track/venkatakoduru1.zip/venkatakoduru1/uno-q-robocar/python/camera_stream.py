
from urllib.request import urlopen
import time

import cv2
import numpy as np


class CameraStream:
    def __init__(self, url="http://192.168.5.1:81/stream"):
        self.url = url
        self.stream = None
        self.buffer = bytearray()

    def connect(self):
        self.stream = urlopen(self.url, timeout=3)
        print("[CAMERA] Connected", flush=True)

    def read(self):
        if self.stream is None:
            raise RuntimeError("Camera not connected")

        deadline = time.monotonic() + 3

        while time.monotonic() < deadline:
            start = self.buffer.find(b"\xff\xd8")

            if start >= 0:
                end = self.buffer.find(b"\xff\xd9", start + 2)

                if end >= 0:
                    jpeg = bytes(self.buffer[start:end + 2])
                    del self.buffer[:end + 2]

                    frame = cv2.imdecode(
                        np.frombuffer(jpeg, dtype=np.uint8),
                        cv2.IMREAD_COLOR
                    )

                    if frame is not None:
                        return frame

            chunk = self.stream.read(1024)

            if not chunk:
                raise RuntimeError("Camera stream disconnected")

            self.buffer.extend(chunk)

            if len(self.buffer) > 2_000_000:
                raise RuntimeError("MJPEG buffer exceeded limit")

        raise TimeoutError("No complete frame received")

    def close(self):
        if self.stream is not None:
            self.stream.close()
            self.stream = None
