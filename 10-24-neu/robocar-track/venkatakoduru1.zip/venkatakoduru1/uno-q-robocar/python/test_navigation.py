
# test_navigation.py
import time

from geometry import Geometry, Observation, Point
from controls import Controller


geometry = Geometry(width=320, height=240)
controller = Controller()


def run_test(name, ball, cones, age=0.1):
    observation = Observation(
        ball=ball,
        cones=cones,
        timestamp=time.monotonic() - age,
    )

    result = geometry.calculate(observation)

    observation_age = (
        time.monotonic() - observation.timestamp
    )

    action = controller.decide(
        result,
        observation_age,
    )

    print(f"\n--- {name} ---")
    print("Ball visible:", result.ball_visible)
    print("Goal visible:", result.goal_visible)
    print("Ball error:", result.ball_error)
    print("Goal error:", result.goal_error)
    print("Ball-goal offset:", result.ball_goal_offset)
    print("Action:", action.direction)
    print("Speed:", action.speed)
    print("Duration:", action.duration_ms)
    print("Reason:", action.reason)

    return action


def main():
    cones = [
        Point(80, 90),
        Point(240, 90),
    ]

    cases = [
        (
            "Ball centered",
            Point(160, 180),
            cones,
            0.1,
            "forward",
        ),
        (
            "Ball left",
            Point(60, 180),
            cones,
            0.1,
            "rotate_left",
        ),
        (
            "Ball right",
            Point(260, 180),
            cones,
            0.1,
            "rotate_right",
        ),
        (
            "Ball missing",
            None,
            cones,
            0.1,
            "stop",
        ),
        (
            "Stale frame",
            Point(160, 180),
            cones,
            2.0,
            "stop",
        ),
        (
            "Goal missing, ball visible",
            Point(160, 180),
            [],
            0.1,
            "forward",
        ),
    ]

    for name, ball, cones, age, expected in cases:
        action = run_test(name, ball, cones, age)
        assert action.direction == expected, (
            f"{name}: expected {expected}, "
            f"got {action.direction}"
        )

    print("\nAll simulated navigation tests passed.")


if __name__ == "__main__":
    main()
