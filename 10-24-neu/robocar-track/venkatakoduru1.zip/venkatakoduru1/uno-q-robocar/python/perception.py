
import argparse
import json
import os
import time
from pathlib import Path

import cv2
from edge_impulse_linux.image import ImageImpulseRunner

from controls import GoalFollower, execute_goal_action
from robot_client import MiniAutoRobot, ProgramStopped


BASE = Path(__file__).resolve().parent

MODEL_PATH = (
    BASE / "uno-q-hackout-2-linux-aarch64-v1-impulse-#1.eim"
)

CAMERA_URL = "http://192.168.5.1:81/stream"

CONFIDENCE_THRESHOLD = 0.40
MOTOR_SPEED = 150
MIN_FORWARD_DISTANCE_MM = 250
MAX_FRAMES = 100000


def open_camera():
    camera = cv2.VideoCapture(CAMERA_URL)

    if not camera.isOpened():
        raise RuntimeError(
            "Cannot open camera stream. Check Wi-Fi."
        )

    camera.set(cv2.CAP_PROP_BUFFERSIZE, 1)
    return camera


def run_perception(max_frames=MAX_FRAMES, show=False):

    if not MODEL_PATH.is_file():
        raise FileNotFoundError(
            f"Model not found: {MODEL_PATH}"
        )

    os.chmod(
        MODEL_PATH,
        MODEL_PATH.stat().st_mode | 0o111
    )

    follower = GoalFollower(
        ball_confidence=0.50,
        goal_confidence=0.40,
        smoothing_window=3,
        push_duration=5.0,
    )

    robot = MiniAutoRobot()

    print(
        "[INFO] Starting navigation. "
        "Press BOOT to enable.",
        flush=True,
    )

    with ImageImpulseRunner(str(MODEL_PATH)) as runner:

        runner.init()

        print(
            "[INFO] FOMO model loaded",
            flush=True,
        )

        camera = open_camera()

        bridge_failures = 0
        was_enabled = False

        try:
            for frame_id in range(max_frames):

                # ----------------------------------
                # MCU / BRIDGE COMMUNICATION
                # ----------------------------------
                try:
                    sensors = robot.read_sensors()
                    bridge_failures = 0

                except Exception as exc:
                    bridge_failures += 1

                    print(
                        f"[BRIDGE ERROR] {exc} "
                        f"({bridge_failures}/3)",
                        flush=True,
                    )

                    follower.reset()

                    if bridge_failures >= 3:
                        print(
                            "[ERROR] MCU Bridge unavailable. "
                            "Check sketch.",
                            flush=True,
                        )
                        break

                    time.sleep(2)
                    continue

                # ----------------------------------
                # START / STOP BUTTON
                # ----------------------------------
                enabled = bool(
                    sensors.get("program_enabled", False)
                )

                if not enabled:
                    if was_enabled:
                        print(
                            "[INFO] Disabled: "
                            "resetting navigation",
                            flush=True,
                        )

                    follower.reset()
                    was_enabled = False

                    time.sleep(0.25)
                    continue

                was_enabled = True

                # ----------------------------------
                # CAMERA FRAME
                # ----------------------------------
                success, frame = camera.read()

                if not success or frame is None:
                    print(
                        "[ERROR] Camera unavailable",
                        flush=True,
                    )
                    break

                start = time.monotonic()

                height, width = frame.shape[:2]

                rgb = cv2.cvtColor(
                    frame,
                    cv2.COLOR_BGR2RGB,
                )

                # ----------------------------------
                # EDGE IMPULSE FOMO INFERENCE
                # ----------------------------------
                features, processed = (
                    runner.get_features_from_image(rgb)
                )

                result = runner.classify(features)

                boxes = result.get(
                    "result", {}
                ).get("bounding_boxes", [])

                model_h, model_w = processed.shape[:2]

                detections = []

                for box in boxes:

                    confidence = float(
                        box.get("value", 0)
                    )

                    if confidence < CONFIDENCE_THRESHOLD:
                        continue

                    cx = (
                        float(box["x"])
                        + float(box["width"]) / 2
                    )

                    cy = (
                        float(box["y"])
                        + float(box["height"]) / 2
                    )

                    detections.append({
                        "label": box["label"],
                        "confidence": round(
                            confidence, 3
                        ),
                        "center_normalized": [
                            round(cx / model_w, 4),
                            round(cy / model_h, 4),
                        ],
                        "center_model": [
                            round(cx, 1),
                            round(cy, 1),
                        ],
                    })

                    cv2.circle(
                        processed,
                        (int(cx), int(cy)),
                        5,
                        (0, 255, 0),
                        2,
                    )

                    cv2.putText(
                        processed,
                        f"{box['label']} {confidence:.2f}",
                        (
                            max(0, int(cx) - 25),
                            max(15, int(cy) - 10),
                        ),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.4,
                        (0, 255, 0),
                        1,
                    )

                # ----------------------------------
                # NAVIGATION STATE MACHINE
                # ----------------------------------
                action, nav = follower.decide(
                    detections
                )

                # ----------------------------------
                # ULTRASONIC SAFETY
                # ----------------------------------
                distance = sensors.get(
                    "ultrasonic_mm", -1
                )

                try:
                    distance = int(distance)
                except (TypeError, ValueError):
                    distance = -1

                # Never override the safety gate,
                # including during presumed capture.
                if action == "FORWARD":
                    if (
                        distance <= 0
                        or distance < MIN_FORWARD_DISTANCE_MM
                    ):
                        print(
                            f"[SAFETY] Forward blocked: "
                            f"{distance}mm",
                            flush=True,
                        )

                        action = "STOP"

                        # Do not count a blocked pulse
                        # as a successful approach.
                        if nav.get("state") == "APPROACH_BALL":
                            follower.approach_pulses = max(
                                0,
                                follower.approach_pulses - 1,
                            )

                        if nav.get("state") in (
                            "BALL_CAPTURED",
                            "PUSH_GOAL",
                        ):
                            follower.reset()

                # ----------------------------------
                # NAVIGATION LOGS
                # ----------------------------------
                print(
                    f"[NAV] frame={frame_id} "
                    f"state={nav.get('state')} "
                    f"action={action} "
                    f"distance={distance}mm "
                    f"balls={nav.get('ball_count')} "
                    f"goals={nav.get('goal_count')} "
                    f"details={nav}",
                    flush=True,
                )

                # ----------------------------------
                # EXECUTE MOTOR COMMAND
                # ----------------------------------
                try:
                    if not robot.is_running():
                        follower.reset()
                        continue

                    execute_goal_action(
                        robot,
                        action,
                        speed=MOTOR_SPEED,
                    )

                except ProgramStopped:
                    follower.reset()
                    continue

                except Exception as exc:
                    print(
                        f"[MOTOR ERROR] {exc}",
                        flush=True,
                    )
                    follower.reset()
                    break

                # ----------------------------------
                # STRUCTURED OUTPUT
                # ----------------------------------
                output = {
                    "frame_id": frame_id,
                    "detections": detections,
                    "navigation": nav,
                    "action": action,
                    "ultrasonic_mm": distance,
                    "inference_ms": result.get(
                        "timing", {}
                    ),
                }

                print(
                    json.dumps(output),
                    flush=True,
                )

                # ----------------------------------
                # SAVE ANNOTATED FRAMES
                # ----------------------------------
                if frame_id % 20 == 0:

                    outdir = (
                        BASE / "perception_output"
                    )

                    outdir.mkdir(exist_ok=True)

                    cv2.imwrite(
                        str(
                            outdir
                            / f"frame_{frame_id:04d}.jpg"
                        ),
                        cv2.cvtColor(
                            processed,
                            cv2.COLOR_RGB2BGR,
                        ),
                    )

                # ----------------------------------
                # OPTIONAL DISPLAY
                # ----------------------------------
                if show:
                    cv2.imshow(
                        "FOMO Navigation",
                        cv2.cvtColor(
                            processed,
                            cv2.COLOR_RGB2BGR,
                        ),
                    )

                    if (
                        cv2.waitKey(1) & 0xFF
                        == ord("q")
                    ):
                        break

                print(
                    f"[TIME] "
                    f"{time.monotonic() - start:.2f}s",
                    flush=True,
                )

        finally:
            camera.release()

            if show:
                cv2.destroyAllWindows()

            print(
                "[INFO] Navigation ended; "
                "motor pulses expire automatically.",
                flush=True,
            )


if __name__ == "__main__":

    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--frames",
        type=int,
        default=MAX_FRAMES,
    )

    parser.add_argument(
        "--show",
        action="store_true",
    )

    args = parser.parse_args()

    run_perception(
        max_frames=args.frames,
        show=args.show,
    )
