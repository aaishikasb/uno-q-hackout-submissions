
from arduino.app_utils import App
from perception import run_perception


def main():
    run_perception(max_frames=100000, show=False)


App.run(user_loop=main)
