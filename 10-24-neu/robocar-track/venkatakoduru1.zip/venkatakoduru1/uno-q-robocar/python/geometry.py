
# geometry.py
from dataclasses import dataclass
from typing import Optional
import math


@dataclass
class Point:
    x: float
    y: float


@dataclass
class Observation:
    ball: Optional[Point]
    cones: list[Point]
    timestamp: float


@dataclass
class GeometryResult:
    ball_visible: bool
    goal_visible: bool
    ball_error: Optional[float]
    goal_error: Optional[float]
    ball_goal_offset: Optional[float]
    ball_y_normalized: Optional[float]


class Geometry:
    def __init__(self, width=320, height=240):
        self.width = width
        self.height = height

    def normalize_x(self, x):
        return (x - self.width / 2) / (self.width / 2)

    def normalize_y(self, y):
        return (y - self.height / 2) / (self.height / 2)

    def goal_midpoint(self, cones):
        if len(cones) != 2:
            return None

        return Point(
            x=(cones[0].x + cones[1].x) / 2,
            y=(cones[0].y + cones[1].y) / 2,
        )

    def calculate(self, observation):
        ball = observation.ball
        goal = self.goal_midpoint(observation.cones)

        ball_error = (
            self.normalize_x(ball.x)
            if ball is not None else None
        )

        goal_error = (
            self.normalize_x(goal.x)
            if goal is not None else None
        )

        # Difference between ball and goal horizontal image positions.
        # This is NOT a metric alignment or push-direction estimate.
        ball_goal_offset = (
            goal_error - ball_error
            if ball_error is not None and goal_error is not None
            else None
        )

        return GeometryResult(
            ball_visible=ball is not None,
            goal_visible=goal is not None,
            ball_error=ball_error,
            goal_error=goal_error,
            ball_goal_offset=ball_goal_offset,
            ball_y_normalized=(
                self.normalize_y(ball.y)
                if ball is not None else None
            ),
        )
