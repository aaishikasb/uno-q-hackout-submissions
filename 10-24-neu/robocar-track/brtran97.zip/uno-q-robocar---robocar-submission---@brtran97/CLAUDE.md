# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## What this is

An Arduino App Lab app ("UNO Q Robocar") that drives a Hiwonder miniAuto mecanum chassis from an Arduino UNO Q. The goal: press the camera's BOOT button, and the robot finds a ball, approaches it in short pulses, and pushes it toward a goal. It must stop safely when the ball is lost, video goes stale, or an error happens. The starter provides motor control and camera firmware. The user writes the detector and decision logic in `python/`.

`README.md` is the official guide: setup, driver API, sensor payload, hardware pinout, camera flashing, and Edge Impulse training. `COMPANION.md` is a personal cheat sheet with untested starter code (`camera.py`, `detector.py`, a closed-loop `motion_check`) and a speed→PWM table. Where the two disagree, README wins.

## Commands

There is no test suite or linter. You can verify changes only on hardware.

**Inside App Lab (the workflow for Claude):** edit the local checkout, then stop and restart the app with the arduino-board tools (`apps_stop`, then `apps_start`). Read Python output and tracebacks with `apps_logs`. The sketch is recompiled and uploaded on start.

**Terminal workflow (the user's, macOS/Linux; needs GNU Make, zip, adb):**

```sh
make flash      # zip app.yaml/python/sketch, push via adb, run scripts/flash.sh on board, start app
make logs       # follow Python output
make monitor    # MCU serial monitor, 9600 baud (try ?, health, read_sensors)
make stop       # stop the CLI-managed app (not a motor-power cutoff)
make package    # build/uno-q-robocar.zip for App Lab import
make build      # compile sketch locally: arduino-cli compile --fqbn arduino:zephyr:unoq --profile default
make flash SERIAL=...   # pick a board when several are connected
```

`make flash` deploys to a separate app, `~/ArduinoApps/uno-q-robocar-cli`, not to this App Lab app. It replaces `python/` and `sketch/` there wholesale, but keeps `data/` and `.env`.

## Architecture

There are three processors:

```
ESP32-S3 camera ──MJPEG over its own Wi-Fi AP (http://192.168.5.1:81/stream, 320x240)──▶ UNO Q Linux (python/)
      └── BOOT button over I2C 0x79 ──▶ UNO Q MCU (sketch/) ◀── Bridge.call(...) ── python/
```

- **`python/main.py`**: entry point. It calls `robot.stop()` at startup, then `App.run(user_loop=lambda: robot.run_program(motion_check))` inside a `try/finally` that stops the robot. Replace `motion_check()` with the user's observe→act routine and keep the surrounding lifecycle.
- **`python/robot_client.py`** (`MiniAutoRobot`): a thin wrapper over `Bridge.call` to providers in the sketch. `run_program()` runs the routine once per BOOT-enabled session. It catches `ProgramStopped` and always calls `stop()` afterwards. `drive()` and `servo()` check `program_enabled` first and raise `ProgramStopped` if the program is off. `drive()` also re-checks after sleeping `ms/1000 + 0.1`. `drive_raw()` returns without waiting.
- **`sketch/sketch.ino`**: supplied firmware that normally needs no edits. It registers `Bridge.provide_safe` methods: `drive`, `stop`, `read_sensors`, `servo`, `buzz`, `led`, `drive_raw`, `health`. Bridge names must match `robot_client.py` exactly.
  - **Run gate:** `programEnabled` is the gate. A BOOT short-press toggles it, with a red/yellow countdown before green.
  - **Timed stops:** the MCU stops the motors on its own when a pulse's `ms` timer runs out (`updateDriveTimer`), so it does not depend on Python to stop them.
  - **Serial commands:** the sketch also takes serial commands, including Hiwonder `A`–`F|…|&` frames. These **bypass the BOOT gate**.
- **`camera/HiwonderCamStream/`**: ESP32-S3 firmware. It is flashed separately in Arduino IDE (esp32 core 2.0.11) and is not part of the App Lab app.
- **`sketch/sketch.yaml`**: pins the RouterBridge library and its dependencies. `app.yaml` declares no bricks, because the app uses only `arduino.app_utils`.

## Non-obvious behavior to respect

- `ms=0` means **continuous** motion. Always pass a small positive duration. The firmware clamps durations to 0–5000 ms, but Python sleeps for the unclamped value.
- `robot.stop()` ends the run, and a new BOOT press is needed to restart. To stop the motors but keep the run enabled, use `robot.drive("stop", speed=0, ms=100)`.
- `left` and `right` move the robot **sideways** (mecanum). To turn toward the ball, use `rotate_left` and `rotate_right`. An unknown direction string silently does nothing.
- Rotation gets about half the wheel power of translation at the same `speed`, and low speeds may stall (see the speed table in COMPANION.md).
- Treat ultrasonic `-1` (I2C failure) and `0` as unknown. Never enable the inherited obstacle-avoid demo (`F|1|&`): it drives forward on invalid readings.
- In loops that don't call `drive()` or `servo()`, check `robot.is_running()` so a BOOT press still stops the routine.
- The camera serves one stream at a time, and its Wi-Fi has no Internet. Python deps (e.g. `opencv-python-headless` in `python/requirements.txt`) must be installed before the UNO Q joins the camera network.
- Perception must use **fresh** frames: consume the newest frame, bound read and inference time, and end the run on a stale feed or a lost ball.
- An Edge Impulse `.eim` model, if used, goes in `python/` and is not included by default.

## Chassis-specific sketch changes (this robot)

- `HEADING_OFFSET_DEG = 180`: stock wiring drove "forward" away from the camera. The offset rotates translation only; rotation is unchanged.
- `ULTRASONIC_ENABLED = false`: the sketch loop froze while the ultrasonic sensor was in use. With it off, distance reads `-1` and the status colours go to the WS2812 instead.
- `startBridge()`/`updateBridge()`: `Bridge.begin()` sometimes fails at boot, which leaves no providers registered, so every Python call times out while the loop keeps blinking blue. The sketch now retries every second. Restarts can still hang, and a full power cycle (battery and USB) followed by a run from App Lab has been the reliable recovery.
- `readCamButtonState()` drains the Wire buffer before and after each read. Motor start-up causes one failed I2C read per pulse. Before this fix, the stray byte shifted later replies, so BOOT presses landed in the hold byte and were lost mid-pulse. Serial `WARN ...` lines report read failures and cooldown-ignored presses.
- On-floor calibration at 200 ms pulses: straight/lateral speed 120 moves 1–2 cm, rotate speed 160 turns 5–10°. These are kept as `FLOOR_MOVES` in `python/main.py`.
- OpenCV 4.13.0 ships with the board's Python image. Don't add `opencv-python-headless` to `requirements.txt`, because it fails to resolve.
