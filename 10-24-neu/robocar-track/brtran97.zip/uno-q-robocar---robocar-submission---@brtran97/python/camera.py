import threading
import time
from urllib.request import urlopen

STREAM_URL = "http://192.168.5.1:81/stream"


class LatestFrame:
    """Reads the camera's MJPEG stream in the background and keeps only the
    newest JPEG, so callers never act on buffered, stale frames."""

    def __init__(self, url: str = STREAM_URL) -> None:
        self._url = url
        self._lock = threading.Lock()
        self._jpeg: bytes | None = None
        self._stamp = 0.0
        self._seq = 0
        self.error: Exception | None = None
        threading.Thread(target=self._run, daemon=True).start()

    def _run(self) -> None:
        while True:
            try:
                # Short socket timeout: a stream that stops sending frames is
                # dropped and reopened after ~1.5 s instead of hanging.
                with urlopen(self._url, timeout=1.5) as stream:
                    buf = b""
                    while True:
                        chunk = stream.read(4096)
                        if not chunk:
                            raise ConnectionError("camera stream closed")
                        buf += chunk
                        end = buf.rfind(b"\xff\xd9")
                        start = buf.rfind(b"\xff\xd8", 0, end) if end != -1 else -1
                        if start != -1:
                            with self._lock:
                                self._jpeg = buf[start:end + 2]
                                self._stamp = time.monotonic()
                                self._seq += 1
                            self.error = None
                            buf = buf[end + 2:]
                        elif len(buf) > 200_000:
                            buf = buf[-100_000:]
            except Exception as error:
                self.error = error
                time.sleep(0.5)

    def latest_seq(self) -> int:
        """Sequence number of the newest frame received so far."""
        with self._lock:
            return self._seq

    def get(self, after_seq: int, timeout: float = 1.0) -> tuple[int, bytes, float] | None:
        """Return (seq, jpeg, age_s) for a frame newer than after_seq, or None
        if none arrives within timeout (treat that as a stalled feed)."""
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            with self._lock:
                seq, jpeg, stamp = self._seq, self._jpeg, self._stamp
            if jpeg is not None and seq > after_seq:
                return seq, jpeg, time.monotonic() - stamp
            time.sleep(0.01)
        return None
