import time

from arduino.app_utils import App
from camera import LatestFrame
from detector import detect
from robot_client import MiniAutoRobot

robot = MiniAutoRobot()
camera = LatestFrame()  # start streaming before the first BOOT press

# Step 4 calibration: one BOOT press runs each pulse once, pausing between
# them. Edit (direction, speed, ms) and restart the app to try new values.
# Floor results (speed, 200 ms): straight/lateral 120 -> 1-2 cm, rotate 160 -> 5-10 deg.
FLOOR_MOVES = [
    ("forward", 120, 200),
    ("backward", 120, 200),
    ("rotate_left", 160, 200),
    ("rotate_right", 160, 200),
    ("left", 120, 200),
    ("right", 120, 200),
]
# BOOT-interrupt test: one long pulse; press BOOT mid-pulse with wheels raised.
BOOT_TEST_MOVES = [
    ("forward", 120, 3000),
]
CALIBRATION_MOVES = FLOOR_MOVES
PAUSE_S = 2.0

FRAME_W = 320
DETECT_RUN_S = 30  # step 5: how long one BOOT press prints detections


def motion_check() -> None:
    for direction, speed, ms in CALIBRATION_MOVES:
        print(f"pulse: {direction} speed={speed} ms={ms}")
        robot.drive(direction, speed=speed, ms=ms)
        time.sleep(PAUSE_S)


def detection_check() -> None:
    # Step 5: motors stay stopped; print what the model sees in each fresh frame.
    started = time.monotonic()
    seq = 0
    while time.monotonic() - started < DETECT_RUN_S:
        if not robot.is_running():
            return
        got = camera.get(after_seq=seq, timeout=1.0)
        if got is None:
            print(f"STALE: no new frame in 1 s ({camera.error})")
            continue
        seq, jpeg, age = got
        t0 = time.monotonic()
        seen = detect(jpeg)
        infer_ms = (time.monotonic() - t0) * 1000
        ball, goal = seen["soccerball"], seen["goal"]
        if ball:
            side = "left" if ball["x"] < FRAME_W / 3 else "right" if ball["x"] > 2 * FRAME_W / 3 else "center"
            ball_text = f"ball {side} x={ball['x']} y={ball['y']} conf={ball['confidence']}"
        else:
            ball_text = "ball none"
        goal_text = f"goal x={goal['x']} y={goal['y']} conf={goal['confidence']}" if goal else "goal none"
        print(f"#{seq} age={age * 1000:.0f}ms infer={infer_ms:.0f}ms | {ball_text} | {goal_text}")


# Step 6: observe -> one short pulse -> observe. Start with robot, ball and
# goal lined up; the goal is not perceived, so pushing straight scores.
CENTER_X = 160
DEAD_BAND = 40         # px either side of center that counts as aligned
PUSH_Y = 200           # ball this low in the frame is close enough to push
LOCK_CONF = 0.8        # a ball must be this confident to lock on (strays score ~0.5-0.7)
CONFIRM_FRAMES = 3     # consistent frames before locking on
# How far the tracked ball may move between frames: turning sweeps it sideways
# across the image, driving forward mostly moves it down.
TRACK_LIMIT = {"rotate": (160, 60), "forward": (60, 80), None: (60, 60)}  # (dx, dy) px
REACQUIRE_AFTER_S = 0.7  # tracked ball missing this long -> search again (motors stopped)
LOST_TIMEOUT_S = 4       # no ball at all this long -> end the run
STALE_TIMEOUT_S = 4      # video often pauses 1-2 s after a pulse; wait (motors stopped) up to this
RUN_LIMIT_S = 60

TURN_SPEED = 160       # rotation needs more power than translation
APPROACH_SPEED = 120
PUSH = ("forward", 180, 1200)  # one push pulse; then look again and follow the ball
MAX_PUSHES = 4                 # pushes per run before stopping

# Start-of-run search: if no ball is in view, turn in small steps to about
# 30 degrees left, then 30 degrees right, then back to the start heading.
SWEEP_PULSE_MS = 200   # one step at TURN_SPEED, about 5-10 degrees
SWEEP_STEPS = 4        # steps per side, about 30 degrees
SWEEP_PLAN = (["rotate_left"] * SWEEP_STEPS + ["rotate_right"] * (2 * SWEEP_STEPS)
              + ["rotate_left"] * SWEEP_STEPS)
SWEEP_DWELL_S = 0.8    # look this long at each heading before the next step


def track(balls: list[dict], last: dict, action: tuple | None) -> dict | None:
    """Our ball in this frame: the detection nearest to where it was, within
    the movement the last pulse could cause. Anything farther is another ball."""
    kind = None if action is None else "rotate" if action[0].startswith("rotate") else "forward"
    max_dx, max_dy = TRACK_LIMIT[kind]
    near = [b for b in balls if abs(b["x"] - last["x"]) <= max_dx and abs(b["y"] - last["y"]) <= max_dy]
    if not near:
        return None
    return min(near, key=lambda b: abs(b["x"] - last["x"]) + abs(b["y"] - last["y"]))


def lock_candidate(balls: list[dict]) -> dict | None:
    """Best ball to lock on to: confident, and the closest (lowest in frame)."""
    strong = [b for b in balls if b["confidence"] >= LOCK_CONF]
    return max(strong, key=lambda b: b["y"]) if strong else None


def observe() -> list[dict]:
    """Balls in a frame captured after the last pulse ended. Raises
    TimeoutError if the feed has stalled."""
    after = camera.latest_seq()
    got = camera.get(after_seq=after, timeout=1.0)
    if got is None:
        # Every pulse is timed, so the motors are already stopped: just wait.
        print("video paused, waiting (motors stopped)")
        got = camera.get(after_seq=after, timeout=STALE_TIMEOUT_S - 1.0)
    if got is None:
        raise TimeoutError(f"camera feed stalled for {STALE_TIMEOUT_S} s ({camera.error})")
    _, jpeg, _ = got
    return detect(jpeg)["balls"]


def choose_action(ball: dict) -> tuple[str, int, int] | None:
    """(direction, speed, ms) for the next pulse, or None when it is time to push."""
    offset = ball["x"] - CENTER_X
    if offset < -DEAD_BAND:
        return ("rotate_left", TURN_SPEED, 250 if offset < -2 * DEAD_BAND else 150)
    if offset > DEAD_BAND:
        return ("rotate_right", TURN_SPEED, 250 if offset > 2 * DEAD_BAND else 150)
    if ball["y"] < PUSH_Y:
        # Longer steps while far, short ones near the ball.
        return ("forward", APPROACH_SPEED, 300 if ball["y"] < 150 else 200)
    return None


def goal_attempt() -> None:
    started = time.monotonic()
    print(f"battery_mv={robot.read_sensors().get('battery_mv')}")
    ball = None              # the ball we are following, None while searching
    action = None            # last pulse, so tracking knows how far the ball may shift
    last_seen = started      # last time we had our ball (or the run started)
    candidate, streak = None, 0
    pushes = 0
    ever_locked = False
    sweep_step, heading_since = 0, started

    while time.monotonic() - started < RUN_LIMIT_S:
        if not robot.is_running():
            return
        balls = observe()
        now = time.monotonic()

        found = track(balls, ball, action) if ball else None
        if found is None:
            if ball and now - last_seen < REACQUIRE_AFTER_S:
                continue  # brief dropout: look again without moving
            if ball:
                print(f"lost track at x={ball['x']} y={ball['y']}, searching (motors stopped)")
                ball, candidate, streak = None, None, 0
            # Lock on only to a confident ball seen in the same place repeatedly.
            pick = lock_candidate(balls)
            if pick and candidate and track([pick], candidate, None):
                streak += 1
            else:
                streak = 1 if pick else 0
            candidate = pick
            if streak >= CONFIRM_FRAMES:
                ball, action, last_seen = candidate, None, now
                ever_locked = True
                print(f"locked on ball x={ball['x']} y={ball['y']} conf={ball['confidence']}")
                continue
            if not ever_locked:
                # Nothing at this heading yet: after a short look, turn one step.
                if now - heading_since < SWEEP_DWELL_S:
                    continue
                if sweep_step >= len(SWEEP_PLAN):
                    print("STOP: no ball found after sweeping about 30 degrees each way")
                    return
                direction = SWEEP_PLAN[sweep_step]
                sweep_step += 1
                print(f"searching: step {sweep_step}/{len(SWEEP_PLAN)} {direction}")
                robot.drive(direction, TURN_SPEED, SWEEP_PULSE_MS)
                # The view moved, so restart the confirmation at the new heading.
                candidate, streak = None, 0
                heading_since = last_seen = time.monotonic()
                continue
            if now - last_seen > LOST_TIMEOUT_S:
                print("STOP: no ball")
                return
            continue

        ball, last_seen = found, now
        action = choose_action(ball)
        if action is None:
            pushes += 1
            print(f"ball x={ball['x']} y={ball['y']} -> push {pushes}/{MAX_PUSHES} {PUSH}")
            robot.drive(*PUSH)
            if pushes >= MAX_PUSHES:
                print("STOP: push limit reached")
                return
            # The ball rolls ahead; keep following it and push again when close.
            action = PUSH
            continue
        print(f"ball x={ball['x']} y={ball['y']} conf={ball['confidence']} -> {action}")
        robot.drive(*action)
    print("STOP: time limit")


def safe_goal_attempt() -> None:
    # A stalled feed (or Bridge timeout) ends the run; run_program then stops
    # the motors and waits for the next BOOT press instead of crashing the app.
    try:
        goal_attempt()
    except TimeoutError as error:
        print(f"STOP: {error}")


ROUTINE = safe_goal_attempt


def wait_for_mcu(limit_s: float = 90) -> None:
    # The sketch's Bridge sometimes comes up late after a restart (it retries
    # every second), so keep trying instead of crashing on the first timeout.
    started = time.monotonic()
    while True:
        try:
            robot.stop()
            return
        except TimeoutError:
            if time.monotonic() - started > limit_s:
                raise
            print("waiting for the sketch to answer over Bridge...")


try:
    wait_for_mcu()
    print(f"health  : {robot.health()}")
    print(f"sensors : {robot.read_sensors()}")
    print(f"Press the camera BOOT button to run {ROUTINE.__name__}.")
    App.run(user_loop=lambda: robot.run_program(ROUTINE))
finally:
    robot.stop()
