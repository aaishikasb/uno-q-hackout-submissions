from arduino.app_bricks.object_detection import ObjectDetection

MIN_CONFIDENCE = 0.5  # 0..1; close balls often read 0.6-0.8, tracking rejects strays

_model = ObjectDetection()


def _objects(detections: list[dict], label: str) -> list[dict]:
    """All detections of one label above MIN_CONFIDENCE, most confident first."""
    found = []
    for det in detections:
        if det.get("class_name") != label:
            continue
        # The brick reports confidence as a percentage (e.g. 99.4); use 0..1.
        confidence = float(det.get("confidence", 0)) / 100
        if confidence < MIN_CONFIDENCE:
            continue
        # FOMO boxes are fixed-size grid cells (always 26 px wide here), so
        # w/h don't track distance; use y (lower in frame = closer) instead.
        x1, y1, x2, y2 = det.get("bounding_box_xyxy", (0, 0, 0, 0))
        found.append(dict(
            x=int((x1 + x2) / 2),
            y=int((y1 + y2) / 2),
            w=int(x2 - x1),
            h=int(y2 - y1),
            confidence=round(confidence, 2),
        ))
    return sorted(found, key=lambda obj: obj["confidence"], reverse=True)


def detect(jpeg: bytes) -> dict:
    """Return {"balls": [...], "soccerball": best | None, "goal": best | None} for one frame."""
    out = _model.detect(jpeg, confidence=0.3) or {}  # loose here, filtered in _objects
    detections = out.get("detection", [])
    balls = _objects(detections, "soccerball")
    goals = _objects(detections, "goal")
    return {
        "balls": balls,
        "soccerball": balls[0] if balls else None,
        "goal": goals[0] if goals else None,
    }
