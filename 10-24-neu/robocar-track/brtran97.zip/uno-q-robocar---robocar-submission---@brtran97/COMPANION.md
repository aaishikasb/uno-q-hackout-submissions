# Robocar session companion

Personal cheat sheet to keep open next to [README.md](README.md) (the official guide) and [PREWORK.md](PREWORK.md). Where they disagree, the official guide wins. Code marked *untested* was written without access to the hardware, so check it on the robot.

---

## Part 1: Before you go

### The goal in one sentence

Press the camera's **BOOT** button, and the robot finds the ball, drives to it in short steps, pushes it into the goal, and **stops safely** if anything goes wrong.

### How points are earned (100 total)

| Criterion | Pts | What it really means |
| --- | --: | --- |
| Ball detection | 25 | Reliably finds the ball in *their* lighting/positions |
| Actions driven by perception | 25 | Every move is based on a **fresh** frame: observe → short pulse → observe |
| Goal-directed behavior | 20 | Ends up pushing the ball toward/into the goal |
| Reliability and safe recovery | 20 | Stops when the ball is lost, video is stale, or an error happens; a BOOT press restarts it cleanly |
| Explanation and reproducibility | 10 | Write down launch steps, calibration numbers, camera settings, and credits |

Takeaway: **safety and stop behavior are worth as much as scoring the goal.** A slow robot that always stops correctly beats a fast one that sometimes runs away.

### Mental model: three computers

```
ESP32-S3 camera ──MJPEG over its own Wi-Fi──▶ UNO Q Linux (Python): detect + decide
      │                                              │
      └─BOOT button over I2C──▶ UNO Q MCU (sketch) ◀─┘ Bridge.call("drive", ...)
                                 motors, sensors, timed stops
```

- **Python (`python/`)** is your code: reading frames, detecting the ball, and choosing the next move.
- **Sketch (`sketch/sketch.ino`)** is supplied firmware. It drives the motors and stops them after `ms`. You shouldn't need to edit it.
- **Camera firmware** comes pre-flashed. Don't touch it unless the camera itself is broken.

### Pre-work checklist (about 30 min)

- [ ] Arduino App Lab installed and opens ([setup](https://docs.arduino.cc/software/app-lab/setup/overview/))
- [ ] Data-capable **USB-C cable** packed (not a charge-only cable)
- [ ] For the terminal workflow: `brew install make zip android-platform-tools`, then check that `adb version` works
- [ ] Read through [main.py](python/main.py), then [robot_client.py](python/robot_client.py) `drive()`, then `Bridge.provide_safe("drive", rpcDrive)` in [sketch.ino](sketch/sketch.ino)
- [ ] On paper, plan what happens when the ball is on the left, centered, or missing
- [ ] Decide on a detector: **OpenCV color threshold** (fastest to get working, recommended) or **Edge Impulse** (README bottom section; a public prelabelled project exists)

### Things that will trip you up

1. **The camera network has no Internet.** Install Python packages (OpenCV) *before* the UNO Q joins the camera Wi-Fi.
2. **The camera serves one stream at a time.** Close the browser preview before Python reads it.
3. **`ms=0` means drive forever.** Always pass a small positive duration.
4. **`robot.stop()` ends the run.** It needs a new BOOT press. To pause motors without ending the run, use `robot.drive("stop", speed=0, ms=100)`.
5. **`left` / `right` move sideways** (mecanum wheels). To turn toward the ball, use `rotate_left` / `rotate_right`.
6. **Unknown direction strings silently do nothing.** Typos won't raise an error.
7. **Ultrasonic `-1` means "unknown"**, not "close". Never enable the inherited obstacle demo (`F|1|&`).
8. **Only one App Lab app runs at a time.** Stop others before flashing.
9. **The BOOT button is a software stop.** Know where the **physical motor-power disconnect** is.
10. **`speed` is not wheel power, and turning gets half.** Firmware scales speed 0–255 down twice. With `drive()`, rotate gets about 0.5× the power that forward gets at the same speed. Wheels likely stall below about PWM 50, so `rotate_*` at speed 100 may not move at all. See the [speed table](#what-speed-actually-means).
11. **Hiwonder's docs describe a different controller.** The kit's docs assume an Atmega328 UNO R3 with Bluetooth and on-camera vision. Here the UNO Q runs its own sketch and the camera only streams video. Use their docs for hardware facts, not for code or flashing steps. See [Hiwonder docs](#hiwonder-miniauto-docs-what-applies).

---

## Part 2: During the session

### Checkpoint ladder

Work through these in order and don't skip ahead. Tick each one off once it works.

| # | Checkpoint | Done when |
| - | --- | --- |
| 0 | Wheels **raised**, power disconnect located, camera SSID/password and motor calibration in hand | Note them in the calibration log below |
| 1 | Board connected (`make devices` shows it, or App Lab sees it) | |
| 2 | Starter runs: BOOT, red/yellow/green countdown, one forward pulse, stop | |
| 3 | BOOT **interrupts** a pulse (try `ms=2000` with wheels raised) | Required before any autonomy |
| 4 | Browser preview at `http://192.168.5.1:81/` (laptop on camera Wi-Fi), then pick the camera angle | Close the tab afterwards |
| 5 | `requirements.txt` installed **while still online**, then the UNO Q joins the camera Wi-Fi | |
| 6 | Stream check from the app (README §3 snippet) prints "Camera stream reached" | |
| 7 | Movement calibration on the floor: smallest reliable pulse for each direction | Fill in the table below |
| 8 | Detector running **with motors stopped**: prints found/x/size for the ball on the left, center, right, and hidden | |
| 9 | Closed loop: rotate toward the ball and approach in short pulses | |
| 10 | Goal attempt from the supplied starting arrangement | |
| 11 | Repeat runs, then write up and export the app | |

### Command cheat sheet (run in `robocar/`)

```sh
make devices        # board visible?
make flash          # deploy + compile + start (re-run after every edit)
make logs           # your print() output and tracebacks  (Ctrl+C leaves, app keeps running)
make monitor        # MCU serial: ?, health, read_sensors   (9600 baud)
make stop           # stop the app (NOT a power cutoff)
make package        # zip for App Lab import instead
```

If another app is already running:

```sh
adb -d shell
TMPDIR=/tmp arduino-app-cli app list
TMPDIR=/tmp arduino-app-cli app stop APP_ID
exit
```

Join the camera Wi-Fi from UNO Q Linux. This isn't in the official guide; it assumes Debian's NetworkManager, so verify it on the day:

```sh
adb -d shell
nmcli dev wifi list
nmcli dev wifi connect "miniAuto_CAM_XX" password "THE_PASSWORD"
curl -sI http://192.168.5.1:81/ | head -1   # expect an HTTP status line
```

### Driver API at a glance

| Call | Notes |
| --- | --- |
| `robot.drive(dir, speed=150, ms=500)` | Blocks for `ms + 100 ms`. Raises `ProgramStopped` if BOOT was pressed. Speed 0–255, ms clamped to 5000 |
| `robot.drive_raw(m0, m1, m2, m3, ms)` | −255..255 per motor, **returns immediately** (no wait) |
| `robot.stop()` | Motors off **and run ended** |
| `robot.is_running()` | Check this inside any loop that isn't calling `drive()` |
| `robot.read_sensors()` | `program_enabled`, `ultrasonic_mm`, `line_ok`, `line_digital`, `battery_mv` |
| `robot.servo(angle)` | Gripper range is **90 (closed) to 150 (open)** (see below). The MCU blocks for about 0.6 s while it moves, so BOOT handling waits too |
| `robot.led(on)`, `robot.buzz()` | Handy for signalling "ball found" or "giving up" |

Directions: `forward backward left right rotate_left rotate_right stop`

#### What `speed` actually means

Taken from [sketch.ino](sketch/sketch.ino): `speedToPercent`, then `velocityController`, then `motorsSetPercent`. Wheel PWM (0–255) for each `drive()` speed:

| `speed` | forward / backward / left / right | rotate_left / rotate_right |
| --: | --: | --: |
| 100 | ~70 | ~50 (may stall) |
| 150 | ~105 | ~75 |
| 200 | ~140 | ~100 |
| 255 | ~180 | ~128 |

- Translation is capped at about 70% and rotation at about 50% of full PWM. `drive_raw` can reach full power: it maps ±255 to ±100% per wheel, with no scaling.
- Hiwonder's own firmware never sends less than PWM 50 to a moving wheel (`pwm_min = 50`, [ch. 5.1](https://docs.hiwonder.com/projects/miniAuto/en/latest/docs/5.motion_control_basic_lesson.html#motion-library-analysis)). That's a hint that the motors stall below about 50. This firmware's floor is 2.
- Low battery lowers real motor power at the same PWM, so re-check your pulses when `battery_mv` drops.

#### Gripper / servo (only if one is fitted)

- Hiwonder's gripper range is **0–60** (0 = closed, 60 = open; [ch. 8.2](https://docs.hiwonder.com/projects/miniAuto/en/latest/docs/8.robotic_gripper_control_lesson.html#robotic-gripper-app-control), [ch. 10](https://docs.hiwonder.com/projects/miniAuto/en/latest/docs/10.serial_communication_instruction.html)).
- This firmware's serial `E|x|&` command calls `servo(90 + x)`. In Python, that makes **`servo(90)` closed and `servo(150)` fully open**.
- Values outside 90–150 may push the gripper past its mechanical stops. Hiwonder doesn't document stall protection.

#### Sensor facts from the Hiwonder docs

- **Ultrasonic** ([ch. 6.4](https://docs.hiwonder.com/projects/miniAuto/en/latest/docs/6.secondary_development_lesson.html#ultrasonic-ranging)):
  - Effective range is about 20–4000 mm.
  - A value of `0` means no valid data, and this firmware returns `-1` on I2C failure. Treat **both `0` and `-1` as unknown**.
  - Readings vary with the target's surface. A small round ball reflects poorly, so the sensor is probably better at seeing the goal or a wall than the ball (unverified).
- **Line sensor** ([ch. 6.7](https://docs.hiwonder.com/projects/miniAuto/en/latest/docs/6.secondary_development_lesson.html#line-following)):
  - A bit is `1` when that probe sees black.
  - The onboard potentiometer sets sensitivity (clockwise = more sensitive).
  - This could help if the field has a taped goal line.
- **Battery** ([ch. 1.4](https://docs.hiwonder.com/projects/miniAuto/en/latest/docs/1.getting_ready.html#charging-instruction)):
  - 2× 18650 cells. Two cells in series read about 8.4 V when full and about 7.4 V nominal (standard Li-ion figures; Hiwonder doesn't give them).
  - Charger light is red while charging and green when full. Charge with 5 V 1–2 A and unplug promptly. The power switch is on the battery holder.
  - `battery_mv` uses a factor tuned for the old UNO, so compare it once against the real voltage before trusting it.
- **Camera** ([ch. 7.1](https://docs.hiwonder.com/projects/miniAuto/en/latest/docs/7.ai_vision_games_lesson.html#introduction-to-esp32-s3-vision-module)):
  - Needs a steady 5 V; Hiwonder recommends at least 5 V 2 A. A weak supply can put "watermark" artifacts in the image.
  - Image origin is the **top-left**, with y increasing downward.
  - Hiwonder advises a plain, simple background to reduce false color detections.

### Calibration log (fill in on the day; needed for the write-up)

| Item | Value |
| --- | --- |
| Robot / camera SSID | |
| Supplied motor calibration | |
| Surface | |
| Battery (`battery_mv`) at start | |

| Direction | Speed | ms | Result (cm or degrees) | Notes |
| --- | --: | --: | --- | --- |
| forward | | | | |
| backward | | | | |
| rotate_left | | | | |
| rotate_right | | | | |
| left (lateral) | | | | |
| right (lateral) | | | | |

| Detector parameter | Value |
| --- | --- |
| HSV lower / upper | |
| Min contour area | |
| Center dead band (px) | |
| "Close enough to push" size | |
| Stale-frame timeout | |

### Starter code (*untested*)

**`python/requirements.txt`** (create it, then flash while the board is online):

```
opencv-python-headless
numpy
```

**`python/camera.py`** keeps only the newest frame, so stale video is detectable. It parses the MJPEG stream by hand, which avoids OpenCV's internal buffering handing you old frames.

```python
import threading
import time
from urllib.request import urlopen

import cv2
import numpy as np

STREAM_URL = "http://192.168.5.1:81/stream"


class LatestFrame:
    def __init__(self, url: str = STREAM_URL) -> None:
        self._url = url
        self._lock = threading.Lock()
        self._jpeg: bytes | None = None
        self._stamp = 0.0
        self._seq = 0
        self.error: Exception | None = None
        threading.Thread(target=self._run, daemon=True).start()

    def _run(self) -> None:
        while True:
            try:
                with urlopen(self._url, timeout=3) as stream:
                    buf = b""
                    while True:
                        chunk = stream.read(4096)
                        if not chunk:
                            raise ConnectionError("camera stream closed")
                        buf += chunk
                        end = buf.rfind(b"\xff\xd9")
                        start = buf.rfind(b"\xff\xd8", 0, end) if end != -1 else -1
                        if start != -1:
                            with self._lock:
                                self._jpeg = buf[start:end + 2]
                                self._stamp = time.monotonic()
                                self._seq += 1
                            buf = buf[end + 2:]
                        elif len(buf) > 200_000:
                            buf = buf[-100_000:]
            except Exception as error:
                self.error = error
                time.sleep(0.5)

    def get(self, after_seq: int, timeout: float = 1.0):
        """Return (seq, BGR image) for a frame newer than after_seq, or None if none arrives in time."""
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            with self._lock:
                seq, jpeg = self._seq, self._jpeg
            if jpeg is not None and seq > after_seq:
                image = cv2.imdecode(np.frombuffer(jpeg, np.uint8), cv2.IMREAD_COLOR)
                if image is not None:
                    return seq, image
            time.sleep(0.01)
        return None
```

**`python/detector.py`** finds an orange ball by color. Tune `LOWER`/`UPPER` from real frames under the session lighting.

```python
import cv2
import numpy as np

LOWER = np.array([5, 120, 120])    # HSV, tune on the day
UPPER = np.array([20, 255, 255])
MIN_AREA = 80                      # px^2, rejects specks


def find_ball(image):
    """Return None, or dict(x=center_x, y=center_y, radius=r, area=a) in 320x240 pixels."""
    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
    mask = cv2.inRange(hsv, LOWER, UPPER)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    best = None
    for contour in contours:
        area = cv2.contourArea(contour)
        if area < MIN_AREA:
            continue
        (x, y), radius = cv2.minEnclosingCircle(contour)
        roundness = area / (np.pi * radius * radius + 1e-6)   # 1.0 = perfect circle
        if roundness < 0.5:
            continue
        if best is None or area > best["area"]:
            best = dict(x=int(x), y=int(y), radius=int(radius), area=int(area))
    return best
```

To tune the HSV range, save a frame with `cv2.imwrite("/tmp/frame.jpg", image)`, then pull it to your laptop with `adb -d pull /tmp/frame.jpg`. Note that `robocar/captures/` is gitignored, so you can keep samples there.

**`python/main.py`** routine. Keep the existing `try/finally` and `App.run(...)` lines and replace only `motion_check`:

```python
import time
from camera import LatestFrame
from detector import find_ball

camera = LatestFrame()          # start streaming before the first BOOT press

FRAME_W = 320
DEAD_BAND = 30                  # px either side of center
PUSH_RADIUS = 45                # ball this big counts as "at the ball", calibrate it
RUN_LIMIT_S = 45
MISSES_ALLOWED = 3              # tolerate brief detection drop-outs


def motion_check() -> None:     # name kept so the rest of main.py is unchanged
    started = time.monotonic()
    seq = 0
    misses = 0
    while time.monotonic() - started < RUN_LIMIT_S:
        if not robot.is_running():
            return
        got = camera.get(after_seq=seq, timeout=1.0)
        if got is None:
            print("STOP: stale/no video", camera.error)
            return                                  # run_program() calls robot.stop()
        seq, image = got
        ball = find_ball(image)
        if ball is None:
            misses += 1
            print(f"miss {misses}")
            if misses > MISSES_ALLOWED:
                print("STOP: ball lost")
                return
            continue
        misses = 0
        offset = ball["x"] - FRAME_W // 2
        if offset < -DEAD_BAND:
            action = ("rotate_left", 160, 80)       # rotate needs more speed; see speed table
        elif offset > DEAD_BAND:
            action = ("rotate_right", 160, 80)
        elif ball["radius"] < PUSH_RADIUS:
            action = ("forward", 120, 200)
        else:
            action = ("forward", 150, 600)          # push
        print(f"ball x={ball['x']} r={ball['radius']} -> {action}")
        robot.drive(*action)
        if action[2] >= 600:
            print("push done")
            return
    print("STOP: time limit")
```

Every rotate/forward value above is a placeholder. Replace them with your calibration-log numbers.

### Debugging quick reference

| Symptom | Check |
| --- | --- |
| Nothing happens on BOOT | `make logs`: did Python start? Is another app running? `read_sensors` in `make monitor` |
| `ProgramStopped` right away | Program not enabled. Press BOOT and wait for the countdown |
| Stream check times out | UNO Q not on camera Wi-Fi, or the browser tab still holds the stream |
| `ModuleNotFoundError: cv2` | requirements weren't installed while online. Rejoin Internet Wi-Fi, flash, then switch back |
| Robot turns the wrong way | Swap rotate directions in the code, then re-check camera orientation (it may be mirrored) |
| Detection flickers | Widen HSV, raise `MIN_AREA`, or bump `MISSES_ALLOWED` by one |
| Robot drifts or overshoots | Shorter pulses, lower speed; check `battery_mv` (low battery means weaker pulses) |
| Forward works but rotate barely moves | Expected at low speeds: rotate gets about half the power. Raise its speed (150+) or use `drive_raw` |
| Lateral (`left`/`right`) goes diagonal or turns | Uneven floor grip or swapped mecanum wheels; Hiwonder [ch. 5.3](https://docs.hiwonder.com/projects/miniAuto/en/latest/docs/5.motion_control_basic_lesson.html#movement). Prefer rotate + forward |
| Speckled or striped image | Camera power is low (check battery). Close any other stream viewer |
| Wheel spins the wrong way | Stop, use the supplied calibration, and ask staff. Don't run serial `dir_sweep`/`combo_scan` unsupervised |

### Hiwonder miniAuto docs: what applies

[Docs home](https://docs.hiwonder.com/projects/miniAuto/en/latest/index.html). Their kit uses an Atmega328 UNO R3 with Bluetooth and runs vision on the camera itself. Your kit uses the UNO Q with this repo's sketch, and the camera only streams video.

| Chapter | Use it? | Why / what to look at |
| --- | --- | --- |
| [1. Getting Ready](https://docs.hiwonder.com/projects/miniAuto/en/latest/docs/1.getting_ready.html) | ✅ Skim | [Charging](https://docs.hiwonder.com/projects/miniAuto/en/latest/docs/1.getting_ready.html#charging-instruction), battery safety, [assembly photos](https://docs.hiwonder.com/projects/miniAuto/en/latest/docs/1.getting_ready.html#assembly-instruction) if a wheel or camera mount comes loose |
| [2. Arduino Environment](https://docs.hiwonder.com/projects/miniAuto/en/latest/docs/2.Set_Arduino_Environment.html) | ❌ | Arduino IDE setup for the stock UNO. You use App Lab / `make flash` |
| [3. Default Program Download](https://docs.hiwonder.com/projects/miniAuto/en/latest/docs/3.default_program_download.html) | ❌ **Don't** | Flashes Hiwonder firmware. That would replace the prepared setup |
| [4. App Control](https://docs.hiwonder.com/projects/miniAuto/en/latest/docs/4.App_control.html) | ❌ | Bluetooth phone app; not wired up here |
| [5. Motion Control](https://docs.hiwonder.com/projects/miniAuto/en/latest/docs/5.motion_control_basic_lesson.html) | ✅ **Read 5.1–5.3** | The same `Velocity_Controller` mecanum math as this sketch (angle 0 = forward, 90 = left, 180 = back, 270 = right; positive rot = counter-clockwise). Explains lateral and diagonal moves |
| [6. Secondary Development](https://docs.hiwonder.com/projects/miniAuto/en/latest/docs/6.secondary_development_lesson.html) | ⚠️ Ideas only | [6.4 ultrasonic](https://docs.hiwonder.com/projects/miniAuto/en/latest/docs/6.secondary_development_lesson.html#ultrasonic-ranging) (range, 0 = invalid), [6.5 following](https://docs.hiwonder.com/projects/miniAuto/en/latest/docs/6.secondary_development_lesson.html#ultrasonic-following) (distance-band behavior: <200 mm back off, 300–700 mm approach), [6.7 line sensor](https://docs.hiwonder.com/projects/miniAuto/en/latest/docs/6.secondary_development_lesson.html#line-following). Skip [6.6 obstacle avoidance](https://docs.hiwonder.com/projects/miniAuto/en/latest/docs/6.secondary_development_lesson.html#obstacle-avoidance); the README says to keep it off |
| [7. AI Vision Games](https://docs.hiwonder.com/projects/miniAuto/en/latest/docs/7.ai_vision_games_lesson.html) | ⚠️ Concepts only | [7.5 Color Tracking](https://docs.hiwonder.com/projects/miniAuto/en/latest/docs/7.ai_vision_games_lesson.html#color-tracking) is the same idea as this track: rotate to keep the ball's x at the image center, under a 20 ms PID timer. Their code runs on the camera with HSV.exe thresholds and a `HW_ESP32S3CAM` Wi-Fi name. **Neither applies**: your camera only streams, and its SSID is `miniAuto_CAM_XX` |
| [8. Gripper](https://docs.hiwonder.com/projects/miniAuto/en/latest/docs/8.robotic_gripper_control_lesson.html) | ⚠️ If fitted | Angle range (see gripper notes above) |
| [9. Wireless Glove](https://docs.hiwonder.com/projects/miniAuto/en/latest/docs/9.wireless_glove_control_lesson.html) | ❌ | Not part of the kit |
| [10. Serial Communication](https://docs.hiwonder.com/projects/miniAuto/en/latest/docs/10.serial_communication_instruction.html) | ✅ For `make monitor` | This sketch accepts the same `A`–`F` frames at 9600 baud. Examples: `A|2|&` forward, `A|8|&` stop, `C|40|&` speed %, `D|&` returns `$distance_mm,battery_mv$`. These **bypass the BOOT gate**, so only use them with the wheels raised. **Never send `F|1|&`** |

Idea borrowed from ch. 6.5 and 7.5: a proportional turn (rotate pulse length ∝ |offset|) converges faster than fixed pulses. Keep a minimum pulse that actually moves the robot, and keep the dead band.

### Before demo / submission

- [ ] Three or more clean runs in a row from the supplied starting arrangement
- [ ] Shown: hiding the ball stops the robot, and covering or killing the camera stops the robot
- [ ] BOOT restarts predictably after every stop
- [ ] Write-up: launch steps, calibration tables above, HSV values / model, camera angle, credits (Edge Impulse project, any copied code)
- [ ] **Export the app** from App Lab, or commit the local folder, so the code and calibration are saved together
