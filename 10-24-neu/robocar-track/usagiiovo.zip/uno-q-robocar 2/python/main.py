import time

from arduino.app_utils import App
from robot_client import MiniAutoRobot

robot = MiniAutoRobot()

# ===== 可调参数 =====
RUN_LIMIT_S = 30                 # 每次运行最长秒数
CENTER_LO, CENTER_HI = 0.4, 0.6  # 中间区域：在这之间就算对准了
MIN_SCORE = 0.5                  # 分数低于这个不算看到球
LOST_S = 2.0                     # 连续这么多秒看不到球就停车
CLOSE_CY = 0.85                  # 球在画面里的高度超过这个值，算“很近”
TURN = dict(speed=120, ms=400)
FORWARD = dict(speed=120, ms=400)
PUSH = dict(speed=150, ms=300)


def wait_fresh_frame(grabber, after, timeout=1.5):
    """等一帧在 after 时刻之后拍到的画面，避免用到移动前的旧画面。"""
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        frame, age = grabber.latest()
        if frame is not None and time.monotonic() - age > after:
            return frame
        time.sleep(0.03)
    return None


def best_ball(dets):
    balls = [d for d in dets if d["label"] == "soccerball" and d["score"] >= MIN_SCORE]
    return max(balls, key=lambda d: d["score"]) if balls else None


def approach() -> None:
    from detector import FrameGrabber, BallDetector

    detector = BallDetector()
    grabber = FrameGrabber()
    try:
        start = time.monotonic()
        last_seen = start
        moved_at = start
        while robot.is_running():
            if time.monotonic() - start > RUN_LIMIT_S:
                print("到达时间上限，停车")
                return
            frame = wait_fresh_frame(grabber, moved_at)
            if frame is None:
                print("摄像头没有新画面，停车", grabber.error or "")
                return
            detections = detector.detect(frame)
            ball = best_ball(detections)
            now = time.monotonic()
            if ball is None:
                if now - last_seen > LOST_S:
                    print("看不到球，停车")
                    return
                print("这一帧没看到球，原地等待")
                continue
            last_seen = now

            if ball["cx"] < CENTER_LO:
                name, direction, params = "左转", "rotate_left", TURN
            elif ball["cx"] > CENTER_HI:
                name, direction, params = "右转", "rotate_right", TURN
            elif ball["cy"] > CLOSE_CY:
                name, direction, params = "推球", "forward", PUSH
            else:
                name, direction, params = "前进", "forward", FORWARD

            print(f"Ball cx={ball['cx']:.2f}, cy={ball['cy']:.2f} -> {name}")

            if name == "推球":
                print("Ball close and centered. Pushing!")
                robot.drive("forward", **PUSH)
                print("Push completed. Stopping.")
                return

            robot.drive(direction, **params)
            moved_at = time.monotonic()
                
    finally:
        grabber.stop()
        detector.close()


def single_forward() -> None:
    print("Single forward test starting...")
    robot.drive("forward", speed=150, ms=500)
    print("Single forward test completed.")
    
def wait_for_mcu(tries=4):
    """启动时电机板可能还没准备好，多试几次。"""
    for i in range(tries):
        try:
            robot.stop()
            return
        except TimeoutError:
            print(f"电机板还没准备好，2 秒后重试 ({i + 1}/{tries})")
            time.sleep(2)
    raise RuntimeError("电机板一直没有回应：请拔插 USB 后再 Run")


try:
    wait_for_mcu()
    print(f"health  : {robot.health()}")
    print(f"sensors : {robot.read_sensors()}")
    print("短按 BOOT 开始接近球。第一次请先把轮子架空！")
    App.run(user_loop=lambda: robot.run_program(approach))

finally:
    try:
        robot.stop()
    except Exception as e:
        print("退出时停车失败:", e)