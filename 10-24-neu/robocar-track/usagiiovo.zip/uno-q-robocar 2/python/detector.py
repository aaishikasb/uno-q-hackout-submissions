import os
import threading
import time
from urllib.request import urlopen

import cv2
import numpy as np
from edge_impulse_linux.image import ImageImpulseRunner

STREAM_URL = "http://192.168.5.1:81/stream"
def find_model():
    import glob
    here = os.path.dirname(os.path.abspath(__file__))
    candidates = [os.path.join(here, "model.eim")]
    candidates += glob.glob("/app/*.eim") + glob.glob("/app/*/*.eim")
    for p in candidates:
        if os.path.isfile(p):
            return p
    print("找不到 .eim 文件")
    print("python 文件夹里有:", os.listdir(here))
    print("/app 里有:", os.listdir("/app"))
    raise FileNotFoundError("model.eim not found")


class FrameGrabber:
    """后台持续读取摄像头画面，只保留最新的一帧。"""

    def __init__(self, url=STREAM_URL):
        self.url = url
        self.frame = None
        self.stamp = 0.0
        self.error = None
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def _run(self):
        try:
            with urlopen(self.url, timeout=3) as stream:
                buf = b""
                while not self._stop.is_set():
                    chunk = stream.read(4096)
                    if not chunk:
                        raise RuntimeError("camera stream ended")
                    buf += chunk
                    end = buf.rfind(b"\xff\xd9")
                    if end == -1:
                        if len(buf) > 1_000_000:
                            buf = b""
                        continue
                    start = buf.rfind(b"\xff\xd8", 0, end)
                    if start != -1:
                        jpg = np.frombuffer(buf[start:end + 2], np.uint8)
                        img = cv2.imdecode(jpg, cv2.IMREAD_COLOR)
                        if img is not None:
                            with self._lock:
                                self.frame = img
                                self.stamp = time.monotonic()
                    buf = buf[end + 2:]
        except Exception as e:
            self.error = e

    def latest(self):
        """返回 (最新画面, 画面已经过了几秒)。还没有画面时返回 (None, 无穷大)。"""
        with self._lock:
            if self.frame is None:
                return None, float("inf")
            return self.frame.copy(), time.monotonic() - self.stamp

    def stop(self):
        self._stop.set()


class BallDetector:
    """用 Edge Impulse 模型识别足球和球门。"""

    def __init__(self, model_path=None):
        model_path = model_path or find_model()
        print("Using model:", model_path)
        try: 
            os.chmod(model_path, 0o755)
        except OSError:
            pass
        self.runner = ImageImpulseRunner(model_path)
        info = self.runner.init()
        params = info["model_parameters"]
        self.in_w = params["image_input_width"]
        self.in_h = params["image_input_height"]
        print("Model loaded, labels:", params["labels"])

    def detect(self, bgr):
        """返回识别结果列表，每项包含 label、score、cx、cy。
        cx、cy 是 0 到 1 之间的位置：cx=0 在画面最左，cx=1 在最右。"""
        rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
        try:
            features, _ = self.runner.get_features_from_image_auto_studio_settings(rgb)
        except AttributeError:
            features, _ = self.runner.get_features_from_image(rgb)
        res = self.runner.classify(features)
        out = []
        for b in res["result"].get("bounding_boxes", []):
            out.append({
                "label": b["label"],
                "score": b["value"],
                "cx": (b["x"] + b["width"] / 2) / self.in_w,
                "cy": (b["y"] + b["height"] / 2) / self.in_h,
            })
        return out

    def close(self):
        self.runner.stop()