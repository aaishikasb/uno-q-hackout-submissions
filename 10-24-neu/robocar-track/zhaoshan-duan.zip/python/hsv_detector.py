"""White-and-black ball on a green floor, by color threshold. Pure: no clock, no I/O."""

import math
from dataclasses import dataclass

import cv2
import numpy as np

import config


@dataclass(frozen=True)
class Ball:
    found: bool
    cx: float = 0.0
    cy: float = 0.0
    radius: float = 0.0
    bottom_y: float = 0.0
    area: float = 0.0
    circularity: float = 0.0
    touches_edge: bool = False
    quality: float = 0.0


NO_BALL = Ball(found=False)

_OPEN = np.ones((3, 3), np.uint8)
_CLOSE = np.ones((5, 5), np.uint8)


def white_mask(hsv: np.ndarray, horizon_row: int, s_max: int, v_min: int) -> np.ndarray:
    mask = cv2.inRange(hsv, (0, 0, v_min), (179, s_max, 255))
    mask[: max(0, horizon_row)] = 0
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, _OPEN)
    return cv2.morphologyEx(mask, cv2.MORPH_CLOSE, _CLOSE)


def green_mask(hsv: np.ndarray) -> np.ndarray:
    return cv2.inRange(hsv, (config.GREEN_H_MIN, config.GREEN_S_MIN, 40),
                       (config.GREEN_H_MAX, 255, 255))


def ring_green_fraction(green: np.ndarray, cx: float, cy: float, radius: float) -> float:
    """Share of in-image pixels in the ring just outside the candidate that are floor green."""
    ring = np.zeros(green.shape, np.uint8)
    center = (round(cx), round(cy))
    cv2.circle(ring, center, max(2, round(radius * 1.6)), 255, -1)
    cv2.circle(ring, center, max(1, round(radius * 1.15)), 0, -1)
    total = cv2.countNonZero(ring)
    if total == 0:
        return 0.0
    return cv2.countNonZero(cv2.bitwise_and(ring, green)) / total


def _candidate(contour: np.ndarray, width: int, height: int, min_area: float, max_area: float,
               min_circ: float, min_fill: float) -> Ball | None:
    # The convex hull fills in the black patches of a soccer ball.
    hull = cv2.convexHull(contour)
    area = cv2.contourArea(hull)
    if not min_area <= area <= max_area:
        return None
    perimeter = cv2.arcLength(hull, True)
    if perimeter <= 0:
        return None
    circularity = min(1.0, 4 * math.pi * area / perimeter**2)
    (cx, cy), radius = cv2.minEnclosingCircle(hull)
    fill = area / (math.pi * radius**2) if radius > 0 else 0.0
    x, y, w, h = cv2.boundingRect(hull)
    touches = x <= 1 or y + h >= height - 1 or x + w >= width - 1
    relax = 0.7 if touches else 1.0
    if circularity < min_circ * relax or fill < min_fill * relax:
        return None
    return Ball(True, cx, cy, radius, cy + radius, area, circularity, touches,
                quality=circularity * fill)


def detect_ball(
    bgr: np.ndarray,
    prev: tuple[float, float] | None = None,
    horizon_row: int = config.HORIZON_ROW,
    s_max: int = config.WHITE_S_MAX,
    v_min: int = config.WHITE_V_MIN,
    min_area: float = config.BALL_MIN_AREA_PX,
    max_area: float = config.BALL_MAX_AREA_PX,
    min_circ: float = config.BALL_MIN_CIRCULARITY,
    min_fill: float = config.BALL_MIN_FILL,
) -> Ball:
    height, width = bgr.shape[:2]
    hsv = cv2.cvtColor(cv2.GaussianBlur(bgr, (3, 3), 0), cv2.COLOR_BGR2HSV)
    mask = white_mask(hsv, horizon_row, s_max, v_min)
    green = green_mask(hsv)
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    candidates = [
        c for c in (_candidate(cnt, width, height, min_area, max_area, min_circ, min_fill)
                    for cnt in contours)
        if c is not None
        and c.radius <= config.BALL_MAX_RADIUS_PX
        and ring_green_fraction(green, c.cx, c.cy, c.radius) >= config.GREEN_RING_MIN
    ]
    if not candidates:
        return NO_BALL
    if prev is not None:
        px, py = prev
        return min(candidates, key=lambda b: (b.cx - px) ** 2 + (b.cy - py) ** 2)
    return max(candidates, key=lambda b: b.area)


def detect(bgr: np.ndarray) -> Ball:
    """Default-config entry point, used by tools/eval_detector.py."""
    return detect_ball(bgr)
