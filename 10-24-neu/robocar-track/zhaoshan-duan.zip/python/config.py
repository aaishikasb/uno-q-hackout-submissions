"""All tunable thresholds in one place. Values marked "calibrate" are starting guesses."""

from pathlib import Path

# "observe": print detections, never drive. "capture": observe + save frames under data/.
# "drive": the full attempt.
MODE = "drive"
OBSERVE_TIME_LIMIT_S = 120.0
CAPTURE_EVERY = 5  # save every Nth frame in capture mode
CAPTURE_MAX = 200

# Camera stream (the board joins the camera AP at the OS level; no credentials here).
STREAM_URL = "http://192.168.5.1:81/stream"
CONNECT_TIMEOUT_S = 2.0
CONNECT_RETRY_S = 6.0
FRAME_TIMEOUT_S = 2.0  # no new frame for this long means the feed is stale (1.0 cut runs on Wi-Fi blips)
STALE_S = 0.5  # a frame older than this at decision time is stale
SETTLE_S = 0.15  # calibrate: ignore frames that arrive this soon after a pulse ends

# White ball on a green floor (HSV, OpenCV ranges: H 0-179, S and V 0-255).
HORIZON_ROW = 80  # calibrate: rows above this (walls) are ignored
WHITE_S_MAX = 70
WHITE_V_MIN = 150
BALL_MIN_AREA_PX = 12
BALL_MAX_AREA_PX = 20000
BALL_MIN_CIRCULARITY = 0.55
BALL_MIN_FILL = 0.45
BALL_MAX_RADIUS_PX = 60
# Floor check: the ring just outside a candidate must be mostly green floor.
GREEN_H_MIN = 30
GREEN_H_MAX = 95
GREEN_S_MIN = 50  # calibrate: this camera tints greys slightly green
GREEN_RING_MIN = 0.4  # calibrate on field frames
ACT_QUALITY = 0.35  # below this a detection is "uncertain" and never causes motion

# Edge Impulse model (the .eim is gitignored; copy it into python/ before make flash).
EI_MODEL_PATH = Path(__file__).with_name("model.eim")
EI_BALL_LABEL = "soccerball"
EI_GOAL_LABEL = "goal"  # one box per cone; a goal is the gap between two cones
EI_MIN_CONFIDENCE = 0.5  # calibrate
EI_TIMEOUT_S = 0.5
EI_GOAL_OVERLAP_BALL_DROP = True  # a "cone" box overlapping the ball box is the ball
