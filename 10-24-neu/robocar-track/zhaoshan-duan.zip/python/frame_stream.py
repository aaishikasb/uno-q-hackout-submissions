"""Newest-frame MJPEG reader for the ESP32 camera.

A background thread drains the stream continuously so old frames never queue up, and keeps
only the newest JPEG with a sequence number and its monotonic arrival time. Decoding happens
in the caller, never in the thread.
"""

import threading
import time
import urllib.request
from dataclasses import dataclass
from typing import Any, Callable

import config

SOI = b"\xff\xd8"
EOI = b"\xff\xd9"


class StreamError(Exception):
    """The camera stream could not be opened, failed, or ended."""


@dataclass(frozen=True)
class Frame:
    jpeg: bytes
    seq: int
    arrival: float


class JpegSplitter:
    """Pulls complete JPEGs (SOI..EOI) out of an MJPEG byte stream, ignoring part headers."""

    def __init__(self, max_frame_bytes: int = 512 * 1024) -> None:
        self._buf = b""
        self._max = max_frame_bytes

    def feed(self, data: bytes) -> list[bytes]:
        self._buf += data
        frames: list[bytes] = []
        while True:
            start = self._buf.find(SOI)
            if start < 0:
                self._buf = self._buf[-1:]  # keep a possible half marker
                return frames
            end = self._buf.find(EOI, start + 2)
            restart = self._buf.find(SOI, start + 2)
            if 0 <= restart and (end < 0 or restart < end):
                self._buf = self._buf[restart:]  # truncated frame: skip to the next one
                continue
            if end < 0:
                self._buf = self._buf[start:]
                if len(self._buf) > self._max:
                    self._buf = b""
                return frames
            frames.append(self._buf[start : end + 2])
            self._buf = self._buf[end + 2 :]


class FrameStream:
    """Context manager: open per run, closed and joined on exit."""

    def __init__(
        self,
        url: str = config.STREAM_URL,
        opener: Callable[[], Any] | None = None,
        clock: Callable[[], float] = time.monotonic,
        connect_timeout_s: float = config.CONNECT_TIMEOUT_S,
        connect_retry_s: float = config.CONNECT_RETRY_S,
    ) -> None:
        self._opener = opener or (lambda: urllib.request.urlopen(url, timeout=connect_timeout_s))
        self._clock = clock
        self._connect_retry_s = connect_retry_s
        self._cond = threading.Condition()
        self._latest: Frame | None = None
        self._error: StreamError | None = None
        self._stop = False
        self._source: Any = None
        self._thread: threading.Thread | None = None

    def __enter__(self) -> "FrameStream":
        self.open()
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()

    def open(self) -> None:
        deadline = time.monotonic() + self._connect_retry_s
        while True:
            try:
                self._source = self._opener()
                break
            except OSError as exc:
                if time.monotonic() >= deadline:
                    raise StreamError(f"camera connect failed: {exc}") from exc
                time.sleep(0.5)
        self._thread = threading.Thread(target=self._run, name="frame-stream", daemon=True)
        self._thread.start()

    def close(self) -> None:
        with self._cond:
            self._stop = True
            self._cond.notify_all()
        if self._source is not None:
            try:
                self._source.close()
            except OSError:
                pass
        if self._thread is not None:
            self._thread.join(timeout=2.0)

    def is_alive(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    def wait_fresh(self, after_seq: int, not_before: float, timeout: float) -> Frame | None:
        """Newest frame with seq > after_seq that arrived at or after not_before, or None."""
        deadline = time.monotonic() + timeout
        with self._cond:
            while True:
                frame = self._latest
                if frame is not None and frame.seq > after_seq and frame.arrival >= not_before:
                    return frame
                if self._error is not None:
                    raise self._error
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    return None
                self._cond.wait(remaining)

    def _run(self) -> None:
        splitter = JpegSplitter()
        seq = 0
        try:
            while not self._stop:
                chunk = self._source.read1(4096)
                if not chunk:
                    if not self._stop:
                        self._fail(StreamError("camera stream ended"))
                    return
                for jpeg in splitter.feed(chunk):
                    seq += 1
                    with self._cond:
                        self._latest = Frame(jpeg=jpeg, seq=seq, arrival=self._clock())
                        self._cond.notify_all()
        except Exception as exc:  # socket timeout, reset, closed during read
            if not self._stop:
                self._fail(StreamError(f"camera stream failed: {exc}"))

    def _fail(self, error: StreamError) -> None:
        with self._cond:
            self._error = error
            self._cond.notify_all()
