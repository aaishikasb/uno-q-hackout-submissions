from arduino.app_utils import App

import config
from attempt import run_attempt
from controller import Params
from ei_detector import EiDetector
from robot_client import MiniAutoRobot
from routines import guarded, run_observe

robot = MiniAutoRobot()

# Measured on the field: the EI model puts a ball at the bumper at bottom_y ~160 (coarse grid).
# Longer, stronger pulses: 120/250 ms barely moved on carpet. Stays inside attempt.py's
# SPEED_MAX 160 and PULSE_MS_MAX 600.
DRIVE_PARAMS = Params(push_bottom_y=150.0, speed=150, pulse_ms_max=550, push_ms=500,
                      forward_ms_far=550, forward_ms_near=300)

# On this chassis the firmware's "forward" drives away from the camera (seen on the field:
# every "forward" backed off from the ball), so translations are mirrored. Rotations are
# passed through unchanged; they are untested in this orientation.
MIRRORED = {"forward": "backward", "backward": "forward", "left": "right", "right": "left"}


class CameraFrontRobot:
    """Delegates to the real robot, translating commands so 'forward' means toward the camera's view."""

    def __init__(self, inner: MiniAutoRobot) -> None:
        self._inner = inner

    def drive(self, command: str, speed: int = 150, ms: int = 500) -> None:
        self._inner.drive(MIRRORED.get(command, command), speed=speed, ms=ms)

    def __getattr__(self, name: str) -> object:
        return getattr(self._inner, name)


def drive() -> None:
    detector = EiDetector()  # a load failure raises; guarded() ends the run and keeps the app alive
    try:
        run_attempt(CameraFrontRobot(robot), params=DRIVE_PARAMS,
                    detect=lambda image, prev: detector.detect(image).ball)
    finally:
        detector.close()


def routine() -> None:
    if config.MODE == "observe":
        run_observe(robot.is_running)
    elif config.MODE == "capture":
        run_observe(robot.is_running, save_every=config.CAPTURE_EVERY)
    elif config.MODE == "drive":
        drive()
    else:
        print(f"[ERROR] unknown or unfinished MODE={config.MODE!r}; nothing will move")


try:
    robot.stop()
    print(f"health  : {robot.health()}")
    print(f"sensors : {robot.read_sensors()}")
    print(f"mode    : {config.MODE}. Short-press the camera BOOT button to start a run.")
    App.run(user_loop=lambda: robot.run_program(guarded(routine)))
finally:
    robot.stop()
