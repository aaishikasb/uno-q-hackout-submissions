"""Edge Impulse FOMO detector for the ball and goal. Same answer shape as hsv_detector.

Coordinate mapping follows edge_impulse_linux 1.2.2 image.py: the SDK resizes the RGB frame
to the model input with the Studio resize mode, and boxes come back in model-input pixels.
"""

import os
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

import cv2
import numpy as np

import config
from hsv_detector import NO_BALL, Ball


@dataclass(frozen=True)
class Goal:
    """The goal is the gap between two cones. With one cone visible, cones=1 and cx is that
    cone's centre, so the caller can tell a real gap from a single post."""

    found: bool
    cx: float = 0.0
    left_x: float = 0.0
    right_x: float = 0.0
    width: float = 0.0
    quality: float = 0.0
    cones: int = 0


NO_GOAL = Goal(found=False)


@dataclass(frozen=True)
class Detections:
    ball: Ball
    goal: Goal


class EiError(Exception):
    """The model could not be loaded, timed out, or returned something unexpected."""


def to_camera(box: dict, mode: str, in_w: int, in_h: int, cam_w: int, cam_h: int
              ) -> tuple[float, float, float, float]:
    """Map a box (x, y, width, height) from model-input pixels back to camera pixels."""
    x, y, w, h = box["x"], box["y"], box["width"], box["height"]
    if mode == "squash":
        sx, sy = cam_w / in_w, cam_h / in_h
        return x * sx, y * sy, w * sx, h * sy
    if mode == "fit-shortest":  # SDK centre-crops to the model aspect, then resizes
        aspect = in_w / in_h
        if cam_w / cam_h > aspect:
            crop_w, crop_h = int(cam_h * aspect), cam_h
            off_x, off_y = (cam_w - crop_w) // 2, 0
        else:
            crop_w, crop_h = cam_w, int(cam_w / aspect)
            off_x, off_y = 0, (cam_h - crop_h) // 2
        sx, sy = crop_w / in_w, crop_h / in_h
        return x * sx + off_x, y * sy + off_y, w * sx, h * sy
    if mode == "fit-longest":  # SDK scales to fit, then pads with black bars
        scale = min(in_w / cam_w, in_h / cam_h)
        pad_x = (in_w - int(cam_w * scale)) // 2
        pad_y = (in_h - int(cam_h * scale)) // 2
        return (x - pad_x) / scale, (y - pad_y) / scale, w / scale, h / scale
    raise EiError(f"unsupported resize mode {mode!r}")


Rect = tuple[float, float, float, float]  # x, y, w, h in camera pixels


def matching(boxes: list[dict], label: str, min_conf: float) -> list[dict]:
    """Boxes with this label at or above the threshold, most confident first."""
    found = [b for b in boxes if b.get("label") == label and b.get("value", 0) >= min_conf]
    return sorted(found, key=lambda b: b["value"], reverse=True)


def overlaps(a: Rect, b: Rect) -> bool:
    return a[0] < b[0] + b[2] and b[0] < a[0] + a[2] and a[1] < b[1] + b[3] and b[1] < a[1] + a[3]


def ball_from(box: dict, rect: Rect, cam_w: int, cam_h: int) -> Ball:
    x, y, w, h = rect
    touches = x <= 1 or y + h >= cam_h - 1 or x + w >= cam_w - 1
    return Ball(True, x + w / 2, y + h / 2, max(w, h) / 2, y + h, w * h, 0.0, touches,
                quality=float(box["value"]))


def goal_from(cones: list[tuple[dict, Rect]]) -> Goal:
    """One cone: aim at it. Two cones: aim at the midpoint of their centres."""
    cones = sorted(cones, key=lambda c: c[1][0])
    left, right = cones[0][1], cones[-1][1]
    left_x, right_x = left[0], right[0] + right[2]
    centres = [r[0] + r[2] / 2 for _, r in cones]
    quality = min(float(box["value"]) for box, _ in cones)
    return Goal(True, sum(centres) / len(centres), left_x, right_x, right_x - left_x,
                quality, cones=len(cones))


def parse(result: Any, mode: str, in_w: int, in_h: int, cam_w: int, cam_h: int,
          min_conf: float = config.EI_MIN_CONFIDENCE) -> Detections:
    """Pure: turn a raw classify() response into ball and goal answers."""
    try:
        boxes = result["result"]["bounding_boxes"]
        if not isinstance(boxes, list):
            raise TypeError("bounding_boxes is not a list")
    except (KeyError, TypeError) as exc:
        raise EiError(f"unexpected model output: {result!r:.200}") from exc

    def rect(box: dict) -> Rect:
        return to_camera(box, mode, in_w, in_h, cam_w, cam_h)

    ball, ball_rect = NO_BALL, None
    balls = matching(boxes, config.EI_BALL_LABEL, min_conf)
    if balls:
        ball_rect = rect(balls[0])
        ball = ball_from(balls[0], ball_rect, cam_w, cam_h)

    cones: list[tuple[dict, Rect]] = []
    for box in matching(boxes, config.EI_GOAL_LABEL, min_conf):
        r = rect(box)
        if config.EI_GOAL_OVERLAP_BALL_DROP and ball_rect is not None and overlaps(r, ball_rect):
            continue  # the model sometimes calls the ball a cone
        if any(overlaps(r, kept) for _, kept in cones):
            continue  # FOMO can split one cone into neighbouring boxes
        cones.append((box, r))
        if len(cones) == 2:
            break
    goal = goal_from(cones) if cones else NO_GOAL
    return Detections(ball, goal)


def with_timeout(fn: Callable[[], Any], timeout_s: float) -> Any:
    """The SDK sets no IPC timeout when shared memory is on; a hung model must not hang the
    run. The worker thread can't be killed, so after a real hang the app needs a restart."""
    out: dict[str, Any] = {}

    def work() -> None:
        try:
            out["value"] = fn()
        except Exception as exc:
            out["error"] = exc

    worker = threading.Thread(target=work, name="ei-classify", daemon=True)
    worker.start()
    worker.join(timeout_s)
    if worker.is_alive():
        raise EiError(f"inference took longer than {timeout_s}s")
    if "error" in out:
        raise EiError(f"inference failed: {out['error']}") from out["error"]
    return out["value"]


class EiDetector:
    """Loads the .eim once. Not thread-safe: one caller at a time."""

    def __init__(self, model_path: Path = config.EI_MODEL_PATH, runner_factory:
                 Callable[[str], Any] | None = None) -> None:
        if not model_path.exists():
            raise EiError(f"model file not found: {model_path}")
        if not os.access(model_path, os.X_OK):
            # The zip/deploy step may drop the execute bit; the app owns the file, so restore it.
            try:
                os.chmod(model_path, model_path.stat().st_mode | 0o111)
                print(f"[EI] restored execute bit on {model_path}")
            except OSError as exc:
                raise EiError(f"model file is not executable: {model_path} ({exc})") from exc
            if not os.access(model_path, os.X_OK):
                raise EiError(f"model file is not executable: {model_path} (chmod +x it)")
        if runner_factory is None:
            from edge_impulse_linux.image import ImageImpulseRunner  # board-only dependency

            runner_factory = ImageImpulseRunner
        self._runner = runner_factory(str(model_path))
        try:
            info = self._runner.init()
            params = info["model_parameters"]
            self.in_w = int(params["image_input_width"])
            self.in_h = int(params["image_input_height"])
        except Exception as exc:
            raise EiError(f"model failed to start: {exc}") from exc
        mode = params.get("image_resize_mode", "squash")
        self.mode = "squash" if mode == "not-reported" else mode  # SDK falls back to squash
        labels = params.get("labels", [])
        print(f"[EI] loaded {info.get('project', {}).get('name', '?')} "
              f"input={self.in_w}x{self.in_h} mode={self.mode} labels={labels}")
        for label in (config.EI_BALL_LABEL, config.EI_GOAL_LABEL):
            if labels and label not in labels:
                print(f"[EI] WARNING: label {label!r} is not in the model's labels {labels}")

    def detect(self, bgr: np.ndarray) -> Detections:
        cam_h, cam_w = bgr.shape[:2]
        rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)  # the SDK packs channels as R, G, B
        features, _ = self._runner.get_features_from_image_auto_studio_settings(rgb)
        result = with_timeout(lambda: self._runner.classify(features), config.EI_TIMEOUT_S)
        return parse(result, self.mode, self.in_w, self.in_h, cam_w, cam_h)

    def close(self) -> None:
        self._runner.stop()
