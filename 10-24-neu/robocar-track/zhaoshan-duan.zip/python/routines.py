"""BOOT-started routines. Each one opens its own stream, so nothing carries over between runs."""

import os
import time
from pathlib import Path
from typing import Callable, Protocol

import cv2
import numpy as np

import config
from ei_detector import Detections, EiDetector, Goal
from frame_stream import Frame, FrameStream
from hsv_detector import Ball
from robot_client import ProgramStopped

DATA_DIR = Path(__file__).resolve().parents[1] / "data"


class Detector(Protocol):
    def detect(self, bgr: np.ndarray) -> Detections: ...

    def close(self) -> None: ...


def guarded(routine: Callable[[], None]) -> Callable[[], None]:
    """Never let an error kill the app: App would exit and BOOT could not restart anything.
    ProgramStopped still propagates so run_program handles it."""

    def run() -> None:
        try:
            routine()
        except ProgramStopped:
            raise
        except Exception as exc:
            print(f"[ERROR] run ended: {type(exc).__name__}: {exc}")

    return run


def decode(frame: Frame) -> np.ndarray | None:
    return cv2.imdecode(np.frombuffer(frame.jpeg, np.uint8), cv2.IMREAD_COLOR)


def describe(ball: Ball) -> str:
    if not ball.found:
        return "ball=none"
    edge = " edge" if ball.touches_edge else ""
    return (f"ball x={ball.cx:.0f} y={ball.cy:.0f} r={ball.radius:.1f} "
            f"bottom={ball.bottom_y:.0f} conf={ball.quality:.2f}{edge}")


def describe_goal(goal: Goal) -> str:
    if not goal.found:
        return "goal=none"
    return (f"goal cx={goal.cx:.0f} cones={goal.cones} left={goal.left_x:.0f} "
            f"right={goal.right_x:.0f} conf={goal.quality:.2f}")


def host_path(path: Path) -> str:
    """The app runs in a container with the app folder mounted at /app; APP_HOME is the
    same folder on the board, which is the path to adb pull from."""
    app_home = os.environ.get("APP_HOME")
    root = DATA_DIR.parent
    if app_home and path.is_relative_to(root):
        return str(Path(app_home) / path.relative_to(root))
    return str(path)


def run_observe(
    is_running: Callable[[], bool],
    stream_factory: Callable[[], FrameStream] = FrameStream,
    detector_factory: Callable[[], Detector] = EiDetector,
    save_every: int = 0,
    time_limit_s: float = config.OBSERVE_TIME_LIMIT_S,
    clock: Callable[[], float] = time.monotonic,
) -> str:
    """Print the EI detector's ball and goal for every frame without moving. Optionally save
    every Nth JPEG under data/captures/<HHMMSS>/. Returns the reason the run ended."""
    detector = detector_factory()  # loaded once per BOOT press; a load failure ends the run
    try:
        return _observe(is_running, stream_factory, detector, save_every, time_limit_s, clock)
    finally:
        detector.close()


def _observe(is_running: Callable[[], bool], stream_factory: Callable[[], FrameStream],
             detector: Detector, save_every: int, time_limit_s: float,
             clock: Callable[[], float]) -> str:
    started = clock()
    last_seq = 0
    saved = 0
    capture_dir = DATA_DIR / "captures" / time.strftime("%H%M%S")
    print(f"[OBSERVE] started save_every={save_every}")
    if save_every:
        print(f"[OBSERVE] saving frames to {host_path(capture_dir)}")
    with stream_factory() as stream:
        while clock() - started < time_limit_s:
            if not is_running():
                raise ProgramStopped
            frame = stream.wait_fresh(last_seq, 0.0, config.FRAME_TIMEOUT_S)
            if frame is None:
                print("[STOP] stale video: no new frame")
                return "stale"
            last_seq = frame.seq
            image = decode(frame)
            if image is None:
                continue
            found = detector.detect(image)
            age_ms = (clock() - frame.arrival) * 1000
            print(f"[OBS] t={clock() - started:5.1f} seq={frame.seq} age={age_ms:.0f}ms "
                  f"{describe(found.ball)} | {describe_goal(found.goal)}")
            if save_every and frame.seq % save_every == 0 and saved < config.CAPTURE_MAX:
                capture_dir.mkdir(parents=True, exist_ok=True)
                (capture_dir / f"{frame.seq:05d}.jpg").write_bytes(frame.jpeg)
                saved += 1
    print(f"[OBSERVE] time limit reached, saved={saved}")
    return "timeout"
