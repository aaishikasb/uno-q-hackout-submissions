"""One BOOT-started goal attempt: newest frame -> detect -> decide -> one bounded pulse -> repeat.

pulse() is the only code that moves the robot. Every exit path returns an outcome, and
run_program calls robot.stop() after the routine returns. ProgramStopped propagates.
"""

import json
import time
from dataclasses import asdict
from typing import Any, Callable, Protocol

import config
import controller
from controller import Action, Observation, Params
from frame_stream import Frame, FrameStream, StreamError
from hsv_detector import Ball, detect_ball
from robot_client import ProgramStopped
from routines import DATA_DIR, decode

VERSION = "v1"
SPEED_MAX = 160
PULSE_MS_MIN = 50
PULSE_MS_MAX = 600
RUN_TIME_LIMIT_S = 60.0
MAX_PULSES = 60
SETTLE_SKIP_FRAMES = 1  # fb_count=2: the first post-pulse frame may be captured mid-pulse
MAX_BAD_FRAMES = 3  # consecutive undecodable or identical frames count as stale


class Robot(Protocol):
    def is_running(self) -> bool: ...
    def drive(self, command: str, speed: int = 150, ms: int = 500) -> None: ...
    def read_sensors(self) -> dict[str, Any]: ...


def pulse(robot: Robot, action: Action) -> None:
    """The single motion chokepoint. Raises ValueError on anything unbounded."""
    if action.command not in controller.MOVES:
        raise ValueError(f"refusing unknown move {action.command!r}")
    if not 0 < action.speed <= SPEED_MAX:
        raise ValueError(f"refusing speed {action.speed}")
    if not PULSE_MS_MIN <= action.ms <= PULSE_MS_MAX:
        raise ValueError(f"refusing pulse of {action.ms} ms")
    robot.drive(action.command, speed=action.speed, ms=action.ms)


def observation(ball: Ball, sensors: dict[str, Any]) -> Observation:
    mm = sensors.get("ultrasonic_mm", -1)
    return Observation(found=ball.found, cx=ball.cx, radius=ball.radius, bottom_y=ball.bottom_y,
                       quality=ball.quality, ultrasonic_mm=mm if isinstance(mm, int) else -1)


def next_frame(stream: Any, after_seq: int, not_before: float, skip: int) -> Frame | None:
    """Newest frame after after_seq arriving at or after not_before, skipping `skip` more."""
    frame = stream.wait_fresh(after_seq, not_before, config.FRAME_TIMEOUT_S)
    for _ in range(skip):
        if frame is None:
            return None
        frame = stream.wait_fresh(frame.seq, not_before, config.FRAME_TIMEOUT_S)
    return frame


def write_run_log(record: dict[str, Any]) -> None:
    try:
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        with (DATA_DIR / "runs.jsonl").open("a") as log:
            log.write(json.dumps(record) + "\n")
    except OSError as exc:
        print(f"[WARN] run log not written: {exc}")


def run_attempt(
    robot: Robot,
    params: Params = Params(),
    stream_factory: Callable[[], Any] = FrameStream,
    detect: Callable[..., Ball] = detect_ball,
    clock: Callable[[], float] = time.monotonic,
    log: Callable[[dict[str, Any]], None] = write_run_log,
) -> str:
    started = clock()
    pulses: dict[str, int] = {}
    battery = -1
    outcome = "error"
    try:
        battery = robot.read_sensors().get("battery_mv", -1)
        outcome = _loop(robot, params, stream_factory, detect, clock, started, pulses)
        return outcome
    except ProgramStopped:
        outcome = "boot"
        raise
    except StreamError as exc:
        outcome = "camera" if "connect" in str(exc) else "stale"
        print(f"[STOP] {exc}")
        return outcome
    except Exception as exc:
        outcome = "error"
        print(f"[ERROR] run ended: {type(exc).__name__}: {exc}")
        return outcome
    finally:
        print(f"[RUN] outcome={outcome} duration={clock() - started:.1f}s pulses={pulses}")
        log({"start": time.strftime("%Y-%m-%dT%H:%M:%S"), "version": VERSION, "mode": config.MODE,
             "params": asdict(params), "outcome": outcome,
             "duration_s": round(clock() - started, 2), "pulses": pulses, "battery_mv": battery})


def _loop(robot: Robot, params: Params, stream_factory: Callable[[], Any],
          detect: Callable[..., Ball], clock: Callable[[], float], started: float,
          pulses: dict[str, int]) -> str:
    state, memory = controller.initial_state(params)
    last_seq, not_before, skip = 0, 0.0, 0
    last_jpeg, bad = b"", 0
    prev: tuple[float, float] | None = None
    with stream_factory() as stream:
        while True:
            if not robot.is_running():
                raise ProgramStopped
            if clock() - started >= RUN_TIME_LIMIT_S:
                print("[STOP] run time limit")
                return "timeout"
            if sum(pulses.values()) >= MAX_PULSES:
                print("[STOP] pulse limit")
                return "timeout"
            frame = next_frame(stream, last_seq, not_before, skip)
            if frame is None:
                print("[STOP] stale video: no new frame")
                return "stale"
            last_seq, skip = frame.seq, 0
            image = decode(frame) if frame.jpeg != last_jpeg else None
            last_jpeg = frame.jpeg
            if image is None:
                bad += 1
                if bad >= MAX_BAD_FRAMES:
                    print("[STOP] stale video: corrupt or frozen frames")
                    return "stale"
                continue
            bad = 0
            ball = detect(image, prev)
            prev = (ball.cx, ball.cy) if ball.found else None
            age = clock() - frame.arrival
            if age > config.STALE_S:
                print(f"[STOP] stale video: frame age {age * 1000:.0f}ms")
                return "stale"
            obs = observation(ball, robot.read_sensors())
            decision = controller.decide(state, memory, obs, params)
            act = decision.action
            act_text = f"{act.command}/{act.speed}/{act.ms}" if act else "none"
            print(f"[RUN] t={clock() - started:5.1f} seq={frame.seq} age={age * 1000:.0f}ms "
                  f"ball={'%.0f,r%.0f,q%.2f' % (obs.cx, obs.radius, obs.quality) if obs.found else 'none'} "
                  f"us={obs.ultrasonic_mm} {state}->{decision.state} act={act_text} {decision.reason}")
            state, memory = decision.state, decision.memory
            if decision.outcome is not None:
                return decision.outcome
            if act is not None:
                pulse(robot, act)
                pulses[state] = pulses.get(state, 0) + 1
                not_before, skip = clock() + config.SETTLE_S, SETTLE_SKIP_FRAMES
