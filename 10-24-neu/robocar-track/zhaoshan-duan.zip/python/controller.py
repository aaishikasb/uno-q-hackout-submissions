"""Ball-approach state machine. Pure: no clock, no I/O, no robot.

decide() maps (state, memory, observation) to the next state, memory, at most one bounded
pulse, a reason, and an outcome when the run must end. The attempt loop owns the camera, the
robot and the clock; this module only decides.

States: SEARCH (run start, ball not acquired yet) -> APPROACH -> PUSH -> end.
Lost ball ends the run, except the bounded cases in PLAN.md section 3.5: run-start SEARCH
(SEARCH_MAX_PULSES) and the contact-zone blind push (BLIND_PUSH_PULSES).
"""

from dataclasses import dataclass, replace

SEARCH = "SEARCH"
APPROACH = "APPROACH"
PUSH = "PUSH"

MOVES = ("forward", "backward", "left", "right", "rotate_left", "rotate_right")


@dataclass(frozen=True)
class Params:
    """Starting guesses, all UNCALIBRATED until the floor calibration (PLAN.md section 9)."""

    target_x: float = 160.0  # calibrate: image column of the robot's push line
    steer_sign: int = 1  # -1 if a right correction moves the ball further right in the image
    center_with: str = "strafe"  # "strafe" keeps the heading on the goal; "rotate" fallback
    speed: int = 120  # calibrate: lowest speed that reliably moves on the field floor
    # The EI model reports positions on a grid of ~27 px columns and 20 px rows (96x96 FOMO,
    # 8 px cells, squashed from 320x240); a one-cell ball sits 13 px off x=160, so the band
    # must be wider than that or the robot can never count as centered.
    band_min_px: float = 20.0
    band_frac: float = 0.6  # band also scales with ball radius
    band_exit_scale: float = 1.5  # hysteresis: once centered, stay centered until this wide
    center_ms_per_px: float = 3.0
    pulse_ms_min: int = 80
    pulse_ms_max: int = 400
    forward_ms_far: int = 400  # forward pulse when the ball is small
    forward_ms_near: int = 150  # forward pulse as the ball reaches push distance
    # Distance comes from how low the ball's bottom edge is (rows are stable on the EI grid);
    # radius is a backup cue only. Losing the ball at or past push distance is contact.
    far_bottom_y: float = 100.0  # calibrate: ball bottom when first seen far away
    push_bottom_y: float = 200.0  # calibrate: ball bottom at push standoff
    push_radius_px: float = 60.0  # calibrate: radius that also means push standoff
    push_ms: int = 250
    push_max_pulses: int = 8
    blind_push_pulses: int = 2
    acquire_frames: int = 2
    lost_frames: int = 3
    act_quality: float = 0.35
    enable_search: bool = False
    search_ms: int = 250  # calibrate: keep each step under half the camera FOV
    search_max_pulses: int = 12  # calibrate: about one full turn
    oscillation_max: int = 4
    no_progress_pulses: int = 5
    progress_px: float = 4.0
    progress_radius_px: float = 1.5
    progress_bottom_px: float = 10.0
    wall_stop_mm: int = 0  # off: the forward sensor may see the ball itself; measure first


@dataclass(frozen=True)
class Observation:
    found: bool
    cx: float = 0.0
    radius: float = 0.0
    bottom_y: float = 0.0
    quality: float = 0.0
    ultrasonic_mm: int = -1  # -1 means unknown


@dataclass(frozen=True)
class Memory:
    seen: int = 0  # consecutive certain detections
    lost: int = 0  # consecutive frames without a certain detection
    last_cx: float | None = None
    last_radius: float = 0.0
    last_bottom_y: float = 0.0
    centered: bool = False
    last_turn_sign: int = 0
    flips: int = 0
    stall: int = 0
    best_err: float | None = None
    best_radius: float = 0.0
    best_bottom_y: float = 0.0
    search_pulses: int = 0
    push_pulses: int = 0
    blind_pushes: int = 0


@dataclass(frozen=True)
class Action:
    command: str
    speed: int
    ms: int


@dataclass(frozen=True)
class Decision:
    state: str
    memory: Memory
    action: Action | None
    reason: str
    outcome: str | None = None  # set when the run must end; the loop then calls stop()


def initial_state(params: Params) -> tuple[str, Memory]:
    return SEARCH, Memory()


def clamp_ms(ms: float, params: Params) -> int:
    return int(min(params.pulse_ms_max, max(params.pulse_ms_min, ms)))


def band_px(radius: float, params: Params) -> float:
    return max(params.band_min_px, params.band_frac * radius)


def certain(obs: Observation, params: Params) -> bool:
    return obs.found and obs.quality >= params.act_quality


def closeness(radius: float, bottom_y: float, params: Params) -> float:
    """0 at far_bottom_y, 1 at push standoff, from whichever cue says closer."""
    span = max(1.0, params.push_bottom_y - params.far_bottom_y)
    by_row = (bottom_y - params.far_bottom_y) / span
    return max(0.0, min(1.0, max(by_row, radius / params.push_radius_px)))


def in_contact_zone(memory: Memory, params: Params) -> bool:
    return closeness(memory.last_radius, memory.last_bottom_y, params) >= 1.0


def side_command(sign: int, params: Params) -> str:
    """Move that brings a ball on image side `sign` (+1 right, -1 left) toward target_x."""
    right = sign * params.steer_sign > 0
    if params.center_with == "rotate":
        return "rotate_right" if right else "rotate_left"
    return "right" if right else "left"


def _end(state: str, memory: Memory, reason: str, outcome: str) -> Decision:
    return Decision(state, memory, None, reason, outcome)


def _seen(memory: Memory, obs: Observation) -> Memory:
    return replace(memory, seen=memory.seen + 1, lost=0, last_cx=obs.cx,
                   last_radius=obs.radius, last_bottom_y=obs.bottom_y)


def decide(state: str, memory: Memory, obs: Observation, params: Params) -> Decision:
    wall = 0 < obs.ultrasonic_mm < params.wall_stop_mm
    if wall and state in (APPROACH, PUSH):
        return _end(state, memory, f"wall {obs.ultrasonic_mm}mm", "done")
    if state == SEARCH:
        return _search(memory, obs, params)
    if state == APPROACH:
        return _approach(memory, obs, params)
    if state == PUSH:
        return _push(memory, obs, params)
    raise ValueError(f"unknown state {state!r}")


def _search(memory: Memory, obs: Observation, params: Params) -> Decision:
    if certain(obs, params):
        memory = _seen(memory, obs)
        if memory.seen >= params.acquire_frames:
            return Decision(APPROACH, memory, None, "acquired")
        return Decision(SEARCH, memory, None, "confirming")
    memory = replace(memory, seen=0, lost=memory.lost + 1)
    if not params.enable_search:
        if memory.lost >= params.lost_frames:
            return _end(SEARCH, memory, "no ball at start", "lost")
        return Decision(SEARCH, memory, None, "waiting for ball")
    if memory.search_pulses >= params.search_max_pulses:
        return _end(SEARCH, memory, "search budget used", "search_timeout")
    sign = 1 if memory.last_cx is None or memory.last_cx >= params.target_x else -1
    turn = "rotate_right" if sign * params.steer_sign > 0 else "rotate_left"
    memory = replace(memory, search_pulses=memory.search_pulses + 1)
    return Decision(SEARCH, memory, Action(turn, params.speed, clamp_ms(params.search_ms, params)),
                    "searching")


def _lost(state: str, memory: Memory, params: Params) -> Decision:
    memory = replace(memory, seen=0, lost=memory.lost + 1)
    if memory.lost >= params.lost_frames:
        return _end(state, memory, "ball lost", "lost")
    return Decision(state, memory, None, "ball missing or uncertain; holding")


def _progress(memory: Memory, err: float, obs: Observation, params: Params) -> Memory:
    better = (memory.best_err is None or err <= memory.best_err - params.progress_px
              or obs.radius >= memory.best_radius + params.progress_radius_px
              or obs.bottom_y >= memory.best_bottom_y + params.progress_bottom_px)
    if better:
        best_err = err if memory.best_err is None else min(err, memory.best_err)
        return replace(memory, stall=0, best_err=best_err,
                       best_radius=max(obs.radius, memory.best_radius),
                       best_bottom_y=max(obs.bottom_y, memory.best_bottom_y))
    return replace(memory, stall=memory.stall + 1)


def _approach(memory: Memory, obs: Observation, params: Params) -> Decision:
    if not certain(obs, params):
        if in_contact_zone(memory, params):
            return _push(memory, obs, params)
        return _lost(APPROACH, memory, params)
    memory = _seen(memory, obs)
    err = obs.cx - params.target_x
    memory = _progress(memory, abs(err), obs, params)
    if memory.stall >= params.no_progress_pulses:
        return _end(APPROACH, memory, "error and radius not improving", "no_progress")
    band = band_px(obs.radius, params)
    if memory.centered:
        band *= params.band_exit_scale
    if abs(err) > band:
        return _center(memory, err, params)
    memory = replace(memory, centered=True, last_turn_sign=0, flips=0)
    share = closeness(obs.radius, obs.bottom_y, params)
    if share >= 1.0:
        return Decision(PUSH, memory, None, f"close bottom={obs.bottom_y:.0f} r={obs.radius:.0f}")
    ms = params.forward_ms_far - share * (params.forward_ms_far - params.forward_ms_near)
    return Decision(APPROACH, memory, Action("forward", params.speed, clamp_ms(ms, params)),
                    f"centered err={err:+.0f}")


def _center(memory: Memory, err: float, params: Params) -> Decision:
    sign = 1 if err > 0 else -1
    flips = memory.flips + (1 if memory.last_turn_sign == -sign else 0)
    if flips >= params.oscillation_max:
        return _end(APPROACH, memory, "oscillating around center", "no_progress")
    ms = clamp_ms(abs(err) * params.center_ms_per_px / (2**flips), params)
    memory = replace(memory, centered=False, last_turn_sign=sign, flips=flips)
    return Decision(APPROACH, memory, Action(side_command(sign, params), params.speed, ms),
                    f"centering err={err:+.0f}")


def _push(memory: Memory, obs: Observation, params: Params) -> Decision:
    if memory.push_pulses >= params.push_max_pulses:
        return _end(PUSH, memory, "push budget used", "done")
    if not certain(obs, params):
        if not in_contact_zone(memory, params):
            return _lost(PUSH, memory, params)
        if memory.blind_pushes >= params.blind_push_pulses:
            return _end(PUSH, memory, "blind push budget used", "done")
        memory = replace(memory, blind_pushes=memory.blind_pushes + 1,
                         push_pulses=memory.push_pulses + 1)
        return Decision(PUSH, memory, Action("forward", params.speed, clamp_ms(params.push_ms, params)),
                        f"blind push {memory.blind_pushes}/{params.blind_push_pulses}")
    memory = replace(_seen(memory, obs), push_pulses=memory.push_pulses + 1, blind_pushes=0)
    err = obs.cx - params.target_x
    if abs(err) > band_px(obs.radius, params) * params.band_exit_scale:
        ms = clamp_ms(abs(err) * params.center_ms_per_px / 2, params)
        sign = 1 if err > 0 else -1
        return Decision(PUSH, memory, Action(side_command(sign, params), params.speed, ms),
                        f"push correction err={err:+.0f}")
    return Decision(PUSH, memory, Action("forward", params.speed, clamp_ms(params.push_ms, params)),
                    f"pushing err={err:+.0f}")
