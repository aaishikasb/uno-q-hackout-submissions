import os
import shutil
import time
import types
from pathlib import Path

import cv2
import numpy as np
import requests

from arduino.app_utils import App
from arduino.app_bricks.web_ui import WebUI
from robot_client import MiniAutoRobot
import camera
from camera import _start_camera, get_preview_image

# ===========================================================================
# Tuning. Calibrate these for your chassis, camera angle and lighting.
# x runs 0.0 (left edge) .. 1.0 (right edge); y runs 0.0 (top) .. 1.0 (bottom).
# ===========================================================================

MODE = "play"               # "observe": print detections only, no movement; "play": chase and push
OBSERVE_S = 20              # length of one observe run

BALL_LABEL = "soccerball"   # model labels, compared without underscores ("soccer_ball" also matches)
GOAL_LABEL = "goal"         # if the model has no goal label, the robot skips alignment and pushes straight
MIN_SCORE = 0.75            # ignore model detections below this confidence (real ball scored 0.8-1.0)

CENTER_BAND = 0.12          # ball within 0.5 +/- this counts as centered
SLOW_Y = 0.55               # ball below this line: approach slowly
NEAR_Y = 0.75               # ball below this line: close enough to push
GOAL_BAND = 0.15            # goal and ball x within this counts as aligned
TRACK_GATE = 0.25           # a detection farther than this from the tracked ball is a different object

DRIVE_REVERSED = True       # camera faces the firmware's "backward": swap forward/backward and left/right

TURN_SPEED, TURN_MS = 160, 200          # steering correction pulse
APPROACH_SPEED, APPROACH_MS = 160, 350  # forward pulse while far
SLOW_SPEED, SLOW_MS = 140, 250          # forward pulse while close
STRAFE_SPEED, STRAFE_MS = 140, 200      # sideways pulse for goal alignment
PUSH_SPEED, PUSH_MS = 180, 600          # push pulse once close and aligned
SEARCH_SPEED, SEARCH_MS = 140, 200      # rotate pulse while looking for a lost ball
BACKOFF_SPEED, BACKOFF_MS = 150, 300    # reverse pulse when the ball is too close to see

MAX_PUSHES = 10         # push attempts per run
MAX_BACKOFFS = 2        # reverse pulses to bring a too-close ball back into view
MAX_ALIGN_STEPS = 8     # strafe pulses toward the goal before pushing anyway
MAX_SEARCH_STEPS = 6    # rotate pulses to look for a lost ball before giving up
LOST_FRAMES = 8         # consecutive empty frames before the ball counts as lost
RUN_LIMIT_S = 60        # hard time limit per BOOT press
FRAME_TIMEOUT_S = 3.0   # no new camera frame for this long -> hold still (stale feed)
STALL_GRACE_S = 8.0     # extra wait for the stream to reconnect before ending the run
SETTLE_FRAMES = 1       # frames to discard after a move (may be blurred or old)

# White-ball fallback, used only when no model loads. Tune with the hsv= output.
BALL_LOWER = np.array([0, 0, 170])
BALL_UPPER = np.array([179, 70, 255])
MIN_AREA = 30

# ===========================================================================
# Startup
# ===========================================================================

robot = MiniAutoRobot()


def _wait_for_mcu(attempts: int = 6) -> dict:
    """The MCU can take a while to answer after App Lab re-uploads the sketch."""
    for i in range(1, attempts + 1):
        try:
            return robot.health()
        except Exception as e:
            print(f"[WARN] MCU not answering yet ({i}/{attempts}): {e}")
    raise RuntimeError("MCU never answered: battery OFF, unplug USB, wait 10 s, reconnect, then Run again")


print(f"health   : {_wait_for_mcu()}")
robot.stop()
print(f"sensors  : {robot.read_sensors()}")
print(f"[TEAM] active team: {'BLUE' if robot.hold_toggle() else 'RED'}  (hold CAM button 5 s to switch)")

def _stream_get(url, **kwargs):
    # camera.py opens the stream with no read timeout, so a camera that stops sending
    # blocks its reader thread forever; a read timeout makes it reconnect instead.
    kwargs["timeout"] = (5, 3)
    return requests.get(url, **kwargs)


camera.requests = types.SimpleNamespace(get=_stream_get, exceptions=requests.exceptions)

_start_camera()
print("[INFO] camera thread started")


def _load_model() -> None:
    """Make the .eim executable and start it; fall back to the color detector on failure."""
    if camera.runner is None:
        print("[INFO] no .eim model in python/, using white-color ball detector")
        return
    try:
        path = camera.MODEL_PATH
        try:
            os.chmod(path, path.stat().st_mode | 0o111)
        except OSError:
            # The app folder may be read-only: run a private executable copy instead.
            from edge_impulse_linux.image import ImageImpulseRunner
            copy = Path("/tmp/robocar-model.eim")
            shutil.copyfile(path, copy)
            os.chmod(copy, 0o755)
            camera.runner = ImageImpulseRunner(str(copy))
        info = camera.runner.init()
        labels = info["model_parameters"]["labels"]
        print(f"[INFO] model loaded: {path.name}  labels={labels}")
        if BALL_LABEL not in [label.replace("_", "") for label in labels]:
            print(f"[WARN] '{BALL_LABEL}' is not a model label; set BALL_LABEL to one of {labels}")
    except Exception as e:
        print(f"[WARN] model failed to load ({e}), using white-color ball detector")
        camera.runner = None


_load_model()

_index = Path(__file__).resolve().parent / "index.html"
if _index.exists():
    ui = WebUI(assets_dir_path=_index.parent)
    ui.expose_api("GET", "/preview", get_preview_image)
    print("[INFO] web UI started")

# ===========================================================================
# Perception. Both detectors return {label: [{"x", "y", "score"}, ...]}, best score first.
# ===========================================================================


last_raw: dict = {}  # best score per label in the last frame, including ones below MIN_SCORE


def detect_with_model(frame) -> dict:
    image = np.asarray(frame.convert("RGB"))
    features, cropped = camera.runner.get_features_from_image_auto_studio_settings(image)
    result = camera.runner.classify(features)
    height, width = cropped.shape[:2]

    found = {}
    last_raw.clear()
    for box in result.get("result", {}).get("bounding_boxes", []):
        score = float(box.get("value", 0))
        x = (box["x"] + box["width"] / 2) / width
        y = (box["y"] + box["height"] / 2) / height
        if score > last_raw.get(box["label"], (0.0,))[0]:
            last_raw[box["label"]] = (score, x, y)
        if score < MIN_SCORE:
            continue
        label = box["label"].replace("_", "")
        found.setdefault(label, []).append({"x": x, "y": y, "score": score})
    for candidates in found.values():
        candidates.sort(key=lambda d: d["score"], reverse=True)
    return found


def detect_with_color(frame) -> dict:
    hsv = cv2.cvtColor(np.asarray(frame), cv2.COLOR_RGB2HSV)
    mask = cv2.inRange(hsv, BALL_LOWER, BALL_UPPER)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((9, 9), np.uint8))
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    height, width = hsv.shape[:2]
    best = None
    for c in contours:
        area = cv2.contourArea(c)
        if area < MIN_AREA:
            continue
        (cx, cy), r = cv2.minEnclosingCircle(c)
        roundness = area / (np.pi * r * r) if r > 0 else 0
        if roundness < 0.4:
            continue
        if best is None or area > best[0]:
            best = (area, cx, cy, roundness)

    if best is None:
        return {}
    return {BALL_LABEL: [{"x": best[1] / width, "y": best[2] / height, "score": best[3]}]}


def pick(candidates: list, prev):
    """Choose the ball to chase. While tracking, accept only a candidate near the previous
    position, so a second blob elsewhere cannot steal the target; otherwise take the ball
    nearest the robot, which is the one lowest in the image."""
    if not candidates:
        return None
    if prev is None:
        return max(candidates, key=lambda d: d["y"])
    best = min(candidates, key=lambda d: (d["x"] - prev["x"]) ** 2 + (d["y"] - prev["y"]) ** 2)
    if (best["x"] - prev["x"]) ** 2 + (best["y"] - prev["y"]) ** 2 > TRACK_GATE ** 2:
        return None
    return best


def detect(frame) -> dict:
    if camera.runner is not None:
        return detect_with_model(frame)
    return detect_with_color(frame)


def center_hsv(frame, size=10) -> list:
    hsv = cv2.cvtColor(np.asarray(frame), cv2.COLOR_RGB2HSV)
    h, w = hsv.shape[:2]
    patch = hsv[h // 2 - size:h // 2 + size, w // 2 - size:w // 2 + size].reshape(-1, 3)
    return [int(v) for v in np.median(patch, axis=0)]


def wait_new_frame(prev, skip: int = 0, timeout: float = FRAME_TIMEOUT_S):
    """Return a frame newer than prev, discarding `skip` extra frames first.
    Returns None if no new frame arrives within `timeout` seconds (stalled feed)."""
    frame = prev
    for _ in range(skip + 1):
        deadline = time.monotonic() + timeout
        while True:
            # The camera thread stores a new Image object per frame, so identity means "same frame".
            with camera._image_lock:
                current = camera._current_image
            if current is not None and current is not frame:
                frame = current
                break
            if time.monotonic() > deadline:
                return None
            time.sleep(0.01)
    return frame


# ===========================================================================
# Behavior: observe one fresh frame, make one short move, repeat.
# ===========================================================================


_REVERSE = {"forward": "backward", "backward": "forward", "left": "right", "right": "left"}


def drive(direction: str, speed: int, ms: int) -> None:
    """Drive in camera-relative directions and wait for the move to finish."""
    if DRIVE_REVERSED:
        # Rotation is unaffected: turning right pans the camera right wherever it is mounted.
        direction = _REVERSE.get(direction, direction)
    robot.drive(direction, speed, ms)


def _fmt(obj) -> str:
    return "-" if obj is None else f"x={obj['x']:.2f} y={obj['y']:.2f} s={obj['score']:.2f}"


def _count(seen: dict) -> str:
    n = len(seen.get(BALL_LABEL, []))
    return f"[{n} seen]" if n > 1 else ""


def _is_near_and_centered(ball) -> bool:
    return ball["y"] >= NEAR_Y and abs(ball["x"] - 0.5) <= CENTER_BAND


def _debug(frame) -> str:
    if camera.runner is None:
        return f" | hsv={center_hsv(frame)}"
    raw = ", ".join(f"{k}={s:.2f}@x{x:.2f},y{y:.2f}" for k, (s, x, y) in last_raw.items()) or "none"
    return f" | raw: {raw}"


def observe() -> None:
    """Print what the robot would see and decide, without moving. Use with raised wheels."""
    start = time.monotonic()
    frame = None
    ball = None
    while time.monotonic() - start < OBSERVE_S:
        if not robot.is_running():
            return
        frame = wait_new_frame(frame)
        if frame is None:
            print("[STOP] camera feed stalled")
            return
        try:
            seen = detect(frame)
        except Exception as e:
            print(f"[STOP] detector error: {e}")
            return
        ball = pick(seen.get(BALL_LABEL, []), ball)
        goal = (seen.get(GOAL_LABEL) or [None])[0]
        if ball is None:
            hint = "no ball"
        elif abs(ball["x"] - 0.5) > CENTER_BAND:
            hint = "would steer " + ("rotate_left" if ball["x"] < 0.5 else "rotate_right")
        elif ball["y"] < NEAR_Y:
            hint = "would approach"
        elif goal is not None and abs(goal["x"] - ball["x"]) > GOAL_BAND:
            hint = "would strafe " + ("right" if goal["x"] < ball["x"] else "left")
        else:
            hint = "would push"
        t = time.monotonic() - start
        print(f"[{t:5.1f}s] ball{_count(seen)} {_fmt(ball)} | goal {_fmt(goal)}{_debug(frame)} -> {hint}")
        time.sleep(0.3)


def loop() -> None:
    start = time.monotonic()
    frame = None
    moved = False
    last_ball = None
    missing = 0
    pushes = 0
    align_steps = 0
    search_steps = 0
    backoffs = 0

    while True:
        t = time.monotonic() - start
        if t > RUN_LIMIT_S:
            print("[STOP] time limit reached")
            return
        if not robot.is_running():
            return

        fresh = wait_new_frame(frame, SETTLE_FRAMES if moved else 0)
        if fresh is None:
            # The robot only moves in short timed pulses, so it is already stopped here.
            print(f"[PAUSE] no camera frame for {FRAME_TIMEOUT_S:.0f} s, holding still")
            fresh = wait_new_frame(frame, 0, STALL_GRACE_S)
            if fresh is None:
                print("[STOP] camera feed stalled")
                return
            print("[INFO] camera feed recovered")
        frame = fresh
        moved = False

        try:
            seen = detect(frame)
        except Exception as e:
            print(f"[STOP] detector error: {e}")
            return
        # Stay locked on the tracked ball until it has been missing for LOST_FRAMES frames.
        ball = pick(seen.get(BALL_LABEL, []), last_ball if missing < LOST_FRAMES else None)
        goal = (seen.get(GOAL_LABEL) or [None])[0]
        status = f"[{t:5.1f}s] ball{_count(seen)} {_fmt(ball)} | goal {_fmt(goal)}{_debug(frame)}"

        # --- Ball not visible ---
        if ball is None:
            missing += 1
            if missing < LOST_FRAMES:
                print(f"{status} -> wait ({missing}/{LOST_FRAMES})")
                continue
            if last_ball is not None and _is_near_and_centered(last_ball) and pushes < MAX_PUSHES:
                # Too close for the camera to see: it was dead ahead, so push once.
                pushes += 1
                last_ball = None
                print(f"{status} -> ball below view, blind push {pushes}/{MAX_PUSHES}")
                drive("forward", PUSH_SPEED, PUSH_MS)
                moved = True
                continue
            if last_ball is not None and last_ball["y"] >= NEAR_Y and backoffs < MAX_BACKOFFS:
                # Last seen close but off-center: it is probably just below the view, so back off.
                backoffs += 1
                print(f"{status} -> ball too close to see, back off ({backoffs}/{MAX_BACKOFFS})")
                drive("backward", BACKOFF_SPEED, BACKOFF_MS)
                moved = True
                continue
            if search_steps >= MAX_SEARCH_STEPS:
                print(f"{status} -> ball lost, stopping")
                return
            turn = "rotate_right" if last_ball is not None and last_ball["x"] > 0.5 else "rotate_left"
            search_steps += 1
            print(f"{status} -> search {turn} ({search_steps}/{MAX_SEARCH_STEPS})")
            drive(turn, SEARCH_SPEED, SEARCH_MS)
            moved = True
            continue

        # --- Ball visible ---
        missing = 0
        search_steps = 0
        backoffs = 0
        last_ball = ball
        offset = ball["x"] - 0.5

        if abs(offset) > CENTER_BAND:
            turn = "rotate_left" if offset < 0 else "rotate_right"
            print(f"{status} -> steer {turn}")
            drive(turn, TURN_SPEED, TURN_MS)
        elif ball["y"] < NEAR_Y:
            speed, ms = (SLOW_SPEED, SLOW_MS) if ball["y"] >= SLOW_Y else (APPROACH_SPEED, APPROACH_MS)
            print(f"{status} -> approach")
            drive("forward", speed, ms)
        elif goal is not None and abs(goal["x"] - ball["x"]) > GOAL_BAND and align_steps < MAX_ALIGN_STEPS:
            # Goal left of the ball: shift right so the robot-ball line swings toward it.
            side = "right" if goal["x"] < ball["x"] else "left"
            align_steps += 1
            print(f"{status} -> align with goal, strafe {side} ({align_steps}/{MAX_ALIGN_STEPS})")
            drive(side, STRAFE_SPEED, STRAFE_MS)
        elif pushes < MAX_PUSHES:
            pushes += 1
            print(f"{status} -> push {pushes}/{MAX_PUSHES}")
            drive("forward", PUSH_SPEED, PUSH_MS)
        else:
            print(f"{status} -> max pushes reached, attempt finished")
            return
        moved = True


_routine = observe if MODE == "observe" else loop


def _tick() -> None:
    robot.run_program(_routine)
    # Each idle check is a Bridge + I2C round trip; don't hammer the MCU while waiting for BOOT.
    time.sleep(0.05)


print(f"[INFO] mode={MODE}, waiting for BOOT button to start...")
try:
    App.run(user_loop=_tick)
finally:
    robot.stop()
    if camera.runner is not None:
        camera.runner.stop()
