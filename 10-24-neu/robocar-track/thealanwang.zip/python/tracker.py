"""Keep following the same ball when several are in view.

Other balls (other teams' practice, a spare on the floor) must not steal the
robot's attention, especially when its own ball slides out of view under the
camera. A ball that vanishes is reported missing for a few frames instead of
being swapped for a different one; after that the biggest (nearest) wins.
"""

from __future__ import annotations

import math
from dataclasses import replace

from config import Settings
from observation import Ball, Detections


class BallTracker:
    def __init__(self, cfg: Settings) -> None:
        self.cfg = cfg
        self.last: Ball | None = None
        self.missed = 0

    def moved(self, pulses) -> None:
        """Shift the remembered ball by the robot's own turning: turning right
        by a degree moves everything about camera_px_per_deg pixels left."""
        if self.last is None:
            return
        shift = 0.0
        for direction, speed, ms in pulses:
            if direction.startswith("rotate"):
                deg = self.cfg.turn_deg_per_s_at_200 * (speed / 200) * ms / 1000
                shift += deg if direction == "rotate_left" else -deg
        if shift:
            self.last = replace(self.last, cx=self.last.cx + shift * self.cfg.camera_px_per_deg)

    def update(self, det: Detections) -> Detections:
        candidates = det.balls or ((det.ball,) if det.ball else ())
        pick = None
        if self.last is not None and self.missed < self.cfg.track_hold_frames:
            gate = max(self.cfg.track_gate_px, self.cfg.track_gate_radii * self.last.r)
            near = [c for c in candidates if self._dist(c) <= gate]
            if near:
                pick = min(near, key=self._dist)
        else:
            # Nothing to follow: the nearest ball, which looks biggest, is ours.
            pick = max(candidates, key=lambda c: c.r, default=None)
        if pick is None:
            self.missed += 1
        else:
            self.last, self.missed = pick, 0
        return replace(det, ball=pick)

    def _dist(self, ball: Ball) -> float:
        return math.hypot(ball.cx - self.last.cx, ball.cy - self.last.cy)
