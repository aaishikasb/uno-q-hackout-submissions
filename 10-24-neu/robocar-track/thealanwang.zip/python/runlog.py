"""Per-run console lines, CSV log and annotated frames under data/runs/."""

from __future__ import annotations

import csv
import os
import time
from pathlib import Path

import cv2
import numpy as np

from brain import Action
from config import Settings
from observation import Detections, Observation
from vision import annotate

COLUMNS = ["step", "t", "ball_x", "ball_y", "ball_r", "ball_score", "goal_x0", "goal_x1",
           "goal_y1", "ultrasonic_mm", "frame_age_ms", "detect_ms", "action", "direction",
           "speed", "ms", "reason"]


def describe(obs: Observation) -> str:
    half = obs.width / 2
    parts = []
    if obs.ball:
        b = obs.ball
        parts.append(f"ball x{(b.cx - half) / half:+.2f} y{b.cy / obs.height:.2f} r{b.r:4.1f} q{b.score:.2f}")
    else:
        parts.append("ball --".ljust(32))
    parts.append(f"goal x{(obs.goal.cx - half) / half:+.2f}" if obs.goal else "goal --   ")
    if obs.ultrasonic_mm >= 0:
        parts.append(f"us{obs.ultrasonic_mm}mm")
    return "  ".join(parts)


class RunLog:
    def __init__(self, cfg: Settings, data_dir: Path, label: str) -> None:
        self.cfg = cfg
        self.data_dir = data_dir
        self.dir: Path | None = None
        self._file = None
        self._csv = None
        try:
            self.dir = data_dir / "runs" / f"{time.strftime('%Y%m%d-%H%M%S')}-{label}"
            self.dir.mkdir(parents=True, exist_ok=True)
            self._file = open(self.dir / "decisions.csv", "w", newline="")
            self._csv = csv.writer(self._file)
            self._csv.writerow(COLUMNS)
            print(f"[INFO] logging to {self.dir}")
        except OSError as exc:
            print(f"[WARN] run logging disabled: {exc}")
            self.dir = None

    def step(self, n: int, obs: Observation, det: Detections, action: Action | None,
             image: np.ndarray, frame_age_ms: float, detect_ms: float,
             jpeg: bytes | None = None) -> None:
        verdict = str(action) if action else ""
        print(f"[{obs.t:6.2f}s] #{n:03d} {describe(obs)} -> {verdict}")
        if self._csv is None:
            return
        try:
            b, g = obs.ball, obs.goal
            ball_cols = [f"{b.cx:.1f}", f"{b.cy:.1f}", f"{b.r:.1f}", f"{b.score:.2f}"] if b else [""] * 4
            goal_cols = [f"{g.x0:.0f}", f"{g.x1:.0f}", f"{g.y1:.0f}"] if g else [""] * 3
            action_cols = ([action.kind, action.direction, action.speed, action.ms, action.reason]
                           if action else [""] * 5)
            self._csv.writerow([n, f"{obs.t:.3f}", *ball_cols, *goal_cols, obs.ultrasonic_mm,
                                f"{frame_age_ms:.0f}", f"{detect_ms:.1f}", *action_cols])
            self._file.flush()
            overlay = annotate(image, det, self.cfg, f"#{n} {verdict}")
            if self.cfg.save_frames and n < self.cfg.max_saved_frames:
                cv2.imwrite(str(self.dir / f"{n:04d}.jpg"), overlay)
            if self.cfg.save_raw_frames and jpeg and n < self.cfg.max_saved_frames:
                raw = self.dir / "raw"
                raw.mkdir(exist_ok=True)
                (raw / f"{n:04d}.jpg").write_bytes(jpeg)
            # Write then rename, so tools/live_view.py never serves a half-written file.
            tmp = self.data_dir / "latest.tmp.jpg"
            cv2.imwrite(str(tmp), overlay)
            os.replace(tmp, self.data_dir / "latest.jpg")
        except OSError as exc:
            print(f"[WARN] run logging stopped: {exc}")
            self.close()

    def finish(self, outcome: str) -> None:
        print(f"[RESULT] {outcome}")
        if self.dir is not None:
            try:
                (self.dir / "result.txt").write_text(outcome + "\n")
            except OSError:
                pass
        self.close()

    def close(self) -> None:
        if self._file:
            self._file.close()
        self._file = None
        self._csv = None
