"""Observation -> next action. Pure logic so it can be tested without hardware.

One decision per fresh frame: a short pulse, then look again.

  no ball     -> wait to confirm, creep if it just slid under the camera,
                 then a bounded search spin, then give up
  off-center  -> rotate toward it, pulse length proportional to the error,
                 halved after an overshoot so it settles instead of wobbling
  not lined up with the goal
              -> strafe around the ball (at any distance, while the goal is
                 still in view; remembered if it slides out of frame)
  far         -> forward pulse, shorter as the ball gets closer
  near        -> push
  in the goal -> done
"""

from __future__ import annotations

from dataclasses import dataclass

from config import Settings
from observation import Ball, Goal, Observation


@dataclass(frozen=True)
class Action:
    kind: str              # "move", "wait", "done" or "abort"
    reason: str
    direction: str = ""
    speed: int = 0
    ms: int = 0
    then: tuple = ()       # further (direction, speed, ms) pulses before looking again

    def __str__(self) -> str:
        if self.kind == "move":
            steps = " + ".join(f"{d} {s}/{m}ms" for d, s, m in ((self.direction, self.speed, self.ms),) + self.then)
            return f"{steps} ({self.reason})"
        return f"{self.kind.upper()} ({self.reason})"


def _lerp(a: float, b: float, t: float) -> float:
    return a + (b - a) * min(1.0, max(0.0, t))


def _ramp(value: float, lo: float, hi: float) -> float:
    return 0.0 if hi == lo else min(1.0, max(0.0, (value - lo) / (hi - lo)))


class Brain:
    def __init__(self, cfg: Settings) -> None:
        self.cfg = cfg
        self.reset()

    def reset(self) -> None:
        self.misses = 0
        self.dribbles = 0
        self.blind_pushes = 0
        self.search_steps = 0
        self.orbit_steps = 0
        self.unseen_goal_orbits = 0
        self.pushes = 0
        self.last_closeness = 0.0
        self.last_side = 1  # +1: ball last seen right of center
        self.last_goal_err: float | None = None
        self.last_turn = ""
        self.turn_scale = 1.0
        self.final_push = False
        self.net_turn_ms = 0  # + left, - right: rough heading relative to the start
        # Effort learned from the last move's effect, so a weak battery or a
        # grippy carpet gets longer pulses instead of a robot that barely moves.
        self.turn_boost = 1.0
        self.drive_boost = 1.0
        self.seen_ball = False
        self.unseen_forwards = 0
        self.last_move: tuple[str, float, float] | None = None  # (kind, |err|, radius)

    def decide(self, obs: Observation) -> Action:
        if obs.t >= self.cfg.run_time_limit_s:
            return Action("done", f"time limit {self.cfg.run_time_limit_s:.0f}s")
        if self.final_push:
            return Action("done", "pushed through the goal mouth")
        if obs.ball is None:
            return self._without_ball(obs)
        return self._with_ball(obs, obs.ball)

    def closeness(self, ball: Ball, height: int) -> float:
        """0 = far away, 1 = close enough to push. Uses apparent size and how
        low the ball sits in the frame, whichever says closer."""
        cfg = self.cfg
        by_size = _ramp(ball.r, cfg.far_ball_radius_px, cfg.near_ball_radius_px)
        by_height = _ramp(ball.cy / height, cfg.far_ball_y_frac, cfg.near_ball_y_frac)
        return max(by_size, by_height)

    def _without_ball(self, obs: Observation) -> Action:
        cfg = self.cfg
        self.misses += 1
        if self.misses < cfg.lost_confirm_frames:
            return Action("wait", f"ball missing {self.misses}/{cfg.lost_confirm_frames}")

        us = obs.ultrasonic_mm
        if (cfg.blind_push_mm > 0 and 0 <= us < cfg.blind_push_mm and self.last_closeness >= 1.0
                and self.blind_pushes < cfg.blind_push_max and self.pushes < cfg.max_pushes):
            self.blind_pushes += 1
            self.pushes += 1
            return Action("move", f"push, ball under camera (ultrasonic {us}mm)", "forward",
                          cfg.push_speed, cfg.push_ms)

        if self.last_closeness >= 1.0 and self.dribbles < cfg.dribble_max:
            self.dribbles += 1
            return Action("move", "close ball left the view, creep",
                          "forward", cfg.approach_speed, cfg.dribble_ms)

        if not self.seen_ball and self.unseen_forwards < cfg.unseen_forward_steps:
            # Straight-line start: a ball not seen yet is most likely ahead but
            # too far to make out, so close in before turning away from it.
            self.unseen_forwards += 1
            return Action("move", f"no ball yet, drive ahead {self.unseen_forwards}/{cfg.unseen_forward_steps}",
                          "forward", cfg.approach_speed, cfg.unseen_forward_ms)

        if self.search_steps >= cfg.search_max_steps:
            return Action("abort", "ball lost")
        self.search_steps += 1
        k = self.search_steps
        toward = "rotate_right" if self.last_side > 0 else "rotate_left"
        away = "rotate_left" if toward == "rotate_right" else "rotate_right"
        if k <= cfg.search_zigzag_steps:
            # Widening sweep: 1 unit toward the side the ball was last seen,
            # 2 back, 3 again..., so the area straight ahead is covered first.
            direction, units = (toward if k % 2 else away), k
        else:
            direction, units = toward, 1
        ms = round(cfg.search_turn_ms * units * self.turn_boost)
        self._count_turn(direction, ms)
        return Action("move", f"search {k}/{cfg.search_max_steps}", direction, cfg.turn_speed, ms)

    def _with_ball(self, obs: Observation, ball: Ball) -> Action:
        cfg = self.cfg
        half = obs.width / 2
        err = (ball.cx - half) / half
        closeness = self.closeness(ball, obs.height)
        near = closeness >= 1.0

        self.misses = 0
        self.dribbles = 0
        self.blind_pushes = 0
        self.search_steps = 0
        self.seen_ball = True
        self.last_closeness = closeness
        self.last_side = 1 if err > 0 else -1
        self._learn_effort(abs(err), ball.r)

        goal = obs.goal if obs.goal and self._whole(obs.goal, obs.width) else None
        if self.pushes and goal and not near and self._in_goal(ball, goal):
            # The image cannot tell the last few centimetres; finish with one more push.
            self.final_push = True
            return Action("move", "ball at the goal line, final push", "forward",
                          cfg.push_speed, cfg.final_push_ms)

        band = cfg.center_band_near if near else cfg.center_band
        if abs(err) > band:
            return self._turn(err, band)

        goal_err = self._goal_error(obs, goal, ball, half)
        if (goal_err is not None and abs(goal_err) > cfg.goal_align_band
                and self.orbit_steps < cfg.max_orbit_steps):
            # Goal right of the ball means we must stand further left so the
            # robot, ball and goal fall on one line; a later rotate re-centers.
            self.orbit_steps += 1
            if goal:
                source = ""
            elif self.last_goal_err is not None:
                source = " (remembered)"
            else:
                source = " (start heading)"
            reason = f"orbit goal x{goal_err:+.2f}{source}"
            return self._orbit(goal_err > 0, abs(goal_err), closeness, reason)

        us = obs.ultrasonic_mm
        if not near and cfg.ultrasonic_stop_mm > 0 and 0 <= us < cfg.ultrasonic_stop_mm:
            return Action("abort", f"obstacle at {us}mm")

        if not near:
            ms = _lerp(cfg.approach_far_ms, cfg.approach_near_ms, closeness) * self.drive_boost
            self.last_move = ("drive", abs(err), ball.r)
            boost = f" x{self.drive_boost:.1f}" if self.drive_boost > 1.05 else ""
            return Action("move", f"approach {closeness:.0%}{boost}", "forward", cfg.approach_speed, round(ms))

        if self.last_goal_err is None and not cfg.assume_goal_ahead:
            return Action("abort", "goal not visible")
        if self.pushes >= cfg.max_pushes:
            return Action("done", f"{cfg.max_pushes} pushes used")
        self.pushes += 1
        self.orbit_steps = 0
        if obs.goal and obs.goal.x1 - obs.goal.x0 >= cfg.goal_mouth_frac * obs.width:
            self.final_push = True
            return Action("move", "final push, goal fills the view", "forward",
                          cfg.push_speed, cfg.final_push_ms)
        return Action("move", f"push {self.pushes}/{cfg.max_pushes}", "forward",
                      cfg.push_speed, cfg.push_ms)

    def _orbit(self, go_left: bool, goal_err: float, closeness: float, reason: str) -> Action:
        """Shift sideways around the ball. Mecanum strafing barely moves on
        carpet, so "arc" mode turns ~25 deg and drives: forward while there is
        room, backward when close so the ball is not bumped. Turning left then
        forward, or right then backward, both end up further left."""
        cfg = self.cfg
        if cfg.orbit_mode == "strafe":
            ms = _lerp(cfg.strafe_min_ms, cfg.strafe_max_ms, _ramp(goal_err, cfg.goal_align_band, 1.0))
            return Action("move", reason, "left" if go_left else "right", cfg.strafe_speed, round(ms))
        back_off = closeness >= cfg.orbit_backoff_closeness
        turn = "rotate_left" if go_left != back_off else "rotate_right"
        drive = "backward" if back_off else "forward"
        self._count_turn(turn, cfg.orbit_turn_ms)
        return Action("move", f"{reason}, arc {'back' if back_off else 'fwd'}", turn, cfg.turn_speed,
                      cfg.orbit_turn_ms, then=((drive, cfg.approach_speed, cfg.orbit_drive_ms),))

    def _turn(self, err: float, band: float) -> Action:
        cfg = self.cfg
        direction = "rotate_right" if err > 0 else "rotate_left"
        if self.last_turn and self.last_turn != direction:
            self.turn_scale = max(0.25, self.turn_scale * 0.5)
        elif self.last_turn == direction:
            self.turn_scale = min(1.0, self.turn_scale * 1.5)
        self.last_turn = direction
        ms = round(_lerp(cfg.turn_min_ms, cfg.turn_max_ms, _ramp(abs(err), band, 1.0))
                   * self.turn_scale * self.turn_boost)
        self._count_turn(direction, ms)
        self.last_move = ("turn", abs(err), 0.0)
        boost = f" x{self.turn_boost:.1f}" if self.turn_boost > 1.05 else ""
        return Action("move", f"center ball x{err:+.2f}{boost}", direction, cfg.turn_speed, ms)

    def _learn_effort(self, err: float, radius: float) -> None:
        """Compare the last move's intent with what the camera now shows."""
        cfg = self.cfg
        kind, before_err, before_r = self.last_move or ("", 0.0, 0.0)
        self.last_move = None
        if kind == "turn" and before_err > 0.15:
            moved = err < before_err * 0.5  # a turn sized for the error fixed at least half of it
            self.turn_boost = (max(1.0, self.turn_boost * 0.8) if moved
                               else min(cfg.max_effort_boost, self.turn_boost * 1.5))
        elif kind == "drive":
            moved = radius > before_r * 1.03
            self.drive_boost = (max(1.0, self.drive_boost * 0.8) if moved
                                else min(cfg.max_effort_boost, self.drive_boost * 1.4))

    def _count_turn(self, direction: str, ms: int) -> None:
        self.net_turn_ms += ms if direction == "rotate_left" else -ms

    def _goal_error(self, obs: Observation, goal: Goal | None, ball: Ball, half: float) -> float | None:
        """Goal bearing minus ball bearing, as a fraction of half the frame.
        When the goal slides out of view sideways, keep steering toward the
        side it left from rather than assuming it is straight ahead."""
        if goal is not None:
            self.last_goal_err = (goal.cx - ball.cx) / half
            return self.last_goal_err
        if obs.goal is not None:
            ratio = self._depth_ratio(ball, obs.goal, obs.height)
            if ratio is None or ratio > self.cfg.partial_goal_max_depth_ratio:
                return None  # at the goal mouth: trust the last line-up
            # Goal far behind the ball: a partial goal still tells us its side.
            self.last_goal_err = (obs.goal.cx - ball.cx) / half
            return self.last_goal_err
        last = self.last_goal_err
        if last is None:
            # Never seen: assume it lies in the starting direction, which is
            # to the left of view after turning right overall, and vice versa.
            # Bounded, so a mistuned goal color cannot burn the run orbiting.
            if (self.cfg.goal_enabled and abs(self.net_turn_ms) > self.cfg.unseen_goal_turn_ms
                    and self.unseen_goal_orbits < self.cfg.unseen_goal_max_orbits):
                self.unseen_goal_orbits += 1
                return -1.0 if self.net_turn_ms < 0 else 1.0
            return None
        if abs(last) <= self.cfg.goal_align_band:
            return None
        return 1.0 if last > 0 else -1.0

    def _whole(self, goal: Goal, width: int) -> bool:
        """False when only part of the goal is visible (cut by the frame edge,
        or a single post), since its center would then be misleading."""
        clipped = goal.x0 <= 2 or goal.x1 >= width - 2
        aspect = (goal.x1 - goal.x0) / max(1.0, goal.y1 - goal.y0)
        return (not clipped and aspect >= self.cfg.goal_min_aspect
                and goal.parts >= self.cfg.goal_parts)

    def _depth_ratio(self, ball: Ball, goal: Goal, height: int) -> float | None:
        """Ball distance / goal distance from where each meets the floor in the
        image (farther contact points sit closer to the horizon)."""
        horizon = self.cfg.horizon_y_frac * height
        ball_drop = ball.cy + ball.r - horizon
        goal_drop = goal.y1 - horizon
        if ball_drop <= 0 or goal_drop <= 0:
            return None
        return goal_drop / ball_drop

    def _in_goal(self, ball: Ball, goal: Goal) -> bool:
        # On a flat floor, farther contact points sit higher in the image, so a
        # ball whose bottom is at or above the goal's base has reached the goal.
        between_posts = goal.x0 <= ball.cx <= goal.x1
        reached_line = ball.cy + ball.r <= goal.y1 + self.cfg.score_margin_px
        return between_posts and reached_line
