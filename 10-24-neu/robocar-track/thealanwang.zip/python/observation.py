"""Plain data passed from perception to the decision logic (no OpenCV here)."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Ball:
    cx: float
    cy: float
    r: float
    score: float


@dataclass(frozen=True)
class Goal:
    x0: float
    y0: float
    x1: float
    y1: float
    score: float
    parts: int = 2   # separate blobs merged into this goal, e.g. two cones

    @property
    def cx(self) -> float:
        return (self.x0 + self.x1) / 2


@dataclass(frozen=True)
class Detections:
    ball: Ball | None
    goal: Goal | None
    balls: tuple[Ball, ...] = ()  # every candidate, best first; lets a tracker keep the same ball
    horizon: float | None = None  # image row where the floor ends, found per frame


@dataclass(frozen=True)
class Observation:
    t: float              # seconds since the run started, at frame arrival
    width: int
    height: int
    ball: Ball | None
    goal: Goal | None
    ultrasonic_mm: int = -1  # -1 means unknown
