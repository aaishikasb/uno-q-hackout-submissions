"""All tunable settings in one place.

Edit the defaults here, or override any field in python/tuning.json (written by
tools/tune.py) so calibration travels with the app without code edits.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field, fields, replace
from pathlib import Path

HsvRange = list  # [[h_lo, s_lo, v_lo], [h_hi, s_hi, v_hi]], OpenCV hue 0..179


@dataclass(frozen=True)
class Settings:
    # "play" runs the full routine, "observe" prints detections without moving,
    # "motion_check" makes the single test_* move below, for calibration.
    mode: str = "play"
    test_direction: str = "forward"  # a name from DIRECTIONS, "left,right" for several, or "all"
    test_speed: int = 100
    test_ms: int = 200

    # --- Camera ---------------------------------------------------------------
    camera_url: str = "http://192.168.5.1:81/stream"
    camera_mirrored: bool = False   # True if the image is left/right flipped
    stale_frame_s: float = 1.5      # no new frame for this long ends the run (the robot is
                                    # already stopped between pulses; ESP32 Wi-Fi hiccups ~1 s)
    settle_s: float = 0.15          # frame must arrive this long after a pulse
    settle_frames: int = 2          # and this many frames must be skipped: the ESP32
                                    # keeps 2 buffered frames that may predate the stop

    # --- Detector -------------------------------------------------------------
    # "color" (OpenCV HSV), "eim" (Edge Impulse model only), or "hybrid": the
    # model confirms the ball, color measures it and finds the cone goal.
    # Without a working .eim in python/, hybrid falls back to color at startup.
    detector: str = "hybrid"
    eim_model: str = ""             # relative to python/; "" picks the first *.eim
    eim_ball_label: str = "soccerball"
    eim_goal_label: str = "goal"
    eim_min_score: float = 0.5
    eim_match_px: float = 25.0      # hybrid: model hit to color blob distance (plus radius)
    # hybrid: colour candidates up to this radius are accepted without a model
    # hit. The floor, whiteness and cone checks reject most false blobs, so the
    # default trusts colour whenever the model sees nothing.
    eim_trust_color_below_px: float = 999.0

    # Ranges are OR-ed together, so a red ball can use two ranges around hue 0.
    # Defaults: white soccer ball (bright, low saturation; the gray carpet is
    # darker) and yellow cone goal posts, from a phone photo of the event kit.
    # Retune with the robot camera: its white balance differs.
    ball_hsv: list[HsvRange] = field(default_factory=lambda: [[[0, 0, 190], [179, 110, 255]]])
    # Cones in the robot camera: hue 25-31, saturation 60-85, brightness 200-250;
    # warm walls and desks are more orange, greyer and darker (measured on Q03).
    goal_hsv: list[HsvRange] = field(default_factory=lambda: [[[24, 55, 170], [35, 255, 255]]])
    goal_shape: str = "cones"       # "cones": two upright blobs on the floor; "blob": any goal-coloured area
    cone_min_height_ratio: float = 0.9  # cones are about as tall as wide or taller
    cone_max_taper: float = 0.8     # width at 1/4 height <= this x width at 3/4 (a ball is ~1.0)
    ball_above_horizon_frac: float = 0.04  # ball pixels allowed this far above the horizon
    # Radius / pixels below the horizon for a ball on the floor; measured
    # 0.12-0.35 on Q03. Rejects background clutter near the horizon.
    ball_floor_ratio_min: float = 0.06
    ball_floor_ratio_max: float = 0.45  # strict check: balls 0.12-0.35 with a good horizon
    ball_floor_ratio_relaxed: float = 0.8  # fallback when nothing passes strict; clutter is 3-15
    horizon_tolerance_px: float = 12.0  # horizon estimate error allowed in the fallback
    ball_hough: bool = True         # fall back to circle detection when no blob fits
    ball_max_saturation: float = 55.0  # median saturation of the ball's bright pixels (close cones ~80)
    # Follow the same ball: candidates within this distance of the last one
    # (pixels, or radii of the last ball, whichever is larger) keep the lock;
    # after this many frames without it, the biggest ball in view is taken.
    track_gate_px: float = 90.0
    track_gate_radii: float = 4.0
    track_hold_frames: int = 4
    turn_deg_per_s_at_200: float = 100.0  # Q03 on carpet, from video
    camera_px_per_deg: float = 5.0        # 320 px across a ~62 deg view
    ball_min_area_px: int = 12      # a ball 2 m away is ~25 px; the floor check rejects specks
    ball_min_roundness: float = 0.55
    goal_min_area_px: int = 120

    # --- Decisions ------------------------------------------------------------
    run_time_limit_s: float = 60.0
    center_band: float = 0.12       # |x error| / half-width treated as centered
    center_band_near: float = 0.08  # tighter once the ball is close enough to push
    far_ball_radius_px: float = 10.0
    near_ball_radius_px: float = 36.0
    far_ball_y_frac: float = 0.38   # ball center height / frame height when far
    near_ball_y_frac: float = 0.82  # ... and when ready to push (FOMO has no size)
    lost_confirm_frames: int = 2    # consecutive misses before reacting
    dribble_max: int = 2            # forward creeps after a close ball drops out of view
    search_max_steps: int = 16      # rotation pulses before giving up; 0 stops at once
    search_zigzag_steps: int = 6    # first sweep left/right with growing turns (~+-75 deg)
    unseen_forward_steps: int = 0   # before any ball is seen, drive ahead this many times first
    unseen_forward_ms: int = 400
    assume_goal_ahead: bool = True  # no goal visible: push straight (start layout)
    unseen_goal_turn_ms: int = 300  # net turning after which an unseen goal is sought by orbiting
    unseen_goal_max_orbits: int = 12  # per run; then push straight as if the goal is ahead
    goal_align_band: float = 0.15   # |goal x - ball x| / half-width counted as lined up
    max_orbit_steps: int = 25       # per push, so one bad line-up cannot loop forever
    max_pushes: int = 20
    score_margin_px: float = 6.0
    goal_mouth_frac: float = 0.85   # goal this wide in frame: robot is at the mouth
    goal_min_aspect: float = 0.8    # narrower (width/height) means one post only; 0 disables
    goal_parts: int = 2             # blobs a whole goal shows (two cones); 1 for a one-piece goal
    horizon_y_frac: float = 0.3     # fallback horizon row when it cannot be found in the frame
    auto_horizon: bool = True       # find the floor's edge in every frame (camera tilt changes)
    horizon_min_contrast: float = 25.0  # room vs floor brightness needed to trust that edge
    horizon_threshold: float = 0.65     # fraction of floor-to-room brightness; within 3% on Q03 frames
    model_hit_below_horizon_px: float = 6.0  # model hits closer to the horizon are glare
    partial_goal_max_depth_ratio: float = 0.7  # ball/goal distance above this: at the mouth
    ultrasonic_stop_mm: int = 0     # >0: end the run if something is this close and not the ball
    blind_push_mm: int = 0          # >0: close ball out of view but ultrasonic sees it nearer
                                    # than this -> keep pushing. Only after checking the
                                    # sensor reads the ball reliably (serial command "u")
    blind_push_max: int = 3         # such pushes in a row before trusting the camera again

    # --- Motion (calibrate per chassis, battery and surface) ------------------
    quick_drive: bool = True        # skip the starter's sensor reads around every pulse
    max_effort_boost: float = 3.0   # pulses may stretch up to this when a move had no visible effect
    # Firmware command to send for each intended movement, if the floor test
    # shows a name moves the wrong way, e.g. {"rotate_left": "rotate_right",
    # "rotate_right": "rotate_left"}.
    direction_map: dict[str, str] = field(default_factory=dict)
    turn_speed: int = 200           # Q03 on carpet: ~30 deg per 300 ms at 200; 110 barely turns
    turn_min_ms: int = 60
    turn_max_ms: int = 220
    search_turn_ms: int = 250
    approach_speed: int = 120
    approach_far_ms: int = 400
    approach_near_ms: int = 150
    # Orbiting the ball to line up with the goal. "arc" turns then drives;
    # "strafe" slides sideways, which barely moves on carpet (tested on Q03).
    orbit_mode: str = "arc"
    orbit_turn_ms: int = 200        # ~20 deg at turn_speed 200: ball stays in view
    orbit_drive_ms: int = 300
    orbit_backoff_closeness: float = 0.85  # closer than this: back away instead of forward
    strafe_speed: int = 255
    strafe_min_ms: int = 120
    strafe_max_ms: int = 300
    push_speed: int = 200
    push_ms: int = 500
    final_push_ms: int = 700
    dribble_ms: int = 200

    # --- Logging --------------------------------------------------------------
    save_frames: bool = True
    max_saved_frames: int = 400
    save_raw_frames: bool = False   # also keep the camera's own JPEGs, e.g. as Edge Impulse data

    @property
    def goal_enabled(self) -> bool:
        return self.detector == "eim" or bool(self.goal_hsv)


MODES = ("play", "observe", "motion_check")
DETECTORS = ("color", "eim", "hybrid")
DIRECTIONS = ("forward", "backward", "left", "right", "rotate_left", "rotate_right")


def validate(settings: Settings) -> list[str]:
    """Problems that would otherwise fail silently (the firmware ignores an
    unknown direction) or crash later in the run."""
    problems = []
    if settings.mode not in MODES:
        problems.append(f"mode {settings.mode!r} is not one of {MODES}")
    if settings.orbit_mode not in ("arc", "strafe"):
        problems.append(f"orbit_mode {settings.orbit_mode!r} is not 'arc' or 'strafe'")
    if settings.detector not in DETECTORS:
        problems.append(f"detector {settings.detector!r} is not one of {DETECTORS}")
    if settings.test_direction != "all" and not set(settings.test_direction.split(",")) <= set(DIRECTIONS):
        problems.append(f"test_direction {settings.test_direction!r} must be 'all' or names from {DIRECTIONS}")
    for key, value in settings.direction_map.items():
        if key not in DIRECTIONS or value not in DIRECTIONS:
            problems.append(f"direction_map {key!r}: {value!r} uses a name outside {DIRECTIONS}")
    for name in ("ball_hsv", "goal_hsv"):
        for r in getattr(settings, name):
            if len(r) != 2 or any(len(v) != 3 for v in r):
                problems.append(f"{name} entry {r} should look like [[h, s, v], [h, s, v]]")
    return problems


def load_settings(path: Path | None = None) -> Settings:
    settings = Settings()
    if path is not None and path.exists():
        try:
            overrides = json.loads(path.read_text())
        except json.JSONDecodeError as exc:
            raise SystemExit(f"[ERROR] {path.name} is not valid JSON: {exc}") from None
        known = {f.name for f in fields(Settings)}
        unknown = sorted(set(overrides) - known)
        if unknown:
            print(f"[WARN] {path.name}: ignoring unknown keys {unknown}")
        settings = replace(settings, **{k: v for k, v in overrides.items() if k in known})
        print(f"[INFO] loaded {len(overrides) - len(unknown)} overrides from {path.name}")
    problems = validate(settings)
    if problems:
        raise SystemExit("[ERROR] settings: " + "; ".join(problems))
    return settings
