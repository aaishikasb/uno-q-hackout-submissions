"""Stationary vision check: print soccerball/goal detections, never move.

Only read-only robot calls are used (stop, health, read_sensors); drive,
drive_raw and servo are never called. Bridge RPC latency is probed between
frames because earlier sessions saw intermittent health/stop timeouts.
"""

from __future__ import annotations

import time
from typing import Any, Callable, Optional

from perception import OK, VisionPipeline, VisionResult, format_result


def timed_call(name: str, call: Callable[[], Any], log: Callable[[str], None]) -> tuple[bool, Any]:
    started = time.monotonic()
    try:
        value = call()
    except Exception as error:  # Bridge timeouts surface as exceptions
        log(f"[BRIDGE] {name} FAILED after {(time.monotonic() - started) * 1000:.0f}ms: "
            f"{type(error).__name__}: {error}")
        return False, None
    log(f"[BRIDGE] {name} ok in {(time.monotonic() - started) * 1000:.0f}ms: {value}")
    return True, value


class BridgeProbe:
    """Periodic read_sensors() with latency and failure counts."""

    def __init__(self, robot: Any, *, interval_s: float, log: Callable[[str], None]) -> None:
        self.robot, self.interval_s, self.log = robot, interval_s, log
        self.calls = self.failures = self.consecutive_failures = 0
        self.max_ms = 0.0
        self.last_sensors: Optional[dict] = None
        self._next_at = 0.0

    def maybe_probe(self, now: float) -> None:
        if self.interval_s <= 0 or now < self._next_at:
            return
        self._next_at = now + self.interval_s
        self.calls += 1
        started = time.monotonic()
        try:
            sensors = self.robot.read_sensors()
        except Exception as error:
            elapsed = (time.monotonic() - started) * 1000
            self.failures += 1
            self.consecutive_failures += 1
            self.max_ms = max(self.max_ms, elapsed)
            self.log(f"[BRIDGE] read_sensors FAILED after {elapsed:.0f}ms "
                     f"({self.consecutive_failures} in a row): {type(error).__name__}: {error}")
            return
        elapsed = (time.monotonic() - started) * 1000
        self.consecutive_failures = 0
        self.max_ms = max(self.max_ms, elapsed)
        if elapsed > 500:
            self.log(f"[BRIDGE] read_sensors slow: {elapsed:.0f}ms")
        self.last_sensors = sensors

    def summary(self) -> str:
        return f"bridge calls={self.calls} failures={self.failures} max={self.max_ms:.0f}ms"


class VisionCheck:
    """Call ``step()`` repeatedly (e.g. as App.run's user_loop)."""

    def __init__(
        self,
        pipeline: VisionPipeline,
        *,
        bridge: Optional[BridgeProbe] = None,
        log_every_s: float = 0.2,
        summary_every_s: float = 10.0,
        clock: Callable[[], float] = time.monotonic,
        log: Callable[[str], None] = print,
    ) -> None:
        self.pipeline = pipeline
        self.bridge = bridge
        self.log_every_s = log_every_s
        self.summary_every_s = summary_every_s
        self._clock = clock
        self._log = log
        self._last_status: Optional[str] = None
        self._last_log_at = float("-inf")
        self._window_start = clock()
        self._reset_window()

    def _reset_window(self) -> None:
        self.counts: dict[str, int] = {}
        self.ball_frames = self.goal_frames = 0
        self.infer_ms_total = self.age_ms_total = 0.0

    def step(self) -> VisionResult:
        result = self.pipeline.step()
        self._record(result)
        now = self._clock()
        # A status change always prints; otherwise at most one line per interval.
        if result.status != self._last_status or now - self._last_log_at >= self.log_every_s:
            self._log(format_result(result))
            self._last_log_at = now
        self._last_status = result.status
        if self.bridge is not None:
            self.bridge.maybe_probe(now)
        if now - self._window_start >= self.summary_every_s:
            self._log(self.summary(now))
            self._window_start = now
            self._reset_window()
        return result

    def _record(self, result: VisionResult) -> None:
        self.counts[result.status] = self.counts.get(result.status, 0) + 1
        if result.status == OK:
            self.ball_frames += result.ball is not None
            self.goal_frames += result.goal is not None
            self.infer_ms_total += result.infer_ms or 0.0
            self.age_ms_total += result.frame_age_ms or 0.0

    def summary(self, now: float) -> str:
        span = max(now - self._window_start, 1e-6)
        ok = self.counts.get(OK, 0)
        text = (f"[SUMMARY] {span:.0f}s statuses={self.counts} ok_fps={ok / span:.1f}"
                f" ball={self.ball_frames}/{ok} goal={self.goal_frames}/{ok}")
        if ok:
            text += f" avg_infer={self.infer_ms_total / ok:.0f}ms avg_age={self.age_ms_total / ok:.0f}ms"
        if self.bridge is not None:
            text += " | " + self.bridge.summary()
        return text
