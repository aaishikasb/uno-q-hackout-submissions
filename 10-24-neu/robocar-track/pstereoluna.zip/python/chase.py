"""Minimal ball chase: confirmed fresh FOMO detections -> one short timed pulse.

Safety rules:
- Move only after ``confirm_frames`` consecutive OK frames, all received after
  the previous pulse finished, with the ball in the same zone.
- Every pulse is a timed drive (MCU stops the motors itself). Commands are
  validated by robocar_logic.Decision (speed 1..255, 1..250 ms).
- No ball / stale / error -> send nothing. robot.stop() is NOT used between
  pulses because the sketch's stop RPC also disables the BOOT-started run.
- Run ends after max_run_s or max_pulses; BOOT ends it at any time
  (drive() raises ProgramStopped; is_running() is checked every loop).
No distance, width or path_clear is inferred: the robot only steers toward the
ball and creeps forward when it is centred.
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any, Callable, Optional

from perception.pipeline import OK, VisionResult, format_result, horizontal_zone
from robocar_logic.models import Decision


@dataclass(frozen=True)
class ChaseConfig:
    min_score: float = 0.6
    confirm_frames: int = 2
    center_band: float = 0.3          # cx in 0.35..0.65 counts as centred
    turn_speed: int = 140
    turn_ms: int = 120
    forward_speed: int = 130
    forward_ms: int = 200
    max_pulses: int = 60
    max_run_s: float = 45.0


class ChasePolicy:
    def __init__(self, config: ChaseConfig = ChaseConfig()) -> None:
        self.config = config
        self._zone: Optional[str] = None
        self._streak = 0

    def reset(self) -> None:
        self._zone, self._streak = None, 0

    def update(self, result: VisionResult, motion_end: float) -> Optional[Decision]:
        """Return a pulse to send, or None to hold still."""
        ball = result.ball
        if (result.status != OK or result.received_at is None
                or result.received_at <= motion_end
                or ball is None or ball.score < self.config.min_score):
            self.reset()
            return None
        zone = horizontal_zone(ball.cx, center_band=self.config.center_band)
        self._streak = self._streak + 1 if zone == self._zone else 1
        self._zone = zone
        if self._streak < self.config.confirm_frames:
            return None
        self.reset()  # each pulse needs a fresh confirmation
        c = self.config
        if zone == "LEFT":
            return Decision("rotate_left", c.turn_speed, c.turn_ms, "ball_left")
        if zone == "RIGHT":
            return Decision("rotate_right", c.turn_speed, c.turn_ms, "ball_right")
        return Decision("forward", c.forward_speed, c.forward_ms, "ball_center")


def run_chase(robot: Any, pipeline: Any, policy: ChasePolicy, *,
              clock: Callable[[], float] = time.monotonic,
              log: Callable[[str], None] = print) -> str:
    """Pass (via a lambda) to robot.run_program. Returns why the run ended."""
    config = policy.config
    started = clock()
    motion_end = started
    pulses = 0
    last_hold_log = float("-inf")
    policy.reset()
    log(f"[CHASE] start: {config}")
    while True:
        if clock() - started > config.max_run_s:
            reason = "max_run_time"
            break
        if pulses >= config.max_pulses:
            reason = "max_pulses"
            break
        if not robot.is_running():
            reason = "boot_disabled"
            break
        result = pipeline.step()
        decision = policy.update(result, motion_end)
        if decision is None:
            if clock() - last_hold_log >= 1.0:  # at most one hold line per second
                log(f"[CHASE] hold | {format_result(result)}")
                last_hold_log = clock()
            continue
        pulses += 1
        log(f"[CHASE] pulse {pulses}: {decision.direction} speed={decision.speed} "
            f"ms={decision.ms} ({decision.reason}) | {format_result(result)}")
        robot.drive(decision.direction, speed=decision.speed, ms=decision.ms)
        motion_end = clock()
    log(f"[CHASE] run ended: {reason} after {pulses} pulses")
    return reason
