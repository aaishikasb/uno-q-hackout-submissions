"""BOOT-gated sessions with exception-safe cleanup and state diagnostics.

Replaces MiniAutoRobot.run_program for the chase app (robot_client.py stays the
organizer's file). Differences, each fixing a problem found in run_program:

- Cleanup is exception-safe: a failing stop()/hold_toggle() RPC can no longer
  leave the session flag stuck, and routine errors do not escape App.run.
- A session starts only on a fresh disabled -> enabled edge. run_program starts
  whenever program_enabled is true, so if the start-up or end-of-run stop() RPC
  failed while the MCU was still enabled, the robot would start moving with no
  new BOOT press.
- [BOOT] lines separate "BOOT never reached the MCU" (program_enabled stays
  false), "MCU enabled but not armed", "session started" and "session ended".

Sketch facts this relies on: stop() also disables the run (rpcStop calls
setProgramEnabled(false)); a BOOT press is only visible to Python as
program_enabled in read_sensors().
"""

from __future__ import annotations

import time
from typing import Any, Callable, Optional, Type

WAIT_HINT = ("press the camera BOOT once and wait ~1.2 s for red -> yellow -> green; "
             "a second press during the countdown turns it off again")


class BootGate:
    def __init__(
        self,
        robot: Any,
        *,
        program_stopped: Type[BaseException],
        heartbeat_s: float = 10.0,
        clock: Callable[[], float] = time.monotonic,
        log: Callable[[str], None] = print,
    ) -> None:
        self.robot = robot
        self.program_stopped = program_stopped
        self.heartbeat_s = heartbeat_s
        self._clock = clock
        self._log = log
        self.enabled: Optional[bool] = None   # last observed program_enabled
        self.armed = False                    # saw disabled since start-up / last session
        self.sessions = 0
        self.read_failures = 0
        self.last_end: Optional[str] = None
        self._warned_unarmed = False
        self._next_heartbeat = clock() + heartbeat_s

    def poll(self, routine: Callable[[], Any]) -> bool:
        """Call every loop. Runs routine() once per BOOT start; returns True if it ran."""
        try:
            enabled = bool(self.robot.is_running())
        except Exception as error:
            self.read_failures += 1
            self._log(f"[BOOT] read_sensors failed ({self.read_failures} total): "
                      f"{type(error).__name__}: {error}")
            return False
        if enabled != self.enabled:
            if self.enabled is not None or enabled:
                self._log(f"[BOOT] program_enabled {self.enabled} -> {enabled}"
                          + (" (MCU accepted BOOT, countdown finished)" if enabled else ""))
            self.enabled = enabled
        if not enabled:
            self.armed = True
            self._warned_unarmed = False
            self._heartbeat()
            return False
        if not self.armed:
            if not self._warned_unarmed:
                self._log("[BOOT] program_enabled=True but not armed (no disabled state seen since "
                          "start-up or the last session); not starting. Press BOOT to disable, "
                          "then again to start.")
                self._warned_unarmed = True
            return False
        self._run(routine)
        return True

    def _run(self, routine: Callable[[], Any]) -> None:
        self.armed = False
        self.sessions += 1
        number = self.sessions
        self._log(f"[BOOT] session {number} start")
        reason = "completed"
        try:
            result = routine()
            if isinstance(result, str):
                reason = result
        except self.program_stopped:
            reason = "stopped_by_boot"
        except Exception as error:
            reason = f"error {type(error).__name__}: {error}"
        finally:
            stopped, stop_note = self._safe_stop()
            # An acknowledged stop() ran setProgramEnabled(false) on the MCU, so any
            # later program_enabled=True needs a new BOOT press: safe to re-arm even
            # if the next press lands before our next poll sees the disabled state.
            self.armed = stopped
            self.last_end = reason
            self._log(f"[BOOT] session {number} ended: {reason}; {stop_note}. "
                      "Press BOOT to start again.")
            self._next_heartbeat = self._clock() + self.heartbeat_s

    def _safe_stop(self) -> tuple[bool, str]:
        try:
            acknowledged = bool(self.robot.stop())
        except Exception as error:
            return False, (f"stop() FAILED ({type(error).__name__}: {error}); the MCU may still "
                           "be enabled, motors still have their timed stop")
        return acknowledged, "stop() ok" if acknowledged else "stop() returned False"

    def _heartbeat(self) -> None:
        now = self._clock()
        if now < self._next_heartbeat:
            return
        self._next_heartbeat = now + self.heartbeat_s
        self._log(f"[BOOT] idle: program_enabled=False sessions={self.sessions} "
                  f"last_end={self.last_end} read_failures={self.read_failures}; {WAIT_HINT}")
