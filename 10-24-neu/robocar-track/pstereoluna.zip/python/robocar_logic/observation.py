"""Boundary for a future OpenCV detector; no image or camera dependency here."""

from typing import Protocol

from .models import Detection, Observation, finite_number


class ObservationSource(Protocol):
    def observe(self, *, after: float, timeout_s: float) -> Observation:
        """Return newest frame captured strictly after `after`, or raise.

        Use the runner's monotonic clock and honor the timeout for acquisition AND
        inference. A timestamp assigned after decoding cannot prove source freshness.
        Repeated frames must not receive new capture IDs/times merely to pass checks.
        """
        ...


def detection_from_bbox(
    x: float, y: float, width: float, height: float, confidence: float,
    *, frame_width: int, frame_height: int,
) -> Detection:
    """Convert an OpenCV-style (left, top, width, height) pixel box.

    Detector decides target identity and confidence. Reject rather than clip a
    malformed box; the runner converts detector exceptions into an end-run stop.
    """
    if (type(frame_width) is not int or type(frame_height) is not int
            or frame_width <= 0 or frame_height <= 0):
        raise ValueError("Frame dimensions must be positive integers")
    if not all(finite_number(v) for v in (x, y, width, height, confidence)):
        raise ValueError("Bounding box values must be finite numbers")
    if (width <= 0 or height <= 0 or x < 0 or y < 0
            or x + width > frame_width or y + height > frame_height
            or not 0 <= confidence <= 1):
        raise ValueError("Bounding box must be wholly inside the frame")
    return Detection((x + width / 2) / frame_width, (y + height / 2) / frame_height,
                     width / frame_width, height / frame_height, confidence)
