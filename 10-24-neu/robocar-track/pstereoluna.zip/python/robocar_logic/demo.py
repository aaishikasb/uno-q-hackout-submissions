"""Deterministic offline replay: python -m robocar_logic.demo.

No camera, Arduino runtime, networking, sleeps or physical motor calls.
"""

from dataclasses import asdict
import json

from .controller import DecisionController
from .models import DecisionConfig, Detection, Observation
from .runner import run_decision_loop


class MockClock:
    def __init__(self) -> None:
        self.now = 10.0

    def __call__(self) -> float:
        return self.now


class MockRobot:
    def __init__(self, clock: MockClock) -> None:
        self.clock = clock
        self.enabled = True
        self.drives = []
        self.stop_calls = 0

    def is_running(self) -> bool:
        return self.enabled

    def drive(self, command: str, speed: int, ms: int) -> None:
        self.drives.append((command, speed, ms))
        self.clock.now += ms / 1000.0 + 0.1

    def stop(self) -> bool:
        self.enabled = False
        self.stop_calls += 1
        return True


class MockSource:
    def __init__(self, clock: MockClock, frames: list[dict]) -> None:
        self.clock, self.frames = clock, iter(frames)
        self.frame_id = 0

    def observe(self, *, after: float, timeout_s: float) -> Observation:
        data = next(self.frames)  # Exhaustion is an error, not a scored goal.
        self.clock.now += 0.02
        self.frame_id += 1
        return Observation(self.frame_id, self.clock(), **data)


def target(cx: float = 0.5, width: float = 0.06) -> Detection:
    return Detection(cx, 0.5, width, width, 0.95)


def scenarios() -> dict:
    far = {"ball": target(), "path_clear": True}
    close = {"ball": target(width=0.2), "goal": target(width=0.3), "path_clear": True}
    return {
        "approach_and_attempt": (
            [dict(far, ball=target(0.25)), dict(far, ball=target(0.75)), far,
             dict(far, ball=target(width=0.14)), close, close, close, close, close],
            "attempt_complete",
        ),
        "lost_ball_after_approach": ([far, {"path_clear": True}], "ball_missing"),
        "unaligned_goal": ([dict(close, goal=target(0.75, 0.2))], "alignment_required"),
        "unknown_clearance": ([dict(far, path_clear=None)], "path_unknown"),
    }


def main() -> None:
    print(json.dumps({"kind": "configuration", "calibrated": False,
                      "hardware_connected": False, "config": asdict(DecisionConfig())}))
    for name, (frames, expected) in scenarios().items():
        class TraceController(DecisionController):
            def step(self, observation: Observation, now: float):
                decision = super().step(observation, now)
                print(json.dumps({"scenario": name, "now": round(now, 6),
                                  "observation": asdict(observation), "decision": asdict(decision)}))
                return decision

        clock = MockClock()
        robot = MockRobot(clock)
        outcome = run_decision_loop(robot, MockSource(clock, frames), TraceController(), clock=clock)
        if outcome.reason != expected or robot.stop_calls != 1:
            raise AssertionError(f"Unexpected replay outcome: {name}: {outcome}")
        print(json.dumps({"scenario": name, "kind": "summary", "reason": outcome.reason,
                          "drive_calls_including_holds": len(robot.drives),
                          "stop_calls": robot.stop_calls, "goal_scored": "unverified"}))


if __name__ == "__main__":
    main()
