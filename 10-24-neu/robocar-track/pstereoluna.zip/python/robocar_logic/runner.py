"""Synchronous, hardware-independent adapter for the official robot client.

Call this only from the routine passed to ``robot.run_program``. It deliberately
imports neither Arduino nor a camera library. A source must implement a bounded
read; this adapter detects an overrun when the call returns but cannot interrupt
an arbitrary blocking source. The MCU's timed stop remains essential.
"""

from __future__ import annotations

import math
import time
from typing import Callable, Protocol

from .controller import DecisionController
from .models import Decision
from .observation import ObservationSource


class RobotPort(Protocol):
    """The existing MiniAutoRobot satisfies this interface without modification."""

    def is_running(self) -> bool: ...

    def drive(self, command: str, speed: int, ms: int) -> None: ...

    def stop(self) -> bool: ...


class StopFailed(RuntimeError):
    """The client did not acknowledge the requested end-of-run stop."""


def run_decision_loop(
    robot: RobotPort,
    source: ObservationSource,
    controller: DecisionController,
    *,
    clock: Callable[[], float] = time.monotonic,
    observation_timeout_s: float = 0.5,
) -> Decision:
    """Run one explicitly started session; always attempt a final robot.stop().

    Exactly one blocking drive is dispatched per accepted observation. The next
    observation must have been captured after that drive *returns*, including
    the official client's extra 100 ms wait. Faults end the session. Exceptions,
    including the official ProgramStopped, propagate to its existing lifecycle.
    If both execution and final stop fail, preserve the execution exception and
    attach the stop failure as ``exception.stop_error`` (and a note on 3.11+).
    """
    failure: BaseException | None = None
    last_clock: float | None = None

    def read_clock() -> float:
        nonlocal last_clock
        value = clock()
        if (
            isinstance(value, bool)
            or not isinstance(value, (int, float))
            or not math.isfinite(value)
            or value < 0
            or (last_clock is not None and value < last_clock)
        ):
            raise ValueError("clock must return finite, monotonic, nonnegative seconds")
        last_clock = value
        return value

    try:
        if (
            isinstance(observation_timeout_s, bool)
            or not isinstance(observation_timeout_s, (int, float))
            or not math.isfinite(observation_timeout_s)
            or observation_timeout_s <= 0
        ):
            raise ValueError("observation_timeout_s must be finite and positive")
        after = read_clock()
        controller.start(after)
        while True:
            if not robot.is_running():
                return controller.stop("program_disabled")
            read_started = read_clock()
            observation = source.observe(after=after, timeout_s=observation_timeout_s)
            read_finished = read_clock()
            if read_finished - read_started > observation_timeout_s:
                return controller.stop("observation_timeout")
            if not robot.is_running():
                return controller.stop("program_disabled")
            # Recheck age/runtime after is_running(), since that RPC also takes time.
            decision = controller.step(observation, read_clock())
            if decision.end_run:
                return decision
            # Core validation establishes that captured_at is a finite number.
            if observation.captured_at <= after:
                return controller.stop("pre_motion_frame")
            robot.drive(decision.direction, speed=decision.speed, ms=decision.ms)
            after = read_clock()
    except BaseException as error:
        failure = error
        controller.stop("execution_error")
        raise
    finally:
        try:
            if not robot.stop():
                raise StopFailed("robot.stop() returned a false acknowledgement")
        except BaseException as stop_error:
            if failure is None:
                controller.stop("stop_failed")
                raise
            failure.stop_error = stop_error
            if hasattr(failure, "add_note"):
                failure.add_note(f"Final robot.stop() also failed: {stop_error!r}")
