"""Hardware-free data contracts. Every default is illustrative, NOT calibrated."""

from dataclasses import dataclass, fields
from math import isfinite
from typing import Optional


def finite_number(value: object) -> bool:
    try:
        return type(value) in (int, float) and isfinite(value)
    except OverflowError:
        return False


@dataclass(frozen=True)
class Detection:
    """Full bounding box in normalized [0, 1] image coordinates, not metres."""

    cx: float
    cy: float
    width: float
    height: float
    confidence: float

    def valid(self) -> bool:
        values = (self.cx, self.cy, self.width, self.height, self.confidence)
        if not all(finite_number(v) for v in values):
            return False
        return (
            0 <= self.confidence <= 1
            and 0 < self.width <= 1
            and 0 < self.height <= 1
            and self.width / 2 <= self.cx <= 1 - self.width / 2
            and self.height / 2 <= self.cy <= 1 - self.height / 2
        )


@dataclass(frozen=True)
class Observation:
    """One frame and its safety context; timestamps use the controller's clock.

    path_clear must be established for the intended motion, including lateral
    motion if enabled. None is unknown, never an implicit permission to move.
    Detection instances are deliberately validated by the policy at its boundary.
    """

    frame_id: int
    captured_at: float
    ball: Optional[Detection] = None
    goal: Optional[Detection] = None
    path_clear: Optional[bool] = None
    stream_ok: bool = True
    error: Optional[str] = None


@dataclass(frozen=True)
class Decision:
    direction: str
    speed: int
    ms: int
    reason: str
    end_run: bool = False

    def __post_init__(self) -> None:
        allowed = {"forward", "left", "right", "rotate_left", "rotate_right", "stop"}
        if self.direction not in allowed or not isinstance(self.reason, str) or not self.reason:
            raise ValueError("Unknown direction or empty reason")
        if type(self.end_run) is not bool or type(self.speed) is not int or type(self.ms) is not int:
            raise ValueError("Commands require integer speed/duration and boolean end_run")
        if self.end_run:
            if (self.direction, self.speed, self.ms) != ("stop", 0, 0):
                raise ValueError("End-run decisions must be a terminal stop")
        elif not 1 <= self.ms <= 250:
            raise ValueError("Phase 1 permits only positive pulses up to 250 ms")
        elif self.direction == "stop":
            if self.speed != 0:
                raise ValueError("Hold must have zero speed")
        elif not 1 <= self.speed <= 255:
            raise ValueError("Movement speed must be in 1..255")


@dataclass(frozen=True)
class DecisionConfig:
    min_ball_confidence: float = 0.6
    min_goal_confidence: float = 0.6
    center_deadband: float = 0.08
    goal_alignment_tolerance: float = 0.08
    slow_ball_width: float = 0.10
    close_ball_width: float = 0.18
    max_frame_age_s: float = 0.3
    max_run_s: float = 15.0
    max_speed: int = 120
    turn_speed: int = 80
    approach_speed: int = 100
    near_speed: int = 65
    push_speed: int = 60
    lateral_speed: int = 65
    turn_ms: int = 120
    approach_ms: int = 180
    near_ms: int = 120
    push_ms: int = 120
    lateral_ms: int = 120
    hold_ms: int = 50
    max_pulse_ms: int = 250
    aligned_frames_required: int = 2
    max_push_pulses: int = 2
    max_correction_pulses: int = 8
    allow_lateral_alignment: bool = False

    def __post_init__(self) -> None:
        for field in fields(self):
            name, value = field.name, getattr(self, field.name)
            if name == "allow_lateral_alignment":
                if type(value) is not bool:
                    raise ValueError("allow_lateral_alignment must be boolean")
            elif name.endswith(("_speed", "_ms", "_required", "_pulses")):
                if type(value) is not int or value <= 0:
                    raise ValueError(f"{name} must be a positive integer")
            elif not finite_number(value) or value <= 0:
                raise ValueError(f"{name} must be finite and positive")
        if not 1 <= self.max_speed <= 255 or not 1 <= self.max_pulse_ms <= 250:
            raise ValueError("Speed/duration exceed the phase-1 command envelope")
        for field in fields(self):
            value = getattr(self, field.name)
            if field.name.endswith("_speed") and value > self.max_speed:
                raise ValueError(f"{field.name} exceeds max_speed")
            if field.name.endswith("_ms") and value > self.max_pulse_ms:
                raise ValueError(f"{field.name} exceeds max_pulse_ms")
        if not 0 < self.slow_ball_width < self.close_ball_width <= 1:
            raise ValueError("Require 0 < slow_ball_width < close_ball_width <= 1")
        if not 0 < self.center_deadband < 0.5 or not 0 < self.goal_alignment_tolerance < 0.5:
            raise ValueError("Image deadbands must be between 0 and 0.5")
        if self.min_ball_confidence > 1 or self.min_goal_confidence > 1:
            raise ValueError("Confidence must be in (0, 1]")
        if self.near_speed > self.approach_speed or self.push_speed > self.near_speed:
            raise ValueError("Near/push motion must not accelerate relative to approach")
