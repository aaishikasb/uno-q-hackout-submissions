"""Bounded image-based decision policy; this module never drives a robot."""

from typing import Optional

from .models import Decision, DecisionConfig, Detection, Observation, finite_number


class DecisionController:
    def __init__(self, config: Optional[DecisionConfig] = None) -> None:
        self.config = config if config is not None else DecisionConfig()
        if not isinstance(self.config, DecisionConfig):
            raise ValueError("Expected DecisionConfig")
        self.active = False
        self._terminal = Decision("stop", 0, 0, "not_started", end_run=True)

    def start(self, now: float) -> None:
        """Explicit new run, called only after the official BOOT run gate."""
        if not finite_number(now) or now < 0:
            self.stop("invalid_clock")
            raise ValueError("start requires a nonnegative monotonic timestamp")
        self.active = True
        self._started_at = self._last_now = self._observe_after = now
        self._last_frame_id = -1
        self._last_capture = -1.0
        self._aligned_frames = self._pushes = self._corrections = 0

    def stop(self, reason: str) -> Decision:
        self.active = False
        self._terminal = Decision("stop", 0, 0, reason, end_run=True)
        return self._terminal

    def _emit(self, direction: str, speed: int, ms: int, reason: str, now: float) -> Decision:
        if now + ms / 1000.0 > self._started_at + self.config.max_run_s:
            return self.stop("run_timeout")
        self._observe_after = now + ms / 1000.0
        return Decision(direction, speed, ms, reason)

    def _correct(self, direction: str, lateral: bool, now: float) -> Decision:
        c = self.config
        self._aligned_frames = 0
        if self._corrections >= c.max_correction_pulses:
            return self.stop("correction_budget_exhausted")
        self._corrections += 1
        return self._emit(
            direction,
            c.lateral_speed if lateral else c.turn_speed,
            c.lateral_ms if lateral else c.turn_ms,
            "experimental_goal_reposition" if lateral else "center_ball",
            now,
        )

    def step(self, observation: Observation, now: float) -> Decision:
        """Consume a fresh frame once. Faults latch until an explicit start()."""
        if not self.active:
            return self._terminal
        c = self.config
        if not finite_number(now) or now < self._last_now:
            return self.stop("invalid_clock")
        self._last_now = now
        if now - self._started_at >= c.max_run_s:
            return self.stop("run_timeout")
        if not isinstance(observation, Observation):
            return self.stop("invalid_observation")
        o = observation
        if (
            type(o.stream_ok) is not bool
            or (o.path_clear is not None and type(o.path_clear) is not bool)
            or (o.error is not None and not isinstance(o.error, str))
            or type(o.frame_id) is not int
            or o.frame_id < 0
            or not finite_number(o.captured_at)
            or o.captured_at < 0
        ):
            return self.stop("invalid_observation")
        if not o.stream_ok or o.error is not None:
            return self.stop("perception_error")
        if o.captured_at > now:
            return self.stop("future_frame")
        if now - o.captured_at > c.max_frame_age_s:
            return self.stop("stale_frame")
        if o.frame_id <= self._last_frame_id or o.captured_at <= self._last_capture:
            return self.stop("repeated_or_out_of_order_frame")
        if o.captured_at <= self._observe_after:
            return self.stop("pre_motion_frame")
        self._last_frame_id, self._last_capture = o.frame_id, o.captured_at
        for target in (o.ball, o.goal):
            if target is not None and (not isinstance(target, Detection) or not target.valid()):
                return self.stop("invalid_detection")
        if o.ball is None:
            return self.stop("ball_missing")
        if o.ball.confidence < c.min_ball_confidence:
            return self.stop("ball_uncertain")
        if o.path_clear is not True:
            return self.stop("path_blocked" if o.path_clear is False else "path_unknown")
        if self._pushes >= c.max_push_pulses:
            return self.stop("attempt_complete")

        ball = o.ball
        # Comparing endpoints avoids float subtraction changing deadband inclusivity.
        if ball.cx < 0.5 - c.center_deadband:
            return self._correct("rotate_left", False, now)
        if ball.cx > 0.5 + c.center_deadband:
            return self._correct("rotate_right", False, now)
        if ball.width < c.close_ball_width:
            self._aligned_frames = 0
            near = ball.width >= c.slow_ball_width
            return self._emit("forward", c.near_speed if near else c.approach_speed,
                              c.near_ms if near else c.approach_ms,
                              "approach_slow" if near else "approach", now)

        if o.goal is None:
            return self.stop("goal_missing")
        if o.goal.confidence < c.min_goal_confidence:
            return self.stop("goal_uncertain")
        goal = o.goal
        separation = goal.cx - ball.cx
        aligned = (
            0.5 - c.center_deadband <= goal.cx <= 0.5 + c.center_deadband
            and ball.cx - c.goal_alignment_tolerance <= goal.cx <= ball.cx + c.goal_alignment_tolerance
        )
        if not aligned:
            if not c.allow_lateral_alignment:
                return self.stop("alignment_required")
            # Experimental planar geometry: goal must be BEYOND the ball, image
            # unmirrored, chassis lateral directions calibrated. Goal to right ->
            # move LEFT behind the ball; yaw alone cannot remove bearing separation.
            if abs(separation) < c.goal_alignment_tolerance:
                return self.stop("alignment_ambiguous")
            return self._correct("left" if separation > 0 else "right", True, now)

        self._aligned_frames += 1
        if self._aligned_frames < c.aligned_frames_required:
            return self._emit("stop", 0, c.hold_ms, "confirm_alignment", now)
        self._aligned_frames = 0
        self._pushes += 1
        return self._emit("forward", c.push_speed, c.push_ms, "controlled_push", now)
