"""RoboCar ball chase demo (BOOT-gated) with vision logging while idle.

Short-press camera BOOT to start a run; press again to stop it. While idle the
program only prints detections. Set CHASE_ENABLED = False for vision only.
Robot and sketch files are the organizer's preinstalled versions, unchanged.
"""

import os

from arduino.app_utils import App
from robot_client import MiniAutoRobot, ProgramStopped

from boot import BootGate
from chase import ChaseConfig, ChasePolicy, run_chase
from perception import DEFAULT_MODEL, DEFAULT_URL, MjpegReader, VisionPipeline, load_detector
from vision_check import BridgeProbe, VisionCheck, timed_call

CHASE_ENABLED = True
# Tune here on the field. Pulses are timed by the MCU; max 250 ms each.
CHASE = ChaseConfig(
    min_score=0.6, confirm_frames=2, center_band=0.3,
    turn_speed=140, turn_ms=120, forward_speed=130, forward_ms=200,
    max_pulses=60, max_run_s=45.0,
)

MODEL_PATH = os.environ.get("ROBOCAR_MODEL", DEFAULT_MODEL)
CAMERA_URL = os.environ.get("ROBOCAR_CAMERA_URL", DEFAULT_URL)
MIN_SCORE = float(os.environ.get("ROBOCAR_MIN_SCORE", "0.5"))
MAX_FRAME_AGE_S = float(os.environ.get("ROBOCAR_MAX_FRAME_AGE_S", "0.5"))
LOG_EVERY_S = float(os.environ.get("ROBOCAR_LOG_EVERY_S", "0.2"))
BRIDGE_PROBE_S = float(os.environ.get("ROBOCAR_BRIDGE_PROBE_S", "5"))  # 0 disables

robot = MiniAutoRobot()
print(f"[INFO] RoboCar {'CHASE (press BOOT to start/stop)' if CHASE_ENABLED else 'vision-only'}")
timed_call("stop", robot.stop, print)
timed_call("health", robot.health, print)

runner = reader = None
try:
    runner, detector = load_detector(MODEL_PATH, min_score=MIN_SCORE)
    spec = detector.spec
    project = runner.model_info.get("project", {})
    print(f"[MODEL] {MODEL_PATH} project={project.get('name')}#{project.get('id')} "
          f"v{project.get('deploy_version')} input={spec.width}x{spec.height} "
          f"labels={list(spec.labels)} resize={spec.resize_mode} "
          f"min_score={detector.min_score} decoder={detector.decoder_name}")
    reader = MjpegReader(CAMERA_URL)
    reader.start()
    pipeline = VisionPipeline(reader, detector, max_frame_age_s=MAX_FRAME_AGE_S)
    check = VisionCheck(
        pipeline,
        bridge=BridgeProbe(robot, interval_s=BRIDGE_PROBE_S, log=print),
        log_every_s=LOG_EVERY_S,
    )
    policy = ChasePolicy(CHASE)
    gate = BootGate(robot, program_stopped=ProgramStopped)

    def user_loop() -> None:
        if CHASE_ENABLED:
            # Runs a chase only on a fresh BOOT start; never raises; stops after each run.
            gate.poll(lambda: run_chase(robot, pipeline, policy))
        check.step()  # idle: keep draining frames and printing detections

    App.run(user_loop=user_loop)
finally:
    if reader is not None:
        reader.stop()
    if runner is not None:
        runner.close()
    timed_call("final stop", robot.stop, print)
