"""Background MJPEG reader for the ESP32-S3 camera; keeps only the newest frame.

The official camera firmware sends ``--boundary`` / ``Content-Type`` /
``Content-Length`` parts over chunked HTTP. A daemon thread drains the stream
continuously so the consumer never works through a TCP backlog of old frames.

``received_at`` is the monotonic time the last JPEG byte arrived. The firmware
sends no capture timestamp, so this is an upper bound on freshness, not proof
of capture time: camera-side JPEG conversion and Wi-Fi latency come before it.
"""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass
from typing import BinaryIO, Callable, Iterator, Optional
from urllib.request import urlopen

DEFAULT_URL = "http://192.168.5.1:81/stream"
SOI = b"\xff\xd8"
EOI = b"\xff\xd9"


class StreamFormatError(ValueError):
    """The byte stream is not the multipart MJPEG the firmware produces."""


@dataclass(frozen=True)
class Frame:
    seq: int
    jpeg: bytes
    received_at: float


def _read_exact(stream: BinaryIO, size: int) -> bytes:
    chunks, remaining = [], size
    while remaining > 0:
        chunk = stream.read(remaining)
        if not chunk:
            raise EOFError("stream ended inside a JPEG part")
        chunks.append(chunk)
        remaining -= len(chunk)
    return b"".join(chunks)


def iter_mjpeg_parts(stream: BinaryIO, *, max_bytes: int = 512_000) -> Iterator[bytes]:
    """Yield each part body. Raises EOFError at end of stream and
    StreamFormatError for a part without a usable Content-Length."""
    while True:
        line = stream.readline(1024)
        if not line:
            raise EOFError("stream closed")
        if not line.startswith(b"--"):
            continue
        headers = {}
        while True:
            header = stream.readline(1024)
            if not header:
                raise EOFError("stream closed inside part headers")
            header = header.strip()
            if not header:
                break
            key, _, value = header.partition(b":")
            headers[key.strip().lower()] = value.strip()
        try:
            length = int(headers[b"content-length"])
        except (KeyError, ValueError):
            raise StreamFormatError("MJPEG part without a valid Content-Length") from None
        if not 0 < length <= max_bytes:
            raise StreamFormatError(f"MJPEG part length {length} outside 1..{max_bytes}")
        yield _read_exact(stream, length)


def looks_like_jpeg(data: bytes) -> bool:
    return data.startswith(SOI) and data.rstrip(b"\r\n\x00").endswith(EOI)


class MjpegReader:
    """Reconnecting stream reader. Call start() once, then latest()/wait_for_frame()."""

    def __init__(
        self,
        url: str = DEFAULT_URL,
        *,
        timeout_s: float = 3.0,
        reconnect_delay_s: float = 1.0,
        max_frame_bytes: int = 512_000,
        clock: Callable[[], float] = time.monotonic,
        opener: Callable[..., BinaryIO] = urlopen,
        log: Callable[[str], None] = print,
    ) -> None:
        self.url = url
        self.timeout_s = timeout_s
        self.reconnect_delay_s = reconnect_delay_s
        self.max_frame_bytes = max_frame_bytes
        self._clock = clock
        self._opener = opener
        self._log = log
        self._cond = threading.Condition()
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._latest: Optional[Frame] = None
        self._seq = 0
        self.connects = 0
        self.bad_frames = 0
        self.last_error: Optional[str] = None
        self.connected = False

    def start(self) -> None:
        if self._thread is not None:
            raise RuntimeError("reader already started")
        self._thread = threading.Thread(target=self._run, name="mjpeg-reader", daemon=True)
        self._thread.start()

    def stop(self, join_timeout_s: float = 2.0) -> None:
        self._stop.set()
        with self._cond:
            self._cond.notify_all()
        if self._thread is not None:
            self._thread.join(join_timeout_s)

    def latest(self) -> Optional[Frame]:
        with self._cond:
            return self._latest

    def wait_for_frame(self, *, after_seq: int, timeout_s: float) -> Optional[Frame]:
        """Newest frame with seq > after_seq, or None if none arrives in time."""
        deadline = self._clock() + timeout_s
        with self._cond:
            while self._latest is None or self._latest.seq <= after_seq:
                remaining = deadline - self._clock()
                if remaining <= 0 or self._stop.is_set():
                    return None
                self._cond.wait(remaining)
            return self._latest

    def _publish(self, jpeg: bytes) -> None:
        received_at = self._clock()
        with self._cond:
            self._seq += 1
            self._latest = Frame(self._seq, jpeg, received_at)
            self._cond.notify_all()

    def _run(self) -> None:
        while not self._stop.is_set():
            stream = None
            try:
                self._log(f"[CAMERA] connecting to {self.url}")
                stream = self._opener(self.url, timeout=self.timeout_s)
                content_type = stream.headers.get("Content-Type", "") if hasattr(stream, "headers") else ""
                if content_type and "multipart" not in content_type:
                    raise StreamFormatError(f"unexpected Content-Type {content_type!r}")
                self.connects += 1
                self.connected = True
                self._log(f"[CAMERA] connected ({content_type or 'no content type'})")
                for part in iter_mjpeg_parts(stream, max_bytes=self.max_frame_bytes):
                    if self._stop.is_set():
                        break
                    if looks_like_jpeg(part):
                        self._publish(part)
                    else:
                        self.bad_frames += 1
            except Exception as error:  # network, timeout, EOF, malformed stream
                self.last_error = f"{type(error).__name__}: {error}"
                if not self._stop.is_set():
                    self._log(f"[CAMERA] stream error: {self.last_error}")
            finally:
                self.connected = False
                if stream is not None:
                    try:
                        stream.close()
                    except Exception:
                        pass
            if self._stop.wait(self.reconnect_delay_s):
                break
