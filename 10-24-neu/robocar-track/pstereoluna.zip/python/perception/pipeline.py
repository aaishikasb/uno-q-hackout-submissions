"""One perception step: newest unseen frame -> detections, with explicit failure states.

Never returns a detection for a frame it has already processed, a frame older
than ``max_frame_age_s``, or a frame whose inference failed. Only ``OK``
results carry detections; every other status means "no usable observation".
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Callable, Optional, Protocol

from .detector import DetectResult, FrameDecodeError, VisionDetection
from .mjpeg import Frame

OK = "OK"
NO_FRAME = "NO_FRAME"          # no new frame arrived within the wait budget
STALE = "STALE"                # newest frame (or result) older than allowed
DECODE_ERROR = "DECODE_ERROR"  # JPEG could not be decoded
INFER_ERROR = "INFER_ERROR"    # model process failed, timed out, or bad response


class FrameSource(Protocol):
    def wait_for_frame(self, *, after_seq: int, timeout_s: float) -> Optional[Frame]: ...

    def latest(self) -> Optional[Frame]: ...


class Detector(Protocol):
    def detect(self, jpeg: bytes) -> DetectResult: ...


@dataclass(frozen=True)
class VisionResult:
    status: str
    observed_at: float                 # monotonic time this result was produced
    frame_seq: Optional[int] = None
    received_at: Optional[float] = None
    frame_age_ms: Optional[float] = None   # observed_at - received_at
    preprocess_ms: Optional[float] = None
    infer_ms: Optional[float] = None
    frame_width: Optional[int] = None
    frame_height: Optional[int] = None
    ball: Optional[VisionDetection] = None
    goal: Optional[VisionDetection] = None
    detections: tuple[VisionDetection, ...] = ()
    error: Optional[str] = None


class VisionPipeline:
    def __init__(
        self,
        frames: FrameSource,
        detector: Detector,
        *,
        ball_label: str = "soccerball",
        goal_label: str = "goal",
        max_frame_age_s: float = 0.5,
        wait_timeout_s: float = 1.0,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        self.frames = frames
        self.detector = detector
        self.ball_label = ball_label
        self.goal_label = goal_label
        self.max_frame_age_s = max_frame_age_s
        self.wait_timeout_s = wait_timeout_s
        self._clock = clock
        self._last_seq = 0

    def step(self) -> VisionResult:
        frame = self.frames.wait_for_frame(after_seq=self._last_seq, timeout_s=self.wait_timeout_s)
        if frame is None:
            now = self._clock()
            latest = self.frames.latest()
            age = None if latest is None else (now - latest.received_at) * 1000
            return VisionResult(NO_FRAME, now, frame_age_ms=age,
                                error="no new camera frame" if latest else "no camera frame yet")
        self._last_seq = frame.seq
        base = dict(frame_seq=frame.seq, received_at=frame.received_at)

        now = self._clock()
        if now - frame.received_at > self.max_frame_age_s:
            return VisionResult(STALE, now, frame_age_ms=(now - frame.received_at) * 1000,
                                error="frame too old before inference", **base)
        try:
            result = self.detector.detect(frame.jpeg)
        except Exception as error:
            now = self._clock()
            status = DECODE_ERROR if isinstance(error, FrameDecodeError) else INFER_ERROR
            return VisionResult(status, now, frame_age_ms=(now - frame.received_at) * 1000,
                                error=f"{type(error).__name__}: {error}", **base)

        now = self._clock()
        age_ms = (now - frame.received_at) * 1000
        timing = dict(preprocess_ms=result.preprocess_ms, infer_ms=result.infer_ms,
                      frame_width=result.frame_width, frame_height=result.frame_height)
        if now - frame.received_at > self.max_frame_age_s:
            return VisionResult(STALE, now, frame_age_ms=age_ms,
                                error="frame too old after inference", **base, **timing)
        return VisionResult(
            OK, now, frame_age_ms=age_ms,
            ball=result.best(self.ball_label),
            goal=result.best(self.goal_label),
            detections=result.detections,
            **base, **timing,
        )


def horizontal_zone(cx: float, *, center_band: float = 0.2) -> str:
    """LEFT / CENTER / RIGHT using a centred band of total width ``center_band``."""
    if cx < 0.5 - center_band / 2:
        return "LEFT"
    if cx > 0.5 + center_band / 2:
        return "RIGHT"
    return "CENTER"


def _fmt_det(det: Optional[VisionDetection], width: Optional[int], height: Optional[int]) -> str:
    if det is None:
        return "none"
    px = f" px=({det.cx * width:.0f},{det.cy * height:.0f})" if width and height else ""
    return (f"{horizontal_zone(det.cx)} cx={det.cx:.2f} cy={det.cy:.2f}{px} "
            f"score={det.score:.2f} cells={det.cell_w:.2f}x{det.cell_h:.2f}")


def format_result(result: VisionResult) -> str:
    seq = f"#{result.frame_seq}" if result.frame_seq is not None else "#-"
    age = f" age={result.frame_age_ms:.0f}ms" if result.frame_age_ms is not None else ""
    if result.status != OK:
        return f"[VISION] {seq} {result.status}{age} t={result.observed_at:.3f} error={result.error}"
    extra = len(result.detections) - (result.ball is not None) - (result.goal is not None)
    return (
        f"[VISION] {seq} OK{age} pre={result.preprocess_ms:.0f}ms infer={result.infer_ms:.0f}ms "
        f"t={result.observed_at:.3f} | ball: {_fmt_det(result.ball, result.frame_width, result.frame_height)}"
        f" | goal: {_fmt_det(result.goal, result.frame_width, result.frame_height)}"
        + (f" | +{extra} more" if extra > 0 else "")
    )
