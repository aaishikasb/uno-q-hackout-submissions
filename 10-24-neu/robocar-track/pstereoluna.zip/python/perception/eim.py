"""Minimal client for an Edge Impulse Linux ``.eim`` model.

The ``.eim`` binary is the Edge Impulse runtime: it listens on a Unix socket
and speaks JSON messages terminated by a NUL byte. ``edge_impulse_linux``'s
ImpulseRunner speaks the same protocol, but importing that package also imports
OpenCV and PyAudio (it calls ``exit(1)`` without OpenCV), waits forever if the
binary dies during start-up, and has no read timeout in shared-memory mode.
UNO Q loses Internet once it joins the camera access point, so this client uses
only the standard library and bounds every wait.
"""

from __future__ import annotations

import json
import os
import shutil
import socket
import stat
import subprocess
import tempfile
import time
from typing import Any, Optional, Sequence


class EimError(RuntimeError):
    """The model process failed, timed out, or returned an error."""


def _ensure_executable(model_path: str, scratch_dir: str) -> str:
    """App Lab uploads may drop the exec bit; fix it in place or use a copy."""
    if not os.path.isfile(model_path):
        raise EimError(f"model file not found: {model_path}")
    if os.access(model_path, os.X_OK):
        return model_path
    try:
        os.chmod(model_path, os.stat(model_path).st_mode | stat.S_IXUSR)
        if os.access(model_path, os.X_OK):
            return model_path
    except OSError:
        pass
    copy = os.path.join(scratch_dir, os.path.basename(model_path))
    shutil.copyfile(model_path, copy)
    os.chmod(copy, 0o700)
    return copy


class EimRunner:
    def __init__(
        self,
        model_path: str,
        *,
        timeout_s: float = 2.0,
        startup_timeout_s: float = 20.0,
        max_response_bytes: int = 1_000_000,
    ) -> None:
        # Absolute, so Popen never searches PATH for a bare file name.
        self.model_path = os.path.abspath(model_path)
        self.timeout_s = timeout_s
        self.startup_timeout_s = startup_timeout_s
        self.max_response_bytes = max_response_bytes
        self.model_info: Optional[dict[str, Any]] = None
        self._tempdir: Optional[str] = None
        self._process: Optional[subprocess.Popen] = None
        self._sock: Optional[socket.socket] = None
        self._msg_id = 0

    def start(self) -> dict[str, Any]:
        """Launch the model and return its ``hello`` response."""
        if self._process is not None:
            raise EimError("runner already started")
        self._tempdir = tempfile.mkdtemp(prefix="eim-")
        try:
            executable = _ensure_executable(self.model_path, self._tempdir)
            socket_path = os.path.join(self._tempdir, "runner.sock")
            try:
                self._process = subprocess.Popen(
                    [executable, socket_path],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                )
            except OSError as error:  # e.g. wrong architecture: Exec format error
                raise EimError(f"cannot launch model: {error}") from error
            deadline = time.monotonic() + self.startup_timeout_s
            while not os.path.exists(socket_path):
                if self._process.poll() is not None:
                    raise EimError(f"model exited during start-up (code {self._process.returncode})")
                if time.monotonic() > deadline:
                    raise EimError("model did not open its socket in time")
                time.sleep(0.05)
            self._sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            self._sock.settimeout(self.timeout_s)
            self._sock.connect(socket_path)
            self.model_info = self._send({"hello": 1})
            return self.model_info
        except BaseException:
            self.close()
            raise

    def classify(self, features: Sequence[int]) -> dict[str, Any]:
        return self._send({"classify": list(features)})

    def close(self) -> None:
        if self._sock is not None:
            try:
                self._sock.close()
            finally:
                self._sock = None
        if self._process is not None:
            if self._process.poll() is None:
                self._process.terminate()
                try:
                    self._process.wait(timeout=2)
                except subprocess.TimeoutExpired:
                    self._process.kill()
            self._process = None
        if self._tempdir is not None:
            shutil.rmtree(self._tempdir, ignore_errors=True)
            self._tempdir = None

    def _send(self, message: dict[str, Any]) -> dict[str, Any]:
        if self._sock is None:
            raise EimError("runner is not started")
        self._msg_id += 1
        message = dict(message, id=self._msg_id)
        try:
            self._sock.sendall(json.dumps(message).encode("utf-8"))
            data = bytearray()
            while not data.endswith(b"\x00"):
                chunk = self._sock.recv(65536)
                if not chunk:
                    raise EimError("model closed the socket")
                data += chunk
                if len(data) > self.max_response_bytes:
                    raise EimError("model response too large")
        except OSError as error:  # includes socket.timeout
            self.close()
            raise EimError(f"model I/O failed: {type(error).__name__}: {error}") from error
        try:
            response = json.loads(bytes(data[:-1]).decode("utf-8"))
        except ValueError as error:
            raise EimError("model returned malformed JSON") from error
        if response.get("id") != self._msg_id:
            raise EimError(f"response id {response.get('id')!r} != {self._msg_id}")
        if not response.get("success"):
            raise EimError(f"model error: {response.get('error', 'unknown')}")
        return response

    def __enter__(self) -> "EimRunner":
        self.start()
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()
