"""Camera + Edge Impulse FOMO perception. Importing this never touches motors."""

from __future__ import annotations

import os
from typing import Optional

from .detector import FomoDetector, ModelSpec, VisionDetection
from .eim import EimError, EimRunner
from .mjpeg import DEFAULT_URL, Frame, MjpegReader
from .pipeline import (DECODE_ERROR, INFER_ERROR, NO_FRAME, OK, STALE, VisionPipeline,
                       VisionResult, format_result, horizontal_zone)

DEFAULT_MODEL = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                             "soccer_fomo.eim")

__all__ = [
    "DECODE_ERROR", "DEFAULT_MODEL", "DEFAULT_URL", "EimError", "EimRunner", "FomoDetector",
    "Frame", "INFER_ERROR", "MjpegReader", "ModelSpec", "NO_FRAME", "OK", "STALE",
    "VisionDetection", "VisionPipeline", "VisionResult", "format_result", "horizontal_zone",
    "load_detector",
]


def load_detector(model_path: str = DEFAULT_MODEL, *, min_score: Optional[float] = None,
                  timeout_s: float = 2.0) -> tuple[EimRunner, FomoDetector]:
    """Start the model process and wrap it. Caller must close the runner."""
    runner = EimRunner(model_path, timeout_s=timeout_s)
    info = runner.start()
    try:
        detector = FomoDetector(runner, ModelSpec.from_model_info(info), min_score=min_score)
    except BaseException:
        runner.close()
        raise
    return runner, detector
