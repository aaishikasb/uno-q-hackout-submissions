"""JPEG -> model features -> FOMO detections, matching the trained impulse.

Impulse: 96x96 RGB input, resize mode "squash" (no crop, no letterbox). Squash
keeps normalized coordinates identical between the model input and the original
frame, so a detection centre at 0.25 of the 96 px input is 0.25 of 320 px too.

FOMO predicts a coarse grid of object centroids (8 px cells at 96 px input).
Its "bounding box" is the extent of the activated cells, which is NOT the
object's real outline. It is reported as ``cell_w``/``cell_h`` and must not be
fed into logic that expects a true object width.
"""

from __future__ import annotations

import io
import time
from dataclasses import dataclass
from typing import Any, Callable, Optional, Protocol, Sequence


class FrameDecodeError(ValueError):
    """The JPEG could not be decoded; the model was not called."""


class Classifier(Protocol):
    def classify(self, features: Sequence[int]) -> dict[str, Any]: ...


@dataclass(frozen=True)
class ModelSpec:
    width: int
    height: int
    labels: tuple[str, ...]
    resize_mode: str
    min_score: float

    @classmethod
    def from_model_info(cls, info: dict[str, Any]) -> "ModelSpec":
        params = info["model_parameters"]
        model_type = params.get("model_type")
        if model_type not in ("constrained_object_detection", "object_detection"):
            raise ValueError(f"expected an object detection model, got {model_type!r}")
        if params.get("image_channel_count") != 3:
            raise ValueError("expected an RGB model (3 channels)")
        mode = params.get("image_resize_mode", "squash")
        if mode != "squash":
            raise ValueError(f"preprocessing implements squash only, model uses {mode!r}")
        thresholds = [t.get("min_score") for t in params.get("thresholds", [])
                      if t.get("type") == "object_detection"]
        return cls(
            width=int(params["image_input_width"]),
            height=int(params["image_input_height"]),
            labels=tuple(params["labels"]),
            resize_mode=mode,
            min_score=float(thresholds[0]) if thresholds else 0.5,
        )


@dataclass(frozen=True)
class VisionDetection:
    label: str
    score: float
    cx: float       # normalized 0..1 in the original frame
    cy: float
    cell_w: float   # normalized FOMO cell-cluster extent; not an object size
    cell_h: float


@dataclass(frozen=True)
class DetectResult:
    detections: tuple[VisionDetection, ...]
    frame_width: int
    frame_height: int
    preprocess_ms: float
    infer_ms: float

    def best(self, label: str) -> Optional[VisionDetection]:
        matches = [d for d in self.detections if d.label == label]
        return max(matches, key=lambda d: d.score) if matches else None


def _decode_resize_pil(jpeg: bytes, size: tuple[int, int]) -> tuple[bytes, int, int]:
    from PIL import Image

    with Image.open(io.BytesIO(jpeg)) as image:
        image.load()
        frame_w, frame_h = image.size
        rgb = image.convert("RGB")
    # BOX is area averaging, the PIL equivalent of OpenCV INTER_AREA used by the SDK.
    return rgb.resize(size, Image.Resampling.BOX).tobytes(), frame_w, frame_h


def _decode_resize_cv2(jpeg: bytes, size: tuple[int, int]) -> tuple[bytes, int, int]:
    import cv2
    import numpy as np

    bgr = cv2.imdecode(np.frombuffer(jpeg, dtype=np.uint8), cv2.IMREAD_COLOR)
    if bgr is None:
        raise ValueError("cv2 could not decode JPEG")
    frame_h, frame_w = bgr.shape[:2]
    rgb = cv2.cvtColor(cv2.resize(bgr, size, interpolation=cv2.INTER_AREA), cv2.COLOR_BGR2RGB)
    return rgb.tobytes(), frame_w, frame_h


def pick_decoder(preferred: str = "auto") -> tuple[str, Callable[[bytes, tuple[int, int]], tuple[bytes, int, int]]]:
    """Return (name, decoder). OpenCV first: its INTER_AREA output is pixel-identical
    to the official edge_impulse_linux SDK. Pillow BOX decodes identically but its
    320->96 resize differs at sharp edges (measured mean 0.2, max 53 levels)."""
    options = {"pil": ("PIL", _decode_resize_pil), "cv2": ("cv2", _decode_resize_cv2)}
    order = ["cv2", "pil"] if preferred == "auto" else [preferred]
    errors = []
    for key in order:
        module = options[key][0]
        try:
            __import__(module)
            return key, options[key][1]
        except ImportError as error:
            errors.append(f"{module}: {error}")
    raise ImportError("no JPEG decoder available (install opencv-python-headless or pillow): "
                      + "; ".join(errors))


def rgb_to_features(rgb: bytes) -> list[int]:
    """Pack RGB888 bytes as 0xRRGGBB integers, the Edge Impulse image format."""
    return [int.from_bytes(rgb[i:i + 3], "big") for i in range(0, len(rgb), 3)]


def parse_bounding_boxes(response: dict[str, Any], spec: ModelSpec, min_score: float) -> tuple[VisionDetection, ...]:
    boxes = response.get("result", {}).get("bounding_boxes")
    if not isinstance(boxes, list):
        raise ValueError("model response has no bounding_boxes list")
    detections = []
    for box in boxes:
        label, score = box["label"], float(box["value"])
        if label not in spec.labels:
            raise ValueError(f"unknown label {label!r}")
        if score < min_score:
            continue
        x, y = float(box["x"]), float(box["y"])
        w, h = float(box["width"]), float(box["height"])
        if w <= 0 or h <= 0 or x < 0 or y < 0 or x + w > spec.width or y + h > spec.height:
            raise ValueError(f"box outside model input: {box}")
        detections.append(VisionDetection(
            label=label,
            score=score,
            cx=(x + w / 2) / spec.width,
            cy=(y + h / 2) / spec.height,
            cell_w=w / spec.width,
            cell_h=h / spec.height,
        ))
    return tuple(sorted(detections, key=lambda d: -d.score))


class FomoDetector:
    def __init__(
        self,
        classifier: Classifier,
        spec: ModelSpec,
        *,
        min_score: Optional[float] = None,
        decoder: str = "auto",
        clock: Callable[[], float] = time.perf_counter,
    ) -> None:
        self.classifier = classifier
        self.spec = spec
        self.min_score = spec.min_score if min_score is None else min_score
        self.decoder_name, self._decode = pick_decoder(decoder)
        self._clock = clock

    def preprocess(self, jpeg: bytes) -> tuple[list[int], int, int]:
        try:
            rgb, frame_w, frame_h = self._decode(jpeg, (self.spec.width, self.spec.height))
        except Exception as error:  # PIL raises OSError/SyntaxError/ValueError variants
            raise FrameDecodeError(f"{type(error).__name__}: {error}") from error
        return rgb_to_features(rgb), frame_w, frame_h

    def detect(self, jpeg: bytes) -> DetectResult:
        t0 = self._clock()
        features, frame_w, frame_h = self.preprocess(jpeg)
        t1 = self._clock()
        response = self.classifier.classify(features)
        t2 = self._clock()
        return DetectResult(
            detections=parse_bounding_boxes(response, self.spec, self.min_score),
            frame_width=frame_w,
            frame_height=frame_h,
            preprocess_ms=(t1 - t0) * 1000,
            infer_ms=(t2 - t1) * 1000,
        )
