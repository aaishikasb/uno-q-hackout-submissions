"""Stand-alone perception probe: no Arduino imports, never drives motors.

Live camera (UNO Q over SSH, or a Linux arm64 container on a Mac joined to the
camera Wi-Fi):
    python3 -m perception.probe --model soccer_fomo.eim --seconds 30
Saved JPEG files:
    python3 -m perception.probe --model soccer_fomo.eim --image a.jpg b.jpg
Run from the ``python/`` directory (or set PYTHONPATH to it).
"""

from __future__ import annotations

import argparse
import json
import sys
import time

from . import DEFAULT_MODEL, DEFAULT_URL, MjpegReader, VisionPipeline, format_result, load_detector
from .pipeline import OK, horizontal_zone


def _describe(det):
    if det is None:
        return None
    return {"zone": horizontal_zone(det.cx), "cx": round(det.cx, 3), "cy": round(det.cy, 3),
            "score": round(det.score, 3), "cell_w": round(det.cell_w, 3), "cell_h": round(det.cell_h, 3)}


def run_images(detector, paths):
    for path in paths:
        with open(path, "rb") as handle:
            result = detector.detect(handle.read())
        record = {
            "image": path, "frame": f"{result.frame_width}x{result.frame_height}",
            "infer_ms": round(result.infer_ms, 1),
            "ball": _describe(result.best("soccerball")), "goal": _describe(result.best("goal")),
            "all": [dict(label=d.label, **_describe(d)) for d in result.detections],
        }
        print(json.dumps(record))


def run_live(detector, args):
    reader = MjpegReader(args.url)
    reader.start()
    pipeline = VisionPipeline(reader, detector, max_frame_age_s=args.max_age)
    counts, deadline = {}, time.monotonic() + args.seconds
    try:
        while time.monotonic() < deadline:
            result = pipeline.step()
            counts[result.status] = counts.get(result.status, 0) + 1
            print(format_result(result), flush=True)
    finally:
        reader.stop()
    ok = counts.get(OK, 0)
    print(f"[SUMMARY] {args.seconds:.0f}s statuses={counts} ok_fps={ok / args.seconds:.1f} "
          f"reconnects={max(reader.connects - 1, 0)} bad_frames={reader.bad_frames}")


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--model", default=DEFAULT_MODEL)
    parser.add_argument("--url", default=DEFAULT_URL)
    parser.add_argument("--image", nargs="+", help="classify these JPEG files instead of the stream")
    parser.add_argument("--seconds", type=float, default=20.0)
    parser.add_argument("--max-age", type=float, default=0.5, help="stale-frame limit in seconds")
    parser.add_argument("--min-score", type=float, default=None)
    args = parser.parse_args(argv)

    runner, detector = load_detector(args.model, min_score=args.min_score)
    try:
        spec = detector.spec
        print(f"[MODEL] {args.model} input={spec.width}x{spec.height} labels={list(spec.labels)} "
              f"resize={spec.resize_mode} min_score={detector.min_score} decoder={detector.decoder_name}",
              file=sys.stderr)
        if args.image:
            run_images(detector, args.image)
        else:
            run_live(detector, args)
    finally:
        runner.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
