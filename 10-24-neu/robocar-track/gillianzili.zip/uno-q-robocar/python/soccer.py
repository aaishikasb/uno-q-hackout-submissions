"""Pulse-and-observe ball chasing: look, make one short move, look again.

The camera delivers only ~1-2 fresh frames per second, so the robot never
drives "while watching". Every decision uses a frame that arrived AFTER the
previous move finished.

Why drive_raw: the firmware's named commands scale power down (forward runs
the wheels at ~71% of the requested speed, rotate_* at only 50%). drive_raw
sends each wheel's power directly (-255..255), which is both faster and
allows car-like arcs: one side faster than the other.

Wheel layout, derived from the sketch's velocityController:
  rotate_left = M0,M3 forward and M1,M2 backward  -> M0,M3 right side, M1,M2 left side
  strafe left = M0+, M1-, M2+, M3-                 -> M0 front-right, M3 rear-right,
                                                     M1 front-left,  M2 rear-left
Verify with MODE=wheels (wheels raised) before driving on the floor.
"""
import time
from pathlib import Path

from robot_client import ProgramStopped

# Every key that robot_config.txt may set, with its default and type.
DEFAULTS = {
    "MODE": "vision",          # vision | match | wheels
    "DRY_RUN": 1,              # 1 = print actions but never move the motors
    "RUN_SECONDS": 60,         # hard time limit for one BOOT press
    "VISION_SECONDS": 60,
    "CENTER_BAND_PX": 30,      # |offset| below this counts as centered
    "FAR_Y": 90,               # y below this: ball is far, take bigger steps
    "NEAR_Y": 150,             # y at/above this: ball is close, push
    "STRAFE_Y": 130,           # off-center and y at/above this: slide sideways
    "STRAFE_MAX_OFF_PX": 80,   # ...but only for small offsets; bigger ones still turn
    "PUSH_MAX_OFF_PX": 45,     # blind push only if the ball was roughly centered when lost
    "SPIN_OFF_PX": 110,        # far ball offset beyond this: spin in place instead of arcing
    # Wheel power, 0-255 (drive_raw sends this straight to the wheels)
    "FWD_POWER": 170,
    "SPIN_POWER": 170,
    "STRAFE_POWER": 180,
    "PUSH_POWER": 255,
    "ARC_BASE": 150,           # forward power while arcing
    "ARC_GAIN": 0.8,           # extra/less power per pixel of offset on each side
    "ARC_TURN_MAX": 120,
    "ARC_INVERT": 0,           # set 1 if arcs turn the wrong way
    # Pulse lengths, ms (never 0: the firmware treats 0 as "run forever")
    "ARC_MS": 300,
    "TURN_MS_PER_PX": 0.8,     # spin pulse per pixel of offset
    "TURN_MS_MIN": 100,
    "TURN_MS_MAX": 300,
    "STRAFE_MS": 200,
    "FWD_MS_FAR": 400,
    "FWD_MS_NEAR": 200,
    "PUSH_MS": 1000,
    "DRIBBLE": 1,              # 1 = after a push keep chasing and pushing again until time runs out
    "GOAL_AIM": 0,             # 1 = before pushing, circle the ball until it lines up with the goal
    "GOAL_ALIGN_PX": 40,       # ball and goal x within this: aligned, push
    "ORBIT_STRAFE_MS": 250,    # one orbit step = sideways slide + small spin back toward the ball
    "ORBIT_SPIN_MS": 120,
    "BACKUP_MS": 250,
    "SEARCH_MS": 200,
    "MAX_SEARCH_STEPS": 20,
    "LOST_FRAMES": 2,          # consecutive misses before searching
    "SETTLE_S": 0.8,           # camera lag: frames arriving sooner may predate the move
    "STALE_LIMIT_S": 4.0,      # no fresh frame for this long: stop the run
}


def load_settings(path: Path) -> dict:
    """Read KEY=VALUE lines; anything missing or invalid keeps its default."""
    values = dict(DEFAULTS)
    try:
        lines = path.read_text().splitlines()
    except OSError:
        print(f"[CFG] {path} not found - using defaults")
        return values
    for raw in lines:
        line = raw.split("#", 1)[0].strip()
        if "=" not in line:
            continue
        key, value = (part.strip() for part in line.split("=", 1))
        key = key.upper()
        if key not in DEFAULTS:
            print(f"[CFG] unknown key {key!r} ignored")
            continue
        default = DEFAULTS[key]
        try:
            values[key] = value.lower() if isinstance(default, str) else type(default)(value)
        except ValueError:
            print(f"[CFG] bad value for {key}: {value!r} - keeping {default}")
    return values


def clamp(value, low, high):
    return max(low, min(high, value))


class Driver:
    """Wheel-level moves built on drive_raw. Positive power = that wheel forward."""

    def __init__(self, robot, cfg: dict):
        self.robot = robot
        self.cfg = cfg
        self.last_motion_end = 0.0

    def _raw(self, label: str, m0, m1, m2, m3, ms) -> None:
        m0, m1, m2, m3 = (int(clamp(v, -255, 255)) for v in (m0, m1, m2, m3))
        ms = int(max(1, ms))
        tag = "(dry run) " if self.cfg["DRY_RUN"] else ""
        print(f"        -> {tag}{label} [M0={m0} M1={m1} M2={m2} M3={m3}] {ms}ms")
        if self.cfg["DRY_RUN"]:
            time.sleep(ms / 1000)
        else:
            self.robot.drive_raw(m0, m1, m2, m3, ms=ms)   # returns immediately
            time.sleep(ms / 1000 + 0.05)                   # MCU timer stops the wheels
            if not self.robot.is_running():
                raise ProgramStopped()
        self.last_motion_end = time.monotonic()

    def sides(self, label: str, left, right, ms) -> None:
        # M1, M2 = left side; M0, M3 = right side
        self._raw(label, right, left, left, right, ms)

    def forward(self, power, ms, label="forward"):
        self.sides(label, power, power, ms)

    def backward(self, power, ms):
        self.sides("backward", -power, -power, ms)

    def spin(self, to_left: bool, power, ms):
        if to_left:
            self.sides("spin_left", -power, power, ms)
        else:
            self.sides("spin_right", power, -power, ms)

    def arc(self, turn, base, ms):
        """turn > 0 curves left, < 0 curves right, while driving forward."""
        if self.cfg["ARC_INVERT"]:
            turn = -turn
        label = "arc_left" if turn > 0 else "arc_right"
        self.sides(label, base - turn, base + turn, ms)

    def strafe(self, to_left: bool, power, ms):
        if to_left:
            self._raw("strafe_left", power, -power, power, -power, ms)
        else:
            self._raw("strafe_right", -power, power, -power, power, ms)


def wheel_test(robot, cfg: dict) -> None:
    """Run each move once so the directions can be checked with wheels raised."""
    drv = Driver(robot, cfg)
    moves = [
        ("forward", lambda: drv.forward(cfg["FWD_POWER"], 400)),
        ("arc LEFT (right wheels faster)", lambda: drv.arc(80, cfg["ARC_BASE"], 600)),
        ("arc RIGHT (left wheels faster)", lambda: drv.arc(-80, cfg["ARC_BASE"], 600)),
        ("spin LEFT", lambda: drv.spin(True, cfg["SPIN_POWER"], 400)),
        ("spin RIGHT", lambda: drv.spin(False, cfg["SPIN_POWER"], 400)),
        ("strafe LEFT", lambda: drv.strafe(True, cfg["STRAFE_POWER"], 400)),
        ("strafe RIGHT", lambda: drv.strafe(False, cfg["STRAFE_POWER"], 400)),
    ]
    for name, move in moves:
        print(f"[WHEELS] {name}")
        move()
        time.sleep(1.5)
    print("[WHEELS] done")


class SoccerRun:
    def __init__(self, robot, camera, detector, cfg: dict):
        self.robot = robot
        self.camera = camera
        self.detector = detector
        self.cfg = cfg
        self.drv = Driver(robot, cfg)
        self.last_seq = -1
        self.last_seen = None      # most recent ball detection
        self.misses = 0            # consecutive frames without a ball
        self.search_steps = 0
        self.step = 0

    def fresh_frame(self):
        """Wait for a frame that arrived after the last move settled."""
        cfg = self.cfg
        need_after = self.drv.last_motion_end + cfg["SETTLE_S"]
        deadline = max(time.monotonic(), need_after) + cfg["STALE_LIMIT_S"]
        while time.monotonic() < deadline:
            if not self.robot.is_running():
                raise ProgramStopped()
            frame, stamp, seq = self.camera.latest()
            if frame is not None and stamp > need_after and seq != self.last_seq:
                self.last_seq = seq
                return frame
            time.sleep(0.03)
        return None

    def push(self) -> bool:
        """Push forward. Returns True if the run should end here."""
        print("        PUSH")
        self.drv.forward(self.cfg["PUSH_POWER"], self.cfg["PUSH_MS"], label="push")
        if not self.cfg["DRIBBLE"]:
            print("[DONE] push finished - press BOOT for another attempt")
            return True
        print("        push done - looking for the ball again")
        self.last_seen = None
        self.misses = 0
        return False

    def run(self) -> None:
        cfg = self.cfg
        drv = self.drv
        end = time.monotonic() + cfg["RUN_SECONDS"]
        while time.monotonic() < end:
            frame = self.fresh_frame()
            if frame is None:
                print("[STOP] camera feed stalled - ending run")
                return
            self.step += 1
            width = frame.shape[1]
            found = self.detector.detect(frame)
            ball, goal = found["ball"], found["goal"]

            if ball is None:
                self.misses += 1
                print(f"[{self.step:3d}] no ball (miss {self.misses})")
                last = self.last_seen
                if last is not None and last["cy"] >= cfg["NEAR_Y"] - 20 and self.misses <= 2:
                    # It was right in front and dropped out of the bottom of the view.
                    last_off = last["cx"] - width / 2
                    if abs(last_off) <= cfg["PUSH_MAX_OFF_PX"]:
                        print("        ball left the view at close range, centered")
                        if self.push():
                            return
                        continue
                    print(f"        ball lost close but off-center ({last_off:+.0f}px) - backing up")
                    drv.backward(cfg["FWD_POWER"], cfg["BACKUP_MS"])
                    self.last_seen = None
                    self.misses = 0
                    continue
                if self.misses < cfg["LOST_FRAMES"]:
                    continue   # one missed frame is normal; look again without moving
                self.search_steps += 1
                if self.search_steps > cfg["MAX_SEARCH_STEPS"]:
                    print("[STOP] ball not found - ending run")
                    return
                turn_left = last is None or last["cx"] < width / 2
                drv.spin(turn_left, cfg["SPIN_POWER"], cfg["SEARCH_MS"])
                continue

            self.misses = 0
            self.search_steps = 0
            self.last_seen = ball
            offset = ball["cx"] - width / 2
            y = ball["cy"]
            goal_txt = "" if goal is None else f" | goal off={goal['cx'] - width / 2:+5.0f}px"
            print(f"[{self.step:3d}] ball off={offset:+5.0f}px y={y:4.0f} conf={ball['quality']:.2f}{goal_txt}")

            if abs(offset) <= cfg["CENTER_BAND_PX"]:
                if y >= cfg["NEAR_Y"]:
                    if cfg["GOAL_AIM"] and goal is not None:
                        diff = goal["cx"] - ball["cx"]
                        if abs(diff) > cfg["GOAL_ALIGN_PX"]:
                            # Goal is right of the ball -> circle left around the ball
                            # (slide left, then turn right to face the ball again).
                            to_left = diff > 0
                            print(f"        goal not lined up ({diff:+.0f}px) - orbiting")
                            drv.strafe(to_left, cfg["STRAFE_POWER"], cfg["ORBIT_STRAFE_MS"])
                            drv.spin(not to_left, cfg["SPIN_POWER"], cfg["ORBIT_SPIN_MS"])
                            continue
                    if self.push():
                        return
                    continue
                ms = cfg["FWD_MS_FAR"] if y < cfg["FAR_Y"] else cfg["FWD_MS_NEAR"]
                drv.forward(cfg["FWD_POWER"], ms)
            elif y >= cfg["STRAFE_Y"] and abs(offset) <= cfg["STRAFE_MAX_OFF_PX"]:
                # Close and slightly off: slide sideways, keep the heading toward the goal.
                drv.strafe(offset < 0, cfg["STRAFE_POWER"], cfg["STRAFE_MS"])
            elif abs(offset) > cfg["SPIN_OFF_PX"] or y >= cfg["STRAFE_Y"]:
                # Far off to the side (or close and far off): turn in place.
                ms = clamp(abs(offset) * cfg["TURN_MS_PER_PX"], cfg["TURN_MS_MIN"], cfg["TURN_MS_MAX"])
                drv.spin(offset < 0, cfg["SPIN_POWER"], ms)
            else:
                # Moderately off and not close: curve toward it like a car.
                turn = clamp(-offset * cfg["ARC_GAIN"], -cfg["ARC_TURN_MAX"], cfg["ARC_TURN_MAX"])
                drv.arc(turn, cfg["ARC_BASE"], cfg["ARC_MS"])
        print("[STOP] time limit reached")