"""Ball detection for the robocar: read the ESP32 MJPEG stream, find the ball by color.

Tune HSV_RANGES on site: put the ball in the middle of the frame, read the
"center HSV" that main.py prints, and set the range around it.
"""
import math
import threading
import time

import cv2
import numpy as np

CAMERA_URL = "http://192.168.5.1:81/stream"
OPEN_TIMEOUT_MS = 10000   # FFmpeg probes several frames while opening; 3 s was too short
READ_TIMEOUT_MS = 5000

# OpenCV HSV ranges: H is 0-179, S and V are 0-255.
# Default is an orange ball. Red wraps around H=0, so it needs two ranges, e.g.
# [((0, 120, 80), (8, 255, 255)), ((170, 120, 80), (179, 255, 255))]
HSV_RANGES = [((5, 120, 100), (22, 255, 255))]

MIN_AREA = 60            # px^2 in a 320x240 frame; smaller blobs are noise
MIN_CIRCULARITY = 0.45   # 1.0 is a perfect circle
KERNEL = np.ones((5, 5), np.uint8)


class LatestFrameCamera:
    """Reads the stream on a background thread and keeps only the newest frame.

    cv2.VideoCapture buffers frames internally, so reading on demand can hand
    back old images. A dedicated reader always holds the most recent one, and
    its timestamp lets the caller detect a stalled feed.
    """

    def __init__(self, url: str = CAMERA_URL):
        self.url = url
        self._lock = threading.Lock()
        self._frame = None
        self._stamp = 0.0
        self._seq = 0
        self._running = False

    def start(self) -> None:
        self._running = True
        threading.Thread(target=self._loop, daemon=True).start()

    def stop(self) -> None:
        self._running = False

    def _loop(self) -> None:
        cap = None
        while self._running:
            if cap is None or not cap.isOpened():
                # FFmpeg only (skip the GStreamer attempt) with short timeouts, so a
                # dead link fails in ~10 s instead of hanging 20-30 s per try.
                cap = cv2.VideoCapture(self.url, cv2.CAP_FFMPEG, [
                    cv2.CAP_PROP_OPEN_TIMEOUT_MSEC, OPEN_TIMEOUT_MS,
                    cv2.CAP_PROP_READ_TIMEOUT_MSEC, READ_TIMEOUT_MS,
                ])
                if not cap.isOpened():
                    print("[CAM] cannot open stream, retrying")
                    time.sleep(1)
                    continue
                print("[CAM] stream opened")
            ok, frame = cap.read()
            if not ok or frame is None or frame.size == 0:
                # The ESP32 stream can drop; reopen instead of staying blind.
                print("[CAM] read failed, reopening")
                cap.release()
                cap = None
                time.sleep(0.2)
                continue
            with self._lock:
                self._frame = frame
                self._stamp = time.monotonic()
                self._seq += 1
        if cap is not None:
            cap.release()

    def latest(self):
        """Return (frame, monotonic_timestamp, sequence_number)."""
        with self._lock:
            return self._frame, self._stamp, self._seq


def detect_ball(frame):
    """Return the most likely ball as a dict, or None.

    Keys: cx, cy (pixels), radius, area, quality (0-1), frame_w.
    """
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    mask = None
    for low, high in HSV_RANGES:
        part = cv2.inRange(hsv, np.array(low), np.array(high))
        mask = part if mask is None else cv2.bitwise_or(mask, part)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, KERNEL)   # remove specks
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, KERNEL)  # fill small holes

    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    best = None
    for contour in contours:
        area = cv2.contourArea(contour)
        if area < MIN_AREA:
            continue
        perimeter = cv2.arcLength(contour, True)
        circularity = 4 * math.pi * area / (perimeter * perimeter) if perimeter else 0
        if circularity < MIN_CIRCULARITY:
            continue
        (x, y), radius = cv2.minEnclosingCircle(contour)
        fill = area / (math.pi * radius * radius) if radius > 0 else 0
        quality = min(1.0, 0.5 * circularity + 0.5 * fill)
        if best is None or area > best["area"]:
            best = {
                "cx": x, "cy": y, "radius": radius, "area": area,
                "quality": quality, "frame_w": frame.shape[1],
            }
    return best


def center_hsv(frame, size: int = 10):
    """Median HSV of a small patch at the frame center, for tuning HSV_RANGES."""
    h, w = frame.shape[:2]
    patch = frame[h // 2 - size:h // 2 + size, w // 2 - size:w // 2 + size]
    hsv = cv2.cvtColor(patch, cv2.COLOR_BGR2HSV).reshape(-1, 3)
    return tuple(int(v) for v in np.median(hsv, axis=0))