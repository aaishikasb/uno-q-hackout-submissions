import subprocess
import sys
import time
from pathlib import Path

from arduino.app_utils import App
from robot_client import MiniAutoRobot
from ball_detector import LatestFrameCamera
from soccer import SoccerRun, load_settings, wheel_test

APP_ROOT = Path(__file__).resolve().parent.parent
PYTHON_DIR = Path(__file__).resolve().parent
CONFIG_PATH = APP_ROOT / "robot_config.txt"   # re-read on every BOOT press
STALE_AFTER_S = 0.5


def ensure_edge_impulse() -> bool:
    """App Lab rebuilds the container on every Run, so install from the local wheel."""
    try:
        import edge_impulse_linux  # noqa: F401
        return True
    except ImportError:
        pass
    wheels = sorted(APP_ROOT.glob("edge_impulse_linux-*.whl"))
    if not wheels:
        print(f"[WARN] no edge_impulse_linux wheel in {APP_ROOT}")
        return False
    attempts = [
        [sys.executable, "-m", "pip", "install", "--no-index", "--no-deps", str(wheels[0])],
        ["uv", "pip", "install", "--offline", "--no-deps", "--python", sys.executable, str(wheels[0])],
    ]
    for cmd in attempts:
        try:
            result = subprocess.run(cmd, capture_output=True, text=True)
        except FileNotFoundError:
            continue
        if result.returncode == 0:
            import importlib
            import site
            path = site.getusersitepackages()
            if path not in sys.path:
                sys.path.insert(0, path)
            importlib.invalidate_caches()
            try:
                import edge_impulse_linux  # noqa: F401
                print("[INFO] edge_impulse_linux ready")
                return True
            except ImportError:
                pass
        print(f"[WARN] {cmd[0]} install failed: {result.stderr.strip()[:200]}")
    return False


robot = MiniAutoRobot()
camera = LatestFrameCamera()


def wait_for_mcu(timeout_s: float = 60) -> None:
    """The MCU needs a few seconds after Run to register Bridge methods."""
    deadline = time.monotonic() + timeout_s
    while True:
        try:
            robot.stop()
            return
        except Exception as error:
            if time.monotonic() > deadline:
                raise
            print(f"[WAIT] MCU not ready yet: {error}")
            time.sleep(1)


def describe(name, obj, frame_w, band):
    if obj is None:
        return f"{name}: -"
    offset = obj["cx"] - frame_w / 2
    side = "CENTER" if abs(offset) < band else ("LEFT" if offset < 0 else "RIGHT")
    return f"{name}: {side:6s} off={offset:+5.0f}px y={obj['cy']:5.0f} conf={obj['quality']:.2f}"


def vision_check(detector, cfg) -> None:
    """Motors never move here: print what the model sees."""
    end = time.monotonic() + cfg["VISION_SECONDS"]
    last_seq = -1
    while time.monotonic() < end and robot.is_running():
        frame, stamp, seq = camera.latest()
        if frame is None or time.monotonic() - stamp > STALE_AFTER_S:
            time.sleep(0.2)
            continue
        if seq == last_seq:
            time.sleep(0.02)
            continue
        last_seq = seq
        found = detector.detect(frame)
        w = frame.shape[1]
        band = cfg["CENTER_BAND_PX"]
        print(f"{describe('BALL', found['ball'], w, band)} | {describe('GOAL', found['goal'], w, band)}")
        time.sleep(0.3)
    print("[INFO] vision check finished")


def make_routine(detector):
    def routine() -> None:
        cfg = load_settings(CONFIG_PATH)
        print(f"[CFG] MODE={cfg['MODE']} DRY_RUN={cfg['DRY_RUN']}")
        if cfg["MODE"] == "vision":
            vision_check(detector, cfg)
        elif cfg["MODE"] == "match":
            SoccerRun(robot, camera, detector, cfg).run()
        elif cfg["MODE"] == "wheels":
            wheel_test(robot, cfg)
        else:
            print(f"[CFG] unknown MODE {cfg['MODE']!r} - use vision, match or wheels")
    return routine


detector = None
try:
    print(f"edge_impulse ok: {ensure_edge_impulse()}")
    wait_for_mcu()
    print(f"health  : {robot.health()}")
    print(f"sensors : {robot.read_sensors()}")

    from ei_detector import EIDetector, find_model
    detector = EIDetector(find_model(PYTHON_DIR))

    camera.start()
    print(f"Edit {CONFIG_PATH.name} to switch MODE / tune values, then press BOOT (no restart needed).")
    App.run(user_loop=lambda: robot.run_program(make_routine(detector)))
finally:
    camera.stop()
    if detector is not None:
        detector.close()
    robot.stop()