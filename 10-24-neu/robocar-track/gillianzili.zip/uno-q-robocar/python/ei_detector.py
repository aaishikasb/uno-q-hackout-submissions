"""Edge Impulse FOMO detector with the same output shape as ball_detector.detect_ball().

FOMO reports object CENTROIDS on a coarse grid; its box width/height are a
fixed cell size, NOT the object's real size. So use cx for steering and cy
(lower in the frame = closer) for distance, not the radius.
"""
from pathlib import Path

import cv2

LABEL_BALL = "soccerball"   # label names from the Edge Impulse project
LABEL_GOAL = "goal"
MIN_CONFIDENCE = 0.5
# Per-label thresholds. With no goal on the field the model still reported a
# "goal" at conf 0.50-0.64 in the bottom-left corner, so goals need more.
MIN_CONFIDENCE_BY_LABEL = {"ball": 0.5, "goal": 0.7}
# Ignore goal detections in the bottom rows of the frame (the false positive
# sat at y=230 of 240). Set to None to disable.
GOAL_MAX_Y = 200


class ModelUnavailable(RuntimeError):
    pass


def find_model(folder: Path) -> Path:
    models = sorted(folder.glob("*.eim"))
    if not models:
        raise ModelUnavailable(f"no .eim model in {folder}")
    return models[0]


class EIDetector:
    def __init__(self, model_path: Path, min_confidence: float = MIN_CONFIDENCE):
        from edge_impulse_linux.image import ImageImpulseRunner

        model_path = Path(model_path)
        model_path.chmod(model_path.stat().st_mode | 0o111)  # .eim must be executable
        self.min_confidence = min_confidence
        self.runner = ImageImpulseRunner(str(model_path))
        info = self.runner.init()
        labels = info["model_parameters"]["labels"]
        print(f"[EI] loaded {model_path.name}, labels={labels}")

    def close(self) -> None:
        try:
            self.runner.stop()
        except Exception:  # noqa: BLE001
            pass

    def detect(self, frame_bgr):
        """Return {"ball": dict|None, "goal": dict|None} in full-frame pixels."""
        frame_h, frame_w = frame_bgr.shape[:2]
        rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
        features, cropped = self.runner.get_features_from_image_auto_studio_settings(rgb)
        result = self.runner.classify(features)
        boxes = result.get("result", {}).get("bounding_boxes", [])

        # Boxes are in the model's input image (e.g. 96x96, squashed); scale back.
        scale_x = frame_w / cropped.shape[1]
        scale_y = frame_h / cropped.shape[0]
        best = {"ball": None, "goal": None}
        for box in boxes:
            name = {LABEL_BALL: "ball", LABEL_GOAL: "goal"}.get(box["label"])
            if name is None:
                continue
            threshold = max(self.min_confidence, MIN_CONFIDENCE_BY_LABEL.get(name, 0))
            if box["value"] < threshold:
                continue
            cx = (box["x"] + box["width"] / 2) * scale_x
            cy = (box["y"] + box["height"] / 2) * scale_y
            if name == "goal" and GOAL_MAX_Y is not None and cy > GOAL_MAX_Y:
                continue
            if best[name] is None or box["value"] > best[name]["quality"]:
                best[name] = {
                    "cx": cx, "cy": cy,
                    "radius": box["width"] * scale_x / 2,  # cell size only, see note above
                    "area": box["width"] * box["height"] * scale_x * scale_y,
                    "quality": box["value"], "frame_w": frame_w, "frame_h": frame_h,
                }
        return best