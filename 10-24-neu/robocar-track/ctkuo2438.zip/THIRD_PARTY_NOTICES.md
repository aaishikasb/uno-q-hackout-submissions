# Sources and third-party notices

## Organizer starter app

The Hiwonder miniAuto drivers, camera firmware template and original hardware
documentation were supplied in the Qualcomm/AI-LA Robot Soccer Cup App Lab app.
The original README is retained as `STARTER_README.md`, and the original camera
source and `docs/` assets are included. No new license is asserted for those files.

## Model and dataset

The included `python/models/fomo-soccer-goal.eim` is the user's Edge Impulse
deployment from project 1147948, trained using the organizer's public project:
<https://studio.edgeimpulse.com/public/1144501/live>.
The public dataset project displayed a 3-Clause BSD license. The dataset images
are not included in this ZIP. Model provenance, metrics and hash are recorded
in `python/models/fomo-model-manifest.json`.

## Edge Impulse Linux SDK

The image/runner subset of `edge-impulse-linux` 1.2.2 is bundled under
`python/vendor/edge_impulse_linux/`. The original Clear BSD license is retained
as `LICENSE` in that directory. Source attribution, local modifications and file
hashes are in `python/vendor/edge-impulse-sdk-manifest.json`.
Source: <https://pypi.org/project/edge-impulse-linux/1.2.2/>.

## OpenCV and NumPy

Official binary distributions are included as unmodified wheel files in
`python/wheels/`. Their original distribution metadata, licenses and notices
remain inside the wheel archives. File names, sources and hashes are retained
in `python/wheels/manifest.json`.

Arduino core, Arduino_RouterBridge and other MCU libraries are supplied through
the prepared App Lab board environment; their sources are not bundled here.

For this public submission, the camera template network definitions were moved
to a private `camera_secrets.h` include. A placeholder example is supplied;
no private camera header is distributed.
