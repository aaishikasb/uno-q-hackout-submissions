# Robocar — FOMO Soccer Ball Detection and Bounded Push

Arduino UNO Q / Hiwonder miniAuto hackathon submission, packaged on 2026-10-24.

This app reads the robot's ESP32-S3 MJPEG camera, detects `soccerball` and `goal`
with an Edge Impulse FOMO MobileNetV2 0.35 model, and implements a BOOT-controlled
forward-push routine. Python handles vision and decisions on UNO Q Linux;
the microcontroller sketch handles motor output, timed stops and the BOOT gate.

## Submission status / 目前完成狀態

- Real robot-camera frames and FOMO ball detections have been demonstrated on UNO Q.
- A field run confirmed the ball in consecutive frames and issued two forward
  commands at speed 100 for 100 ms each. The user reported no visible forward motion.
- This submitted version changes each pulse to **200 ms** and checks the MCU's
  acknowledgement. Those final changes have **not** been tested on the car.
- Goal detection is integrated in the model/output, but field goal recognition,
  automatic steering, and scoring a goal have not been demonstrated.
- 34 host-side software checks passed before packaging. No additional car tests
  were performed after the user requested submission.

這是目前開發版本：辨識與前進決策已接通，實際推球尚未確認。

## Start in Arduino App Lab / 啟動方式

1. Import this ZIP from **My Apps** in Arduino App Lab. `app.yaml`, `python/`
   and `sketch/` are at the archive root.
2. Connect the prepared UNO Q over USB and select the board in App Lab.
3. Power the robot's motor battery. Keep wheels clear while starting the app;
   use an open floor area for any movement attempt.
4. Join the camera access point from **UNO Q Linux** using App Lab's network
   settings. This robot used `miniAuto_CAM_16`. Obtain the password supplied
   with the kit. The Mac can remain on its normal Wi-Fi when using USB.
5. Close other camera streams on laptops/phones before Python uses the camera.
   Camera endpoint: `http://192.168.5.1:81/stream`.
6. Press **Run**. Wait for `health`, `FOMO ready` and `[MODE] push`.
7. Manually align robot, ball and goal. A short press/release of the camera's
   **BOOT** starts one bounded run. Another short press stops the program.
   Keep the physical motor-power disconnect accessible.

The selected routine is in `python/robot_mode.py`:

```python
MODE = "push"
```

Set it to `"observe"` to keep motors stopped and capture five observations per
BOOT run. Observation mode saves unlabelled original camera JPEGs in
`data/captures/session-<uuid>/`, with a 500-image archive limit. Predictions
in session JSON files are diagnostics, not training annotations.

## Included runtime / 執行環境

- Arduino App Lab 0.11.0 was used with the prepared board.
- UNO Q Linux AARCH64 / CPython 3.13.
- FOMO int8 Linux `.eim` is included in `python/models/`.
- OpenCV 4.12.0.88 and NumPy 2.2.6 ARM64 wheels are included in `python/wheels/`.
  `offline_cv.py` checks their hashes and loads them locally.
- The Edge Impulse Linux Python SDK subset and its license are bundled.
- Arduino `app_utils`, the App Lab container runtime, and the UNO Q core/libraries
  are provided by the prepared board/App Lab installation. A new board may need
  an initial Internet-connected setup before joining the camera-only network.
- Last observed successful sketch build: Arduino Zephyr core 0.90.0,
  Arduino_RouterBridge 0.4.3, Arduino_RPClite 0.3.0, MsgPack 0.4.2,
  DebugLog 0.8.4, ArxTypeTraits 0.3.2 and ArxContainer 0.7.0.

The original exported `sketch.yaml` is preserved. App Lab configures the board
profile when the UNO Q is selected.

## Motion settings / 前進條件

Settings live in `python/push_policy.py`.

| Setting | Submitted value |
| --- | --- |
| Direction | Forward only |
| Speed parameter | 100; this is not a percentage |
| Pulse duration | 200 ms |
| Maximum pulses per BOOT run | 4 |
| Overall run budget | 12 seconds |
| Ball confidence | At least 0.80 |
| Confirmation | Two independent fresh frames before every pulse |
| Maximum observation age for motion | 1.2 seconds |
| Horizontal center band | 40–60% of frame width |
| Calibrated vertical band | 35–95% of frame height; y=84–228 at 320×240 |

A missing, ambiguous, off-center, low-confidence or stale ball ends the run.
Each pulse is followed by a new observation. BOOT gating and timed motor stops
also run in the MCU sketch. FOMO activation-region dimensions are not treated
as physical object size or distance.

`[ACTION]` reports an intended call. `[DRIVE] MCU accepted` confirms a positive
controller reply; it does not prove that the wheels physically moved. A refused
reply raises an error and the run lifecycle stops the robot.

## Model and dataset

- Model: FOMO MobileNetV2 0.35, int8, 96×96 RGB, squash resize.
- Labels: `goal`, `soccerball`. The dataset's `goal` objects are yellow cones;
  automatic selection/alignment of the gap between cones is not implemented.
- Training project: <https://studio.edgeimpulse.com/studio/1147948>.
- Organizer dataset: <https://studio.edgeimpulse.com/public/1144501/live>.
- Recorded training settings: 150 epochs, learning rate 0.001, augmentation enabled.
- Int8 validation F1: approximately 0.969. The independent Model testing UI
  reported 83.33% accuracy and F1 0.87. These are dataset metrics, not a measured
  success rate for driving the car or scoring goals.
- Full parameters, artifact hash and development status:
  `python/models/fomo-model-manifest.json`.

Phone training images differ from the robot camera in viewpoint, lighting,
object scale and sharpness. The observation archive supports later collection
and manual annotation of robot-camera images. Keep independent capture sessions
for evaluation rather than splitting nearly identical adjacent frames.

## Known issues / 尚未解決

- Camera reads sometimes stall or exceed the freshness limit; the run stops.
  Observation mode allows one fresh reconnection; push mode does not retry.
- Bridge startup has intermittently timed out at `robot.stop()`. A full board
  power cycle previously restored it; the underlying cause remains unresolved.
  Do not remove the startup stop to bypass this condition.
- Ground motor power, minimum starting speed, traction and final 200 ms pulses
  still need physical verification. Actual pushing has not been confirmed.
- Current control is a manually aligned forward demo. Left/right steering,
  autonomous goal alignment and a complete scoring run remain future work.

## Files and credits

| Path | Role |
| --- | --- |
| `python/main.py` | App lifecycle, observation and push mode |
| `python/fomo_vision.py` | FOMO preprocessing, inference and centroid decoding |
| `python/ball_vision.py` | Fresh MJPEG reads; older YOLO helper code remains unused |
| `python/push_policy.py` | Confirmation rules and bounded forward actions |
| `python/robot_client.py` | MCU Bridge calls and acknowledgement checks |
| `python/capture_store.py` | Session-based storage of unlabelled camera originals |
| `sketch/` | Motor/sensor/BOOT firmware, including the MCU run gate |
| `camera/` | Organizer camera firmware template, flashed separately |
| `docs/` | Original organizer manual and illustrations |
| `tests/` | Host-side software checks retained for review |
| `STARTER_README.md` | Original hardware-driver README and credits |

The supplied robot camera had already been configured as `miniAuto_CAM_16`.
Importing this app does not flash the separate ESP32 camera. To rebuild that
firmware separately, copy `camera_secrets.h.example` to `camera_secrets.h`
and enter the kit network settings privately. The private header is excluded
from this submission; no camera password is embedded in the submitted template.

Base robot drivers/camera setup were supplied by the Qualcomm Developer Relations
Team. Original documentation and SDK licensing notices are preserved. See
`THIRD_PARTY_NOTICES.md`. Earlier YOLO model weights remain in the development
workspace and are not required or included in this FOMO submission.
