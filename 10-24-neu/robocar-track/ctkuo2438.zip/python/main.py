"""BOOT starts the selected FOMO observation or bounded forward-push routine."""

from pathlib import Path
import time
import traceback

from offline_cv import prepare_opencv

prepare_opencv()

import cv2
from arduino.app_utils import App
from robot_client import MiniAutoRobot, ProgramStopped
from ball_vision import Camera
from capture_store import CaptureSession
from fomo_vision import FomoDetector, annotate_fomo
from push_policy import Observation, PushConfig, run_push_demo
from robot_mode import MODE

MODEL_PATH = Path(__file__).resolve().parent / "models" / "fomo-soccer-goal.eim"
PREVIEW_PATH = Path(__file__).resolve().parents[1] / "data" / "vision-latest.jpg"
RAW_PATH = PREVIEW_PATH.with_name("vision-raw-latest.jpg")
MODEL_INPUT_PATH = PREVIEW_PATH.with_name("vision-model-input-latest.jpg")
CAPTURE_PATH = PREVIEW_PATH.parent / "captures"
robot = MiniAutoRobot()
# Observation can recover a single transient interruption. Motion must end
# the current BOOT run on the first camera failure.
camera = Camera(retry_attempts=1 if MODE == "observe" else 0)
detector = None


def check_running() -> None:
    if not robot.is_running():
        raise ProgramStopped


def save_previews(image, detections) -> None:
    try:
        PREVIEW_PATH.parent.mkdir(parents=True, exist_ok=True)
        images = [(PREVIEW_PATH, annotate_fomo(image, detections)), (RAW_PATH, image)]
        if detector.last_input_rgb is not None:
            images.append((MODEL_INPUT_PATH,
                           cv2.cvtColor(detector.last_input_rgb, cv2.COLOR_RGB2BGR)))
        for path, preview in images:
            ok, jpeg = cv2.imencode(".jpg", preview, [cv2.IMWRITE_JPEG_QUALITY, 95])
            if not ok:
                raise OSError(f"Could not encode {path.name}")
            temporary = path.with_suffix(".tmp")
            temporary.write_bytes(jpeg.tobytes())
            temporary.replace(path)
    except OSError as error:
        print(f"[VISION] preview not saved: {error}", flush=True)


def read_observation(index: int, total=None, capture_session=None) -> Observation:
    check_running()
    camera_started_at = time.monotonic()
    snapshot = camera.read_fresh(check_running)
    # Include any recovery time in camera=, while the freshness check below
    # remains tied to the successful new capture, after all old data was closed.
    capture_ms = (time.monotonic() - camera_started_at) * 1000
    check_running()
    detections, inference_ms = detector.detect(snapshot.image)
    check_running()
    age = time.monotonic() - snapshot.requested_at
    if age > 2:
        raise TimeoutError(
            f"Observation took {age:.2f}s (camera={capture_ms:.0f}ms, "
            f"inference={inference_ms:.0f}ms); refusing stale results"
        )
    height, width = snapshot.image.shape[:2]
    progress = f"{index}/{total}" if total else str(index)
    print(f"[FOMO {progress}] camera={capture_ms:.0f}ms "
          f"inference={inference_ms:.0f}ms age<={age:.2f}s "
          f"frame={width}x{height}", flush=True)
    for label, tag in (("soccerball", "BALL"), ("goal", "GOAL")):
        objects = [d for d in detections if d.label == label]
        if not objects:
            print(f"[{tag}] not found", flush=True)
        for item in objects:
            cx, cy = item.center
            position = "LEFT" if cx < width * .4 else "RIGHT" if cx > width * .6 else "CENTER"
            print(f"[{tag}] count={len(objects)} score={item.score:.2f} "
                  f"center=({cx:.0f},{cy:.0f}) position={position}", flush=True)
    save_previews(snapshot.image, detections)
    if capture_session is not None:
        try:
            capture_session.save(
                snapshot.jpeg, width, height, requested_at=snapshot.requested_at,
                camera_ms=capture_ms, inference_ms=inference_ms, age_seconds=age,
                predictions=[{"label": item.label, "score": float(item.score),
                              "center": [float(v) for v in item.center]}
                             for item in detections],
            )
        except (OSError, ValueError) as error:
            print(f"[CAPTURE] photo not saved: {error}", flush=True)
    return Observation(tuple(detections), snapshot.image.shape, snapshot.requested_at)


def observe_objects() -> None:
    run_deadline = time.monotonic() + 20
    capture_session = None
    try:
        capture_session = CaptureSession(CAPTURE_PATH, camera.url, MODEL_PATH.name)
        print(f"[CAPTURE] unlabelled camera originals: {capture_session.path}", flush=True)
    except OSError as error:
        print(f"[CAPTURE] recording unavailable: {error}", flush=True)
    try:
        for index in range(5):
            check_running()
            if time.monotonic() >= run_deadline:
                print("[VISION] observation time limit reached.", flush=True)
                return
            read_observation(index + 1, 5, capture_session)
            time.sleep(.2)
        print(f"[VISION] finished; latest preview: {PREVIEW_PATH}", flush=True)
        print(f"[VISION] raw camera: {RAW_PATH}; model input: {MODEL_INPUT_PATH}", flush=True)
    except ProgramStopped:
        raise
    except Exception as error:
        print(f"[VISION] stopped: {type(error).__name__}: {error}", flush=True)
        traceback.print_exc()
    finally:
        if capture_session is not None:
            print(f"[CAPTURE] saved {len(capture_session.frames)} original photos; "
                  "manual labels still required.", flush=True)


def push_objects() -> None:
    frame_number = 0

    def observe() -> Observation:
        nonlocal frame_number
        frame_number += 1
        return read_observation(frame_number)

    try:
        run_push_demo(robot, observe, check_running, PushConfig(),
                      log=lambda message: print(message, flush=True))
    except ProgramStopped:
        raise
    except Exception as error:
        print(f"[PUSH] stopped: {type(error).__name__}: {error}", flush=True)
        traceback.print_exc()


try:
    print(f"[ENV] OpenCV {cv2.__version__}; file={cv2.__file__}", flush=True)
    robot.stop()
    if MODE not in {"observe", "push"}:
        raise ValueError("robot_mode.MODE must be 'observe' or 'push'")
    print(f"health   : {robot.health()}", flush=True)
    cv2.setNumThreads(2)
    detector = FomoDetector(str(MODEL_PATH))
    print(f"[VISION] FOMO ready; labels=goal,soccerball; "
          f"input={detector.size[0]}x{detector.size[1]} RGB squash; "
          f"threshold={detector.confidence:.2f}", flush=True)
    if MODE == "observe":
        print("[MODE] observe: motors stay stopped.", flush=True)
        print("[INFO] waiting for BOOT; each press checks five fresh frames...", flush=True)
        routine = observe_objects
    else:
        print("[MODE] push: BOOT starts short forward pulses toward a centered ball.", flush=True)
        print("[INFO] starting arrangement: robot, ball and goal aligned; clear test area.", flush=True)
        routine = push_objects
    App.run(user_loop=lambda: robot.run_program(routine))
finally:
    # A secondary Bridge error must not hide the original diagnostic.
    try:
        robot.stop()
    except Exception as error:
        print(f"[STOP] {type(error).__name__}: {error}", flush=True)
    if detector is not None:
        detector.close()
