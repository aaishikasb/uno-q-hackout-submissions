"""Keep unlabelled camera originals, grouped by one deliberate BOOT run."""

import json
from pathlib import Path
from uuid import uuid4


class CaptureSession:
    def __init__(self, root: Path, camera_url: str, model_name: str,
                 max_images: int = 500) -> None:
        root.mkdir(parents=True, exist_ok=True)
        existing = sum(1 for _ in root.glob("session-*/frame-*.jpg"))
        self.remaining = max_images - existing
        if self.remaining <= 0:
            raise OSError(f"Capture limit ({max_images} images) reached; copy/review existing photos first")
        # The board clock can be wrong; a UUID keeps BOOT runs distinct.
        self.session_id = f"session-{uuid4().hex}"
        self.path = root / self.session_id
        self.path.mkdir()
        self.frames = []
        self.metadata = {
            "schema_version": 1,
            "session_id": self.session_id,
            "camera_url": camera_url,
            "model_name": model_name,
            "annotation_status": "unlabelled; predictions are diagnostics, not ground truth",
            "split_note": "Keep each BOOT session in one dataset split; reserve separate scenes for testing.",
            "frames": self.frames,
        }

    def save(self, jpeg: bytes, width: int, height: int, *, requested_at: float,
             camera_ms: float, inference_ms: float, age_seconds: float,
             predictions: list[dict]) -> Path:
        if self.remaining <= 0:
            raise OSError("Capture image limit reached; existing photos were preserved")
        if not (jpeg.startswith(b"\xff\xd8") and jpeg.endswith(b"\xff\xd9")):
            raise ValueError("Capture requires a complete original camera JPEG")
        path = self.path / f"frame-{self.session_id[8:]}-{len(self.frames) + 1:03d}.jpg"
        with path.open("xb") as image_file:
            image_file.write(jpeg)
        self.remaining -= 1
        self.frames.append({
            "file": path.name,
            "width": width,
            "height": height,
            "requested_at_monotonic": requested_at,
            "camera_ms": camera_ms,
            "inference_ms": inference_ms,
            "age_seconds": age_seconds,
            "predictions_for_review": predictions,
        })
        temporary = self.path / "session.json.tmp"
        temporary.write_text(json.dumps(self.metadata, indent=2, allow_nan=False) + "\n")
        temporary.replace(self.path / "session.json")
        return path
