"""Choose the routine that a deliberate BOOT press starts.

observe: capture five frames with motors stopped; keep unlabelled originals in data/captures.
push: short forward pulses after confirming a centered ball on the floor.
For push, arrange robot, ball and goal in a straight line in a clear test area.
"""

MODE = "push"
