"""Fresh camera frames and CPU inference for the COCO sports-ball baseline."""

from dataclasses import dataclass
from http.client import HTTPException
import time
from typing import Callable
from urllib.error import HTTPError, URLError
from urllib.request import ProxyHandler, build_opener

import cv2
import numpy as np


@dataclass(frozen=True)
class Snapshot:
    image: np.ndarray
    requested_at: float
    jpeg: bytes = b""  # Original camera bytes, before annotations/recompression.


@dataclass(frozen=True)
class Detection:
    box: tuple[int, int, int, int]  # x1, y1, x2, y2 in the original image
    score: float

    @property
    def center(self) -> tuple[float, float]:
        x1, y1, x2, y2 = self.box
        return (x1 + x2) / 2, (y1 + y2) / 2


class CameraConnectionError(ConnectionError):
    """The camera could not begin an HTTP stream, before decoding/inference."""


class CameraReadError(ConnectionError):
    """The established camera stream ended or returned incomplete data."""


class CameraReadTimeout(TimeoutError):
    """The established camera stream stopped delivering complete frames."""


class Camera:
    def __init__(self, url: str = "http://192.168.5.1:81/stream", retry_attempts: int = 0) -> None:
        if type(retry_attempts) is not int or retry_attempts not in (0, 1):
            raise ValueError("Camera recovery must be disabled or limited to one retry")
        self.url = url
        self.retry_attempts = retry_attempts
        self.opener = build_opener(ProxyHandler({}))

    def read_fresh(self, check_running: Callable[[], None]) -> Snapshot:
        for attempt in range(self.retry_attempts + 1):
            try:
                return self._read_once(check_running)
            except HTTPError:
                raise  # An HTTP status/configuration error needs diagnosis.
            except (CameraConnectionError, CameraReadError, CameraReadTimeout) as error:
                if attempt >= self.retry_attempts:
                    raise
                check_running()
                print(f"[CAMERA] stream interrupted: {error}; reconnecting "
                      f"{attempt + 1}/{self.retry_attempts}; discarded previous frames.", flush=True)
                # Give the ESP32's former stream handler time to notice its
                # closed socket. No partial JPEG or failed connection survives.
                time.sleep(.25)
                check_running()
        raise RuntimeError("Camera retry loop ended unexpectedly")

    def _read_once(self, check_running: Callable[[], None]) -> Snapshot:
        # A new connection avoids an old TCP backlog. Discard the camera's two
        # configured frame buffers before taking a frame for a new observation.
        # On recovery, this timestamp belongs to the NEW connection/capture;
        # the failed attempt's bytes and images are never returned as fresh.
        check_running()
        requested_at = time.monotonic()
        deadline = requested_at + 6
        buffer = bytearray()
        frame_count = 0
        received_bytes = 0
        last_run_check = requested_at
        try:
            stream = self.opener.open(self.url, timeout=3)
        except HTTPError:
            raise  # Preserve an actual HTTP status such as 404 or 500.
        except (OSError, URLError, HTTPException) as error:
            detail = getattr(error, "reason", error)
            raise CameraConnectionError(
                f"Camera HTTP connection failed before receiving an image: {self.url} "
                f"({detail}). Stop and close camera previews on Mac/phones; "
                "verify UNO Q is on the camera Wi-Fi and the camera has power. "
                "Inference for this camera read did not run."
            ) from error
        with stream:
            if stream.headers.get_content_type() != "multipart/x-mixed-replace":
                raise ValueError("The camera did not return an MJPEG stream")
            while time.monotonic() < deadline:
                # Do not turn each small HTTP chunk into another sensor RPC.
                if time.monotonic() - last_run_check >= 0.2:
                    check_running()
                    last_run_check = time.monotonic()
                try:
                    # read() tries to fill the requested amount across HTTP
                    # chunks, potentially waiting for an unnecessary next frame.
                    chunk = stream.read1(4096)
                except TimeoutError as error:
                    raise CameraReadTimeout(
                        f"Camera read stalled: {received_bytes} bytes, "
                        f"{frame_count}/3 JPEG frames, "
                        f"elapsed={time.monotonic() - requested_at:.2f}s"
                    ) from error
                except (OSError, HTTPException) as error:
                    raise CameraReadError(
                        f"Camera stream interrupted after {received_bytes} bytes, "
                        f"{frame_count}/3 JPEG frames: {error}"
                    ) from error
                if not chunk:
                    raise CameraReadError("Camera stream ended")
                received_bytes += len(chunk)
                buffer.extend(chunk)
                if len(buffer) > 512 * 1024:
                    raise ValueError("Camera frame exceeded the size limit")
                while True:
                    start = buffer.find(b"\xff\xd8")
                    end = buffer.find(b"\xff\xd9", start + 2) if start >= 0 else -1
                    if end < 0:
                        break
                    jpeg = bytes(buffer[start : end + 2])
                    del buffer[: end + 2]
                    frame_count += 1
                    if frame_count <= 2:
                        continue
                    image = cv2.imdecode(np.frombuffer(jpeg, np.uint8), cv2.IMREAD_COLOR)
                    if image is None:
                        raise CameraReadError("Could not decode the camera JPEG")
                    return Snapshot(image, requested_at, jpeg)
        raise CameraReadTimeout(
            f"No fresh camera frame within the time limit: "
            f"{received_bytes} bytes, {frame_count}/3 JPEG frames"
        )


def letterbox(image: np.ndarray, size: int = 320) -> tuple[np.ndarray, float, int, int]:
    height, width = image.shape[:2]
    ratio = min(size / width, size / height)
    resized_width, resized_height = round(width * ratio), round(height * ratio)
    left, top = (size - resized_width) // 2, (size - resized_height) // 2
    canvas = np.full((size, size, 3), 114, dtype=np.uint8)
    canvas[top : top + resized_height, left : left + resized_width] = cv2.resize(
        image, (resized_width, resized_height), interpolation=cv2.INTER_LINEAR
    )
    return canvas, ratio, left, top


def decode_predictions(
    output: np.ndarray,
    image_shape: tuple[int, ...],
    ratio: float,
    left: int,
    top: int,
    confidence: float = 0.35,
    class_id: int = 32,
    class_count: int = 80,
) -> list[Detection]:
    if output.ndim != 3 or output.shape[:2] != (1, 4 + class_count):
        raise ValueError(f"Unexpected YOLO output shape: {output.shape}")
    if not 0 <= class_id < class_count:
        raise ValueError("Target class is outside this model's class list")
    height, width = image_shape[:2]
    rows = output[0].T
    class_scores = rows[:, 4:]
    scores = class_scores[:, class_id]
    selected = (class_scores.argmax(axis=1) == class_id) & (scores >= confidence)
    boxes, accepted_scores = [], []
    for row, score in zip(rows[selected], scores[selected]):
        if not np.isfinite(row).all():
            continue
        cx, cy, box_width, box_height = row[:4]
        x1 = int(np.clip(round((cx - box_width / 2 - left) / ratio), 0, width - 1))
        y1 = int(np.clip(round((cy - box_height / 2 - top) / ratio), 0, height - 1))
        x2 = int(np.clip(round((cx + box_width / 2 - left) / ratio), 0, width - 1))
        y2 = int(np.clip(round((cy + box_height / 2 - top) / ratio), 0, height - 1))
        if x2 - x1 < 4 or y2 - y1 < 4:
            continue
        boxes.append([x1, y1, x2 - x1, y2 - y1])
        accepted_scores.append(float(score))
    if not boxes:
        return []
    kept = np.asarray(cv2.dnn.NMSBoxes(boxes, accepted_scores, confidence, 0.45)).reshape(-1)
    results = []
    for index in kept:
        x, y, w, h = boxes[int(index)]
        results.append(Detection((x, y, x + w, y + h), accepted_scores[int(index)]))
    return sorted(results, key=lambda item: item.score, reverse=True)


class BallDetector:
    def __init__(self, model_path: str) -> None:
        self.net = cv2.dnn.readNetFromONNX(model_path)
        self.net.setPreferableBackend(cv2.dnn.DNN_BACKEND_OPENCV)
        self.net.setPreferableTarget(cv2.dnn.DNN_TARGET_CPU)
        self.net.setInput(np.zeros((1, 3, 320, 320), np.float32))
        output = self.net.forward()  # Allocate and validate before BOOT is pressed.
        if output.shape != (1, 84, 2100):
            raise ValueError(f"Expected the COCO YOLOv8n baseline; received {output.shape}")

    def detect(self, image: np.ndarray) -> tuple[list[Detection], float]:
        canvas, ratio, left, top = letterbox(image)
        blob = cv2.dnn.blobFromImage(canvas, 1 / 255.0, (320, 320), swapRB=True, crop=False)
        started_at = time.monotonic()
        self.net.setInput(blob)
        output = self.net.forward()
        inference_ms = (time.monotonic() - started_at) * 1000
        return decode_predictions(output, image.shape, ratio, left, top), inference_ms


def annotate(image: np.ndarray, detections: list[Detection]) -> np.ndarray:
    result = image.copy()
    height, width = image.shape[:2]
    for x in (int(width * 0.4), int(width * 0.6)):
        cv2.line(result, (x, 0), (x, height - 1), (0, 220, 220), 1)
    for detection in detections:
        x1, y1, x2, y2 = detection.box
        cv2.rectangle(result, (x1, y1), (x2, y2), (0, 255, 0), 2)
        cv2.putText(result, f"ball {detection.score:.2f}", (x1, max(12, y1 - 4)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 255, 0), 1)
    return result
