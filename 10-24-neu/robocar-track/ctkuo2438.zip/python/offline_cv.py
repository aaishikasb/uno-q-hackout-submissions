"""Load the project-local ARM64 OpenCV wheels without Internet access."""

import hashlib
import json
from pathlib import Path, PurePosixPath
import platform
import shutil
import sys
import tempfile
import zipfile


def unpack_runtime(wheels: Path, cache: Path) -> Path:
    manifest_bytes = (wheels / "manifest.json").read_bytes()
    manifest = json.loads(manifest_bytes)
    identity = hashlib.sha256(manifest_bytes).hexdigest()[:16]
    destination = cache / identity
    if (destination / ".complete").is_file():
        return destination

    cache.mkdir(parents=True, exist_ok=True)
    staging = Path(tempfile.mkdtemp(prefix="unpack-", dir=cache))
    try:
        print("[SETUP] preparing offline OpenCV with DNN (first run)...", flush=True)
        for item in manifest["wheels"]:
            path = wheels / item["name"]
            if hashlib.sha256(path.read_bytes()).hexdigest() != item["sha256"]:
                raise ValueError(f"Wheel integrity check failed: {path.name}")
            with zipfile.ZipFile(path) as archive:
                for member in archive.infolist():
                    relative = PurePosixPath(member.filename)
                    if relative.is_absolute() or ".." in relative.parts:
                        raise ValueError("Unexpected path inside a dependency wheel")
                archive.extractall(staging)
        if not (staging / "cv2" / "__init__.py").is_file():
            raise ValueError("Offline runtime is missing the OpenCV package")
        if not (staging / "numpy" / "__init__.py").is_file():
            raise ValueError("Offline runtime is missing the NumPy package")
        (staging / ".complete").write_text(identity)
        staging.rename(destination)
    finally:
        if staging.exists():
            shutil.rmtree(staging)
    return destination


def prepare_opencv() -> None:
    if platform.system() != "Linux" or platform.machine() not in {"aarch64", "arm64"}:
        return
    if sys.version_info[:2] != (3, 13):
        raise RuntimeError("These offline wheels target the UNO Q Python 3.13 runtime")
    if any(name in sys.modules for name in ("cv2", "numpy")):
        raise RuntimeError("Load offline_cv before importing cv2 or numpy; restart the App")
    source = Path(__file__).resolve().parent
    cache = source.parent / ".cache" / "robocar-opencv"
    try:
        cache.mkdir(parents=True, exist_ok=True)
    except PermissionError:
        cache = Path(tempfile.gettempdir()) / "robocar-opencv"
    runtime = unpack_runtime(source / "wheels", cache)
    sys.path.insert(0, str(runtime))

