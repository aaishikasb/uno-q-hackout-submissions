"""A bounded forward-push demo for use inside MiniAutoRobot.run_program.

The starting arrangement establishes the goal direction. FOMO supplies a ball
centroid; activation-box dimensions are not used as a distance measurement.
"""

from dataclasses import dataclass
import math
import time
from typing import Callable, Protocol, Sequence


class Detection(Protocol):
    label: str
    score: float
    center: tuple[float, float]


@dataclass(frozen=True)
class Observation:
    detections: Sequence[Detection]
    image_shape: tuple[int, ...]
    requested_at: float  # Same conservative timestamp as Camera.read_fresh.


@dataclass(frozen=True)
class PushConfig:
    speed: int = 100
    pulse_ms: int = 200
    max_pulses: int = 4
    max_run_seconds: float = 12.0
    min_ball_score: float = 0.80
    max_observation_age_seconds: float = 1.2
    center_left: float = 0.40
    center_right: float = 0.60
    # Verified robot-camera view: the real floor ball at (173,110) in
    # 320x240 is above the old midpoint cutoff. Exclude the upper 35%.
    floor_top: float = 0.35
    floor_bottom: float = 0.95
    confirm_frames: int = 2
    max_confirmation_gap_seconds: float = 2.0
    max_center_shift: float = 0.15

    def __post_init__(self):
        # Positive durations are essential: firmware interprets zero as
        # continuous motion. Keep this initial demo's movements short.
        if type(self.speed) is not int or not 1 <= self.speed <= 100:
            raise ValueError("Push demo speed must be an integer from 1 to 100")
        if type(self.pulse_ms) is not int or not 1 <= self.pulse_ms <= 200:
            raise ValueError("Push pulse must be an integer from 1 to 200 ms")
        if type(self.max_pulses) is not int or not 1 <= self.max_pulses <= 10:
            raise ValueError("Push demo must have 1 to 10 pulses")
        if type(self.confirm_frames) is not int or not 2 <= self.confirm_frames <= 5:
            raise ValueError("At least two independent frames must confirm the ball")
        values = (self.max_run_seconds, self.min_ball_score,
                  self.max_observation_age_seconds, self.center_left, self.center_right,
                  self.floor_top, self.floor_bottom, self.max_confirmation_gap_seconds,
                  self.max_center_shift)
        if not all(math.isfinite(v) for v in values):
            raise ValueError("Push parameters must be finite")
        if not (0 < self.max_run_seconds <= 30 and
                0 < self.max_observation_age_seconds <= 2 and
                0 < self.max_confirmation_gap_seconds <= 3 and
                0 < self.max_center_shift <= .25 and
                .5 <= self.min_ball_score <= 1 and
                0 <= self.center_left < self.center_right <= 1 and
                0 <= self.floor_top < self.floor_bottom <= 1):
            raise ValueError("Push parameters are outside the demo's limits")


@dataclass(frozen=True)
class Decision:
    action: str  # confirm, forward, or stop
    reason: str


class PushPolicy:
    def __init__(self, config: PushConfig):
        self.config = config
        self.previous = None
        self.confirmed = 0

    def reset(self):
        self.previous = None
        self.confirmed = 0

    def stop(self, reason):
        self.reset()
        return Decision("stop", reason)

    def decide(self, observation: Observation, now: float) -> Decision:
        config = self.config
        age = now - observation.requested_at
        if not math.isfinite(age) or not 0 <= age <= config.max_observation_age_seconds:
            return self.stop(f"image age {age:.2f}s exceeds the movement limit")
        height, width = observation.image_shape[:2]
        if height <= 0 or width <= 0:
            return self.stop("invalid camera frame size")
        candidates = []
        for detection in observation.detections:
            if detection.label != "soccerball":
                continue
            score = detection.score
            cx, cy = detection.center
            if not all(math.isfinite(v) for v in (score, cx, cy)) or not 0 <= score <= 1:
                return self.stop("invalid ball detection")
            x, y = cx / width, cy / height
            if (score >= config.min_ball_score and 0 <= x <= 1 and
                    config.floor_top <= y <= config.floor_bottom):
                candidates.append((x, y))
        if not candidates:
            return self.stop(
                f"no ball meets score>={config.min_ball_score:.2f} and floor "
                f"y=[{config.floor_top * height:.0f},{config.floor_bottom * height:.0f}]; "
                "check the ball position in the preview"
            )
        if len(candidates) != 1:
            return self.stop("multiple possible balls; target is ambiguous")
        x, y = candidates[0]
        if x < config.center_left:
            return self.stop("ball is LEFT; align the robot with the ball before restarting")
        if x > config.center_right:
            return self.stop("ball is RIGHT; align the robot with the ball before restarting")
        if self.previous is not None:
            old_x, old_y, old_time = self.previous
            gap = observation.requested_at - old_time
            if not 0 < gap <= config.max_confirmation_gap_seconds:
                return self.stop("confirmation did not use two recent independent reads")
            if math.hypot(x - old_x, y - old_y) > config.max_center_shift:
                return self.stop("ball position changed too much between confirmations")
        self.previous = (x, y, observation.requested_at)
        self.confirmed += 1
        if self.confirmed < config.confirm_frames:
            return Decision("confirm", f"centered ball confirmed {self.confirmed}/{config.confirm_frames}")
        # Each movement requires a completely new set of confirmations.
        self.reset()
        return Decision("forward", "centered ball confirmed on consecutive floor observations")


def run_push_demo(
    robot, observe: Callable[[], Observation], check_running: Callable[[], None],
    config: PushConfig = PushConfig(), log: Callable[[str], None] = print,
    clock: Callable[[], float] = time.monotonic,
) -> tuple[int, str]:
    """Return (pulse count, reason); caller's run_program stops on every exit.

robot.drive waits for the MCU-timed pulse to finish. All camera reads and
confirmations therefore occur while the previous pulse's motors are stopped.
"""
    policy = PushPolicy(config)
    deadline = clock() + config.max_run_seconds
    pulses = 0

    def finish(reason):
        log(f"[PUSH] STOP: {reason}; pulses={pulses}/{config.max_pulses}")
        return pulses, reason

    log(f"[PUSH] limits: speed={config.speed} pulse={config.pulse_ms}ms "
        f"max_pulses={config.max_pulses} time={config.max_run_seconds:g}s "
        f"min_score={config.min_ball_score:.2f} "
        f"floor_y={config.floor_top:.2f}..{config.floor_bottom:.2f}")
    while pulses < config.max_pulses:
        check_running()
        if clock() >= deadline:
            return finish("run time limit reached")
        observation = observe()  # Camera/model failures propagate to run_program.
        check_running()
        now = clock()
        if now >= deadline:
            return finish("run time limit reached")
        decision = policy.decide(observation, now)
        log(f"[PUSH] {decision.action.upper()}: {decision.reason}")
        if decision.action == "stop":
            return finish(decision.reason)
        if decision.action == "confirm":
            continue
        check_running()
        now = clock()
        age = now - observation.requested_at
        if not 0 <= age <= config.max_observation_age_seconds:
            return finish("image became stale before issuing the pulse")
        # Include the documented Python wrapper's 100ms settling wait.
        if now + config.pulse_ms / 1000 + .1 >= deadline:
            return finish("insufficient time remaining for a complete pulse")
        log(f"[ACTION] forward speed={config.speed} ms={config.pulse_ms} "
            f"pulse={pulses + 1}/{config.max_pulses}")
        robot.drive("forward", speed=config.speed, ms=config.pulse_ms)
        pulses += 1
        check_running()
    return finish("pulse limit reached; press BOOT for another run")
