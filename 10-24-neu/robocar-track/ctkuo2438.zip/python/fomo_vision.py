"""FOMO image inference; reported regions describe activations, not object size."""

from dataclasses import dataclass
import math
from pathlib import Path
import sys
import time

import cv2
import numpy as np

# Ship the small official SDK image/runner subset with the app for offline use.
sys.path.insert(0, str(Path(__file__).resolve().parent / "vendor"))
from edge_impulse_linux.runner import ImpulseRunner
from edge_impulse_linux.image import get_features_from_image_with_studio_mode


@dataclass(frozen=True)
class FomoDetection:
    label: str
    score: float
    center: tuple[float, float]  # Coordinates in the original camera frame.
    activation_box: tuple[int, int, int, int]  # Never use this for distance.


def decode_fomo(
    response: dict, image_shape: tuple[int, ...], model_size: tuple[int, int],
    confidence: float,
) -> list[FomoDetection]:
    boxes = response.get("result", {}).get("bounding_boxes")
    if not isinstance(boxes, list):
        raise ValueError("EIM did not return FOMO bounding_boxes")
    height, width = image_shape[:2]
    model_width, model_height = model_size
    found = []
    for box in boxes:
        label = box.get("label")
        if label not in {"goal", "soccerball"}:
            continue
        score = float(box["value"])
        if not math.isfinite(score) or not 0 <= score <= 1:
            raise ValueError("EIM returned an invalid confidence")
        if score < confidence:
            continue
        x, y, w, h = (float(box[key]) for key in ("x", "y", "width", "height"))
        if not all(math.isfinite(v) for v in (x, y, w, h)) or w <= 0 or h <= 0:
            raise ValueError("EIM returned an invalid activation region")
        x1, y1 = max(0., x), max(0., y)
        x2, y2 = min(float(model_width), x + w), min(float(model_height), y + h)
        if x2 <= x1 or y2 <= y1:
            continue
        # Squash rescales each axis separately and retains the whole image.
        scale_x, scale_y = width / model_width, height / model_height
        center = ((x1 + x2) / 2 * scale_x, (y1 + y2) / 2 * scale_y)
        activation = (
            min(width - 1, round(x1 * scale_x)),
            min(height - 1, round(y1 * scale_y)),
            min(width - 1, round(x2 * scale_x)),
            min(height - 1, round(y2 * scale_y)),
        )
        found.append(FomoDetection(label, score, center, activation))
    return sorted(found, key=lambda item: item.score, reverse=True)


class FomoDetector:
    def __init__(self, model_path: str) -> None:
        model = Path(model_path).resolve()
        if not model.is_file():
            raise FileNotFoundError(f"Copy the UNO Q FOMO .eim model to {model}")
        # ADB transfers may reset permissions; this is our project-local model.
        if not model.stat().st_mode & 0o100:
            model.chmod(model.stat().st_mode | 0o100)
        self.runner = ImpulseRunner(str(model), timeout=2, allow_shm=False)
        self.ready = False
        self.last_input_rgb = None
        try:
            self.info = self.runner.init()
            parameters = self.info["model_parameters"]
            if parameters["model_type"] != "constrained_object_detection":
                raise ValueError("Expected a FOMO constrained_object_detection model")
            if set(parameters["labels"]) != {"goal", "soccerball"}:
                raise ValueError(f"Unexpected model labels: {parameters['labels']}")
            if parameters["image_channel_count"] != 3:
                raise ValueError("Expected an RGB model")
            if parameters.get("image_resize_mode") != "squash":
                raise ValueError("This adapter expects Studio resize mode 'squash'")
            self.size = (int(parameters["image_input_width"]),
                         int(parameters["image_input_height"]))
            if min(self.size) <= 0 or parameters["input_features_count"] != math.prod(self.size):
                raise ValueError("Expected one packed RGB feature per input pixel")
            thresholds = [float(t["min_score"]) for t in parameters.get("thresholds", [])
                          if t.get("type") == "object_detection"]
            self.confidence = max([0.5, *thresholds])
            if not math.isfinite(self.confidence) or self.confidence > 1:
                raise ValueError("Invalid model threshold")
            # Allocate the EIM engine before waiting for the BOOT button.
            warmup = self.runner.classify([0] * math.prod(self.size))
            decode_fomo(warmup, (self.size[1], self.size[0], 3), self.size, self.confidence)
            self.ready = True
        except BaseException:
            self.close()
            raise

    def detect(self, image: np.ndarray) -> tuple[list[FomoDetection], float]:
        if not self.ready:
            raise RuntimeError("FOMO process stopped; Stop and Run the app to restart it")
        if image.ndim != 3 or image.shape[2] != 3 or image.dtype != np.uint8:
            raise ValueError("Expected a uint8 BGR camera image")
        started_at = time.monotonic()
        # SDK expects RGB. It resizes with Studio's squash mode and encodes
        # each pixel as 0xRRGGBB. The .eim performs normalization/quantization.
        rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        features, self.last_input_rgb = get_features_from_image_with_studio_mode(
            rgb, "squash", self.size[0], self.size[1], False,
        )
        try:
            response = self.runner.classify(features)
            detections = decode_fomo(response, image.shape, self.size, self.confidence)
        except BaseException:
            # Do not let a delayed response become the next frame's result.
            self.close()
            raise
        return detections, (time.monotonic() - started_at) * 1000

    def close(self) -> None:
        self.ready = False
        self.runner.stop()


def annotate_fomo(image: np.ndarray, detections: list[FomoDetection]) -> np.ndarray:
    result = image.copy()
    height, width = result.shape[:2]
    for x in (round(width * 0.4), round(width * 0.6)):
        cv2.line(result, (x, 0), (x, height - 1), (0, 220, 220), 1)
    for detection in detections:
        color = (0, 255, 0) if detection.label == "soccerball" else (0, 165, 255)
        x, y = (round(v) for v in detection.center)
        cv2.drawMarker(result, (x, y), color, cv2.MARKER_CROSS, 12, 2)
        cv2.putText(result, f"{detection.label} {detection.score:.2f}",
                    (max(0, min(x - 20, width - 130)), max(12, y - 8)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.4, color, 1)
    return result
