import json
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "python"))
from capture_store import CaptureSession


class CaptureStoreTests(unittest.TestCase):
    def save(self, session):
        return session.save(
            b"\xff\xd8original-camera-payload\xff\xd9", 320, 240,
            requested_at=12.0, camera_ms=400., inference_ms=40., age_seconds=.45,
            predictions=[{"label": "soccerball", "score": .8, "center": [160., 120.]}],
        )

    def test_originals_remain_unlabelled_and_sessions_have_distinct_import_names(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            first = CaptureSession(root, "camera", "fomo.eim")
            second = CaptureSession(root, "camera", "fomo.eim")
            image = self.save(first)
            other_image = self.save(second)
            self.assertNotEqual(image.name, other_image.name)
            self.assertEqual(image.read_bytes(), b"\xff\xd8original-camera-payload\xff\xd9")
            metadata = json.loads((first.path / "session.json").read_text())
            self.assertIn("not ground truth", metadata["annotation_status"])
            self.assertNotIn("labels", metadata)
            self.assertEqual(metadata["frames"][0]["file"], image.name)
            self.assertEqual(metadata["frames"][0]["width"], 320)
            self.assertEqual(metadata["frames"][0]["predictions_for_review"][0]["score"], .8)

    def test_limit_keeps_existing_photos_and_partial_jpeg_is_not_archived(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            session = CaptureSession(root, "camera", "fomo.eim", max_images=1)
            with self.assertRaises(ValueError):
                session.save(b"partial", 320, 240, requested_at=0., camera_ms=0.,
                             inference_ms=0., age_seconds=0., predictions=[])
            self.assertEqual(list(session.path.glob("*.jpg")), [])
            image = self.save(session)
            with self.assertRaises(OSError):
                self.save(session)
            with self.assertRaises(OSError):
                CaptureSession(root, "camera", "fomo.eim", max_images=1)
            self.assertTrue(image.exists())
            self.assertEqual(len(list(root.glob("session-*/frame-*.jpg"))), 1)


if __name__ == "__main__":
    unittest.main()
