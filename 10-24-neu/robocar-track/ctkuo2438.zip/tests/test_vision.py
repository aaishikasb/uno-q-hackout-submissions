import io
import contextlib
from http.client import HTTPResponse
from email.message import Message
from pathlib import Path
import sys
import unittest
from unittest.mock import patch
from urllib.error import HTTPError

import cv2
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "python"))
from ball_vision import Camera, CameraConnectionError, decode_predictions, letterbox


class Response(io.BytesIO):
    def __init__(self, content):
        super().__init__(content)
        self.headers = Message()
        self.headers["Content-Type"] = "multipart/x-mixed-replace"


class PausingSource(io.RawIOBase):
    """A live server that has sent frames but has not sent the next one yet."""
    def __init__(self, payload):
        self.payload = memoryview(payload)
        self.position = 0

    def readable(self):
        return True

    def readinto(self, target):
        if self.position == len(self.payload):
            raise TimeoutError("Waiting for the camera's next frame")
        size = min(len(target), len(self.payload) - self.position)
        target[:size] = self.payload[self.position:self.position + size]
        self.position += size
        return size


def live_http_response(frames):
    body = b""
    for frame in frames:
        part = b"--frame\r\nContent-Type: image/jpeg\r\n\r\n" + frame + b"\r\n"
        body += f"{len(part):X}\r\n".encode() + part + b"\r\n"
    payload = (b"HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n"
               b"Content-Type: multipart/x-mixed-replace\r\n\r\n" + body)
    class Socket:
        def makefile(self, mode):
            return io.BufferedReader(PausingSource(payload))
    response = HTTPResponse(Socket())
    response.begin()
    return response


class VisionTests(unittest.TestCase):
    @staticmethod
    def jpeg(color):
        ok, jpeg = cv2.imencode(".jpg", np.full((24, 32, 3), color, np.uint8))
        assert ok
        return jpeg.tobytes()

    def test_recovery_uses_a_new_connection_and_discards_all_failed_frames(self):
        clock = [10.]

        class StallingResponse(Response):
            def read1(self, size):
                data = super().read1(size)
                if not data:
                    clock[0] += 3
                    raise TimeoutError("interrupted stream")
                return data

        red, green, blue = (self.jpeg(c) for c in
                            ((0, 0, 255), (0, 255, 0), (255, 0, 0)))
        failed = StallingResponse(red + red + b"\xff\xd8incomplete")
        recovered = Response(green + green + blue)
        with patch("ball_vision.build_opener") as build, \
             patch("ball_vision.time.monotonic", side_effect=lambda: clock[0]), \
             patch("ball_vision.time.sleep", side_effect=lambda seconds: clock.__setitem__(0, clock[0] + seconds)), \
             contextlib.redirect_stdout(io.StringIO()) as output:
            build.return_value.open.side_effect = [failed, recovered]
            frame = Camera(retry_attempts=1).read_fresh(lambda: None)
        self.assertEqual(build.return_value.open.call_count, 2)
        self.assertTrue(failed.closed and recovered.closed)
        self.assertGreater(float(frame.image[:, :, 0].mean()), 250)
        self.assertLess(float(frame.image[:, :, 1:].mean()), 5)
        self.assertEqual(frame.requested_at, 13.25)
        self.assertEqual(frame.jpeg, blue)
        self.assertIn("reconnecting 1/1", output.getvalue())

    def test_persistent_failure_has_only_one_recovery_attempt(self):
        with patch("ball_vision.build_opener") as build, \
             patch("ball_vision.time.sleep"), contextlib.redirect_stdout(io.StringIO()):
            build.return_value.open.side_effect = TimeoutError("camera unavailable")
            with self.assertRaises(CameraConnectionError):
                Camera(retry_attempts=1).read_fresh(lambda: None)
        self.assertEqual(build.return_value.open.call_count, 2)

    def test_boot_stop_during_recovery_cannot_open_a_second_stream(self):
        class ProgramStopped(Exception):
            pass
        with patch("ball_vision.build_opener") as build, patch("ball_vision.time.sleep") as pause:
            build.return_value.open.side_effect = TimeoutError("camera unavailable")
            checks = iter((None, ProgramStopped()))

            def check():
                result = next(checks)
                if result:
                    raise result

            with self.assertRaises(ProgramStopped):
                Camera(retry_attempts=1).read_fresh(check)
        build.return_value.open.assert_called_once()
        pause.assert_not_called()

    def test_http_status_error_is_not_retried(self):
        with patch("ball_vision.build_opener") as build:
            build.return_value.open.side_effect = HTTPError("http://camera/stream", 404, "Not found", {}, None)
            with self.assertRaises(HTTPError):
                Camera(retry_attempts=1).read_fresh(lambda: None)
        build.return_value.open.assert_called_once()

    def test_control_bridge_timeout_is_not_misclassified_as_a_camera_fault(self):
        with patch("ball_vision.build_opener") as build:
            def check():
                raise TimeoutError("Bridge request timed out")
            with self.assertRaisesRegex(TimeoutError, "Bridge request"):
                Camera(retry_attempts=1).read_fresh(check)
        build.return_value.open.assert_not_called()

    def test_http_handshake_timeout_is_identified_before_any_image_is_decoded(self):
        with patch("ball_vision.build_opener") as build:
            build.return_value.open.side_effect = TimeoutError("timed out")
            with patch("ball_vision.cv2.imdecode") as decode:
                with self.assertRaisesRegex(CameraConnectionError, "before receiving an image"):
                    Camera().read_fresh(lambda: None)
                decode.assert_not_called()

    def test_original_camera_coordinates_and_duplicate_suppression(self):
        image = np.zeros((240, 320, 3), np.uint8)
        _, ratio, left, top = letterbox(image)
        output = np.zeros((1, 84, 3), np.float32)
        output[0, :4, 0] = [160, 160, 60, 60]
        output[0, 36, 0] = 0.9
        output[0, :4, 1] = [161, 160, 60, 60]
        output[0, 36, 1] = 0.7
        output[0, :4, 2] = [60, 60, 40, 40]
        output[0, 4, 2] = 0.99  # A confident person must not become a ball.
        found = decode_predictions(output, image.shape, ratio, left, top)
        self.assertEqual(len(found), 1)
        self.assertEqual(found[0].box, (130, 90, 190, 150))
        self.assertEqual(found[0].center, (160, 120))

    def test_fresh_read_discards_the_two_buffered_frames(self):
        parts = []
        for color in [(0, 0, 255), (0, 255, 0), (255, 0, 0)]:
            image = np.full((24, 32, 3), color, np.uint8)
            ok, jpeg = cv2.imencode(".jpg", image)
            self.assertTrue(ok)
            parts.append(b"--frame\r\nContent-Type: image/jpeg\r\n\r\n" + jpeg.tobytes())
        with patch("ball_vision.build_opener") as build:
            build.return_value.open.return_value = Response(b"\r\n".join(parts))
            frame = Camera().read_fresh(lambda: None)
        self.assertGreater(float(frame.image[:, :, 0].mean()), 250)
        self.assertLess(float(frame.image[:, :, 1:].mean()), 5)

    def test_complete_frame_does_not_wait_for_the_next_http_chunk(self):
        frames = []
        for color in [(0, 0, 255), (0, 255, 0), (255, 0, 0)]:
            ok, jpeg = cv2.imencode(".jpg", np.full((24, 32, 3), color, np.uint8))
            self.assertTrue(ok)
            frames.append(jpeg.tobytes())
        # The former fixed-size read loses already-arrived frames when the
        # next HTTP chunk pauses. Exercise Python's real HTTPResponse parser.
        with live_http_response(frames) as response:
            with self.assertRaises(TimeoutError):
                response.read(4096)
        with patch("ball_vision.build_opener") as build:
            build.return_value.open.return_value = live_http_response(frames)
            frame = Camera().read_fresh(lambda: None)
        self.assertGreater(float(frame.image[:, :, 0].mean()), 250)


if __name__ == "__main__":
    unittest.main()
