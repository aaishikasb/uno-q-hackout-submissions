from dataclasses import dataclass
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "python"))
from push_policy import Observation, PushConfig, PushPolicy, run_push_demo


@dataclass(frozen=True)
class Ball:
    center: tuple[float, float] = (160., 180.)
    score: float = .9
    label: str = "soccerball"


def observation(detections=None, at=1.):
    return Observation(tuple([Ball()] if detections is None else detections), (240, 320, 3), at)


class PolicyTests(unittest.TestCase):
    def test_two_independent_centered_frames_are_required_after_every_pulse(self):
        policy = PushPolicy(PushConfig())
        self.assertEqual(policy.decide(observation(at=1), 1.1).action, "confirm")
        self.assertEqual(policy.decide(observation(at=1.5), 1.6).action, "forward")
        self.assertEqual(policy.decide(observation(at=2), 2.1).action, "confirm")
        self.assertEqual(policy.decide(observation(at=2.5), 2.6).action, "forward")

    def test_verified_ground_ball_above_old_midpoint_can_confirm_but_sky_still_cannot(self):
        policy = PushPolicy(PushConfig())
        self.assertEqual(policy.decide(observation([Ball(center=(173, 90), score=.97)], 1.),
                                       1.62).action, "confirm")
        self.assertEqual(policy.decide(observation([Ball(center=(173, 110), score=1.)], 1.8),
                                       2.46).action, "forward")
        self.assertEqual(policy.decide(observation([Ball(center=(173, 70), score=1.)], 3.),
                                       3.5).action, "stop")
        self.assertEqual(policy.decide(observation([Ball(center=(173, 110), score=1.)], 4.),
                                       5.3).action, "stop")

    def test_window_false_positive_missing_ambiguous_off_center_and_stale_stop(self):
        cases = [
            ([], 1., 1.1),
            ([Ball(score=.53)], 1., 1.1),
            ([Ball(center=(160, 70))], 1., 1.1),
            ([Ball(), Ball(center=(170, 180), score=.85)], 1., 1.1),
            ([Ball(center=(50, 180))], 1., 1.1),
            ([Ball(center=(270, 180))], 1., 1.1),
            ([Ball(center=(160, 239))], 1., 1.1),
            ([Ball(score=float("nan"))], 1., 1.1),
            ([Ball(label="goal")], 1., 1.1),
            ([Ball()], 1., 2.3),
            ([Ball()], 2., 1.),
        ]
        for detections, captured, now in cases:
            with self.subTest(detections=detections, now=now):
                policy = PushPolicy(PushConfig())
                policy.decide(observation(at=.5), .6)
                self.assertEqual(policy.decide(observation(detections, captured), now).action, "stop")
                self.assertEqual(policy.confirmed, 0)

    def test_replayed_old_confirmation_or_jumping_target_cannot_authorize_motion(self):
        for new_at, now, center in ((1., 1.2, (160, 180)), (3.1, 3.2, (160, 180)),
                                    (1.5, 1.6, (160, 105))):
            with self.subTest(new_at=new_at, center=center):
                policy = PushPolicy(PushConfig())
                policy.decide(observation(at=1), 1.1)
                self.assertEqual(policy.decide(observation([Ball(center=center)], new_at), now).action,
                                 "stop")

    def test_continuous_duration_or_unbounded_configuration_is_rejected(self):
        for values in ({"pulse_ms": 0}, {"pulse_ms": 5000}, {"speed": 255},
                       {"max_pulses": 0}, {"confirm_frames": 1}, {"max_run_seconds": float("inf")}):
            with self.subTest(values=values), self.assertRaises(ValueError):
                PushConfig(**values)


class Clock:
    def __init__(self):
        self.now = 0.

    def __call__(self):
        return self.now


class LoopTests(unittest.TestCase):
    def test_camera_is_sampled_after_each_completed_pulse_and_run_is_bounded(self):
        clock = Clock()
        events = []

        class Robot:
            def drive(self, direction, speed, ms):
                events.append(("move", direction, speed, ms))
                clock.now += ms / 1000 + .1

        def observe():
            start = clock.now
            clock.now += .1
            events.append(("observe", start))
            return observation(at=start)

        pulses, _ = run_push_demo(Robot(), observe, lambda: None, log=lambda _: None, clock=clock)
        self.assertEqual(pulses, 4)
        self.assertEqual([e[0] for e in events], ["observe", "observe", "move"] * 4)
        self.assertTrue(all(e[3] == 200 for e in events if e[0] == "move"))

    def test_deadline_expiring_during_capture_or_final_gate_prevents_movement(self):
        for expire_during_capture in (True, False):
            clock = Clock()
            moves = []
            captures = 0
            checks = 0

            class Robot:
                def drive(self, *args, **kwargs):
                    moves.append(args)

            def observe():
                nonlocal captures
                start = clock.now
                captures += 1
                clock.now += 20 if expire_during_capture else .1
                return observation(at=start)

            def gate():
                nonlocal checks
                checks += 1
                # Iteration 1: pre/post capture; iteration 2: pre/post capture,
                # then the last BOOT check immediately before the action.
                if not expire_during_capture and checks == 5:
                    clock.now += 2

            pulses, _ = run_push_demo(Robot(), observe, gate, log=lambda _: None, clock=clock)
            self.assertEqual(pulses, 0)
            self.assertEqual(moves, [])


class FirmwareGateTests(unittest.TestCase):
    def test_actual_rpc_bodies_reject_motion_after_boot_stop(self):
        compiler = shutil.which("clang++") or shutil.which("g++")
        if not compiler:
            self.skipTest("Host C++ compiler unavailable; full sketch build occurs in App Lab")
        source = (ROOT / "sketch/sketch.ino").read_text()
        bodies = []
        for name in ("rpcDrive", "rpcDriveRaw"):
            match = re.search(r"bool " + name + r"\([^)]*\) \{.*?\n\}", source, re.S)
            self.assertIsNotNone(match)
            bodies.append(match.group())
        harness = '''
#include <string>
#include <cassert>
using String = std::string;
bool programEnabled = false;
int stops = 0, drives = 0, rawDrives = 0;
void stopMotors() { ++stops; }
bool driveCommand(String command, int speed, int ms) {
    assert(command == "forward" && speed == 100 && ms == 100);
    ++drives; return true;
}
void driveRaw(int, int, int, int, int) { ++rawDrives; }
''' + "\n".join(bodies) + '''
int main() {
    assert(!rpcDrive("forward", 100, 100));
    assert(!rpcDriveRaw(100, 100, 100, 100, 100));
    assert(stops == 2 && drives == 0 && rawDrives == 0);
    programEnabled = true;
    assert(rpcDrive("forward", 100, 100));
    assert(rpcDriveRaw(100, 100, 100, 100, 100));
    programEnabled = false;
    assert(!rpcDrive("forward", 100, 100));
    assert(drives == 1 && rawDrives == 1 && stops == 3);
}
'''
        with tempfile.TemporaryDirectory() as directory:
            cpp = Path(directory) / "gate.cpp"
            binary = Path(directory) / "gate"
            cpp.write_text(harness)
            subprocess.run([compiler, "-std=c++17", str(cpp), "-o", str(binary)],
                           check=True, capture_output=True, timeout=30)
            subprocess.run([str(binary)], check=True, capture_output=True, timeout=5)


if __name__ == "__main__":
    unittest.main()
