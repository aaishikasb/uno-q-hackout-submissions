"""Adapter and lifecycle regressions; the real ARM64 EIM runs on the UNO Q."""

import contextlib
import copy
import io
import json
from pathlib import Path
import runpy
import sys
import tempfile
import time
import types
import unittest
from unittest.mock import Mock, patch

import cv2
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "python"))
from ball_vision import Snapshot
from fomo_vision import FomoDetection, FomoDetector, decode_fomo
from edge_impulse_linux.runner import ImpulseRunner


PARAMETERS = {
    "model_type": "constrained_object_detection", "labels": ["goal", "soccerball"],
    "image_channel_count": 3, "image_resize_mode": "squash",
    "image_input_width": 96, "image_input_height": 96, "input_features_count": 9216,
    "thresholds": [{"type": "object_detection", "min_score": 0.5}],
}


def response(boxes=()):
    return {"result": {"bounding_boxes": list(boxes)}}


class FomoAdapterTests(unittest.TestCase):
    def test_rgb_encoding_keeps_both_sides_and_maps_positions_to_original_image(self):
        runner = Mock()
        runner.init.return_value = {"model_parameters": copy.deepcopy(PARAMETERS)}
        runner.classify.side_effect = [response(), response([
            {"label": "soccerball", "value": 0.9, "x": 44, "y": 44, "width": 8, "height": 8},
            {"label": "goal", "value": 0.8, "x": 8, "y": 16, "width": 8, "height": 16},
            {"label": "soccerball", "value": 0.49, "x": 80, "y": 16, "width": 8, "height": 8},
        ])]
        with patch("fomo_vision.ImpulseRunner", return_value=runner) as factory:
            detector = FomoDetector(str(ROOT / "python/models/fomo-soccer-goal.eim"))
        factory.assert_called_once_with(str(ROOT / "python/models/fomo-soccer-goal.eim"),
                                        timeout=2, allow_shm=False)
        image = np.zeros((240, 320, 3), np.uint8)
        image[:, :160] = (0, 0, 255)  # BGR red
        image[:, 160:] = (255, 0, 0)  # BGR blue
        detections, _ = detector.detect(image)
        features = runner.classify.call_args.args[0]
        self.assertEqual(len(features), 9216)
        self.assertEqual(features[0], 0xFF0000)
        self.assertEqual(features[-1], 0x0000FF)
        self.assertEqual([(d.label, d.center) for d in detections],
                         [("soccerball", (160, 120)), ("goal", (40, 60))])
        self.assertEqual(detections[1].activation_box, (27, 40, 53, 80))
        detector.close()
        runner.stop.assert_called_once()

    def test_incompatible_preprocessing_closes_process(self):
        runner = Mock()
        parameters = copy.deepcopy(PARAMETERS)
        parameters["image_resize_mode"] = "fit-shortest"
        runner.init.return_value = {"model_parameters": parameters}
        with patch("fomo_vision.ImpulseRunner", return_value=runner):
            with self.assertRaisesRegex(ValueError, "squash"):
                FomoDetector(str(ROOT / "python/models/fomo-soccer-goal.eim"))
        runner.stop.assert_called_once()

    def test_timeout_discards_process_and_cannot_reuse_late_response(self):
        runner = Mock()
        runner.init.return_value = {"model_parameters": copy.deepcopy(PARAMETERS)}
        runner.classify.side_effect = [response(), TimeoutError("model stalled")]
        with patch("fomo_vision.ImpulseRunner", return_value=runner):
            detector = FomoDetector(str(ROOT / "python/models/fomo-soccer-goal.eim"))
        image = np.zeros((240, 320, 3), np.uint8)
        with self.assertRaises(TimeoutError):
            detector.detect(image)
        runner.stop.assert_called_once()
        with self.assertRaisesRegex(RuntimeError, "Stop and Run"):
            detector.detect(image)
        self.assertEqual(runner.classify.call_count, 2)

    def test_empty_unknown_invalid_and_outside_regions(self):
        self.assertEqual(decode_fomo(response(), (240, 320, 3), (96, 96), .5), [])
        self.assertEqual(decode_fomo(response([
            {"label": "person", "value": .99},
            {"label": "goal", "value": .9, "x": 100, "y": 0, "width": 8, "height": 8},
        ]), (240, 320, 3), (96, 96), .5), [])
        with self.assertRaisesRegex(ValueError, "confidence"):
            decode_fomo(response([{"label": "goal", "value": float("nan")}]),
                        (240, 320, 3), (96, 96), .5)
        with self.assertRaisesRegex(ValueError, "bounding_boxes"):
            decode_fomo({}, (240, 320, 3), (96, 96), .5)


class EimTransportTests(unittest.TestCase):
    def test_fragmented_nul_response_and_complete_feature_send(self):
        runner = ImpulseRunner("unused", timeout=2, allow_shm=False)
        client = runner._client = Mock()
        client.recv.side_effect = [b'{"id":1,"success":true,"result":',
                                   b'{"bounding_boxes":[]}}', b'\x00']
        self.assertEqual(runner.classify([0xFF0000] * 9216), response())
        message = json.loads(client.sendall.call_args.args[0])
        self.assertEqual(len(message["classify"]), 9216)
        self.assertEqual(message["id"], 1)
        runner.stop()

    def test_model_eof_and_absolute_deadline(self):
        runner = ImpulseRunner("unused", timeout=2, allow_shm=False)
        client = runner._client = Mock()
        client.recv.return_value = b""
        with self.assertRaisesRegex(ConnectionError, "closed its socket"):
            runner.hello()
        with patch("edge_impulse_linux.runner.time.monotonic", side_effect=[0, 3]):
            with self.assertRaises(TimeoutError):
                runner.hello()
        runner.stop()

    def test_crashed_and_stalled_startups_are_bounded(self):
        model = str(ROOT / "python/models/fomo-soccer-goal.eim")
        for status, expected in ((7, RuntimeError), (None, TimeoutError)):
            with self.subTest(status=status):
                process = Mock()
                process.poll.return_value = status
                runner = ImpulseRunner(model, timeout=2, allow_shm=False)
                with patch("edge_impulse_linux.runner.subprocess.Popen", return_value=process), \
                     patch("edge_impulse_linux.runner.time.sleep", side_effect=AssertionError("startup loop")), \
                     patch("edge_impulse_linux.runner.time.monotonic", side_effect=[0, 11]):
                    with self.assertRaises(expected):
                        runner.init()
                self.assertIsNone(runner._runner)
                self.assertIsNone(runner._tempdir)


class ObservationLifecycleTests(unittest.TestCase):
    def run_app(self, directory, stale=False, cancel=False, mode="observe", camera_error=None):
        class ProgramStopped(Exception):
            pass

        class Robot:
            def __init__(self):
                self.running = False
                self.stops = 0
                self.drives = []

            def stop(self):
                self.stops += 1
                self.running = False

            def health(self):
                return {"bridge": True}

            def is_running(self):
                return self.running

            def run_program(self, routine):
                self.running = True  # Simulate one deliberate BOOT press.
                try:
                    routine()
                except ProgramStopped:
                    pass
                finally:
                    self.stop()

            def drive(self, *args, **kwargs):
                if mode == "observe":
                    raise AssertionError("Observation must not request motion")
                self.drives.append((args, kwargs))

            servo = drive
            drive_raw = drive

        robot = Robot()
        detector = Mock(size=(96, 96), confidence=.5,
                        last_input_rgb=np.zeros((96, 96, 3), np.uint8))
        detector.detect.return_value = ([
            FomoDetection("soccerball", .9, (160, 120), (140, 100, 180, 140)),
            FomoDetection("goal", .8, (40, 60), (20, 40, 60, 80)),
        ], 10.)

        def read_frame(check):
            check()
            if camera_error:
                raise camera_error
            if cancel:
                robot.running = False
            image = np.zeros((240, 320, 3), np.uint8)
            ok, jpeg = cv2.imencode(".jpg", image)
            assert ok
            return Snapshot(image, time.monotonic() - (3 if stale else 0), jpeg.tobytes())

        camera = Mock(url="http://192.168.5.1:81/stream")
        camera.read_fresh.side_effect = read_frame
        utils = types.ModuleType("arduino.app_utils")
        utils.App = types.SimpleNamespace(run=lambda user_loop: user_loop())
        client = types.ModuleType("robot_client")
        client.MiniAutoRobot = lambda: robot
        client.ProgramStopped = ProgramStopped
        main = Path(directory) / "python/main.py"
        main.parent.mkdir()
        main.write_bytes((ROOT / "python/main.py").read_bytes())
        output = io.StringIO()
        with patch.dict(sys.modules, {"arduino": types.ModuleType("arduino"),
                                      "arduino.app_utils": utils, "robot_client": client}), \
             patch("ball_vision.Camera", return_value=camera) as camera_factory, \
             patch("fomo_vision.FomoDetector", return_value=detector), \
             patch("robot_mode.MODE", mode), \
             patch("time.sleep"), contextlib.redirect_stdout(output), contextlib.redirect_stderr(output):
            runpy.run_path(str(main), run_name="__main__")
        camera_factory.assert_called_once_with(retry_attempts=1 if mode == "observe" else 0)
        return robot, detector, output.getvalue()

    def test_five_frames_report_both_labels_and_save_preview_without_motion(self):
        with tempfile.TemporaryDirectory() as directory:
            robot, detector, output = self.run_app(directory)
            self.assertEqual(detector.detect.call_count, 5)
            self.assertEqual(output.count("[BALL] count=1"), 5)
            self.assertEqual(output.count("[GOAL] count=1"), 5)
            self.assertIn("center=(160,120) position=CENTER", output)
            self.assertIn("center=(40,60) position=LEFT", output)
            self.assertEqual(robot.stops, 3)
            detector.close.assert_called_once()
            self.assertEqual(cv2.imread(str(Path(directory) / "data/vision-latest.jpg")).shape,
                             (240, 320, 3))
            self.assertEqual(cv2.imread(str(Path(directory) / "data/vision-raw-latest.jpg")).shape,
                             (240, 320, 3))
            self.assertEqual(cv2.imread(str(Path(directory) / "data/vision-model-input-latest.jpg")).shape,
                             (96, 96, 3))
            captures = list((Path(directory) / "data/captures").glob("session-*/frame-*.jpg"))
            self.assertEqual(len(captures), 5)
            self.assertTrue(all(cv2.imread(str(path)).shape == (240, 320, 3) for path in captures))
            metadata = json.loads((captures[0].parent / "session.json").read_text())
            self.assertIn("unlabelled", metadata["annotation_status"])
            self.assertEqual(len(metadata["frames"]), 5)
            self.assertIn("[CAPTURE] saved 5 original photos", output)

    def test_capture_storage_failure_does_not_request_motion_or_break_observation(self):
        with tempfile.TemporaryDirectory() as directory, \
             patch("capture_store.CaptureSession.save", side_effect=OSError("disk full")):
            robot, detector, output = self.run_app(directory)
            self.assertEqual(detector.detect.call_count, 5)
            self.assertIn("[CAPTURE] photo not saved: disk full", output)
            self.assertEqual(robot.drives, [])
            self.assertEqual(robot.stops, 3)

    def test_stale_or_cancelled_frames_end_run_without_reporting_detections(self):
        for stale, cancel in ((True, False), (False, True)):
            with self.subTest(stale=stale, cancel=cancel), tempfile.TemporaryDirectory() as directory:
                robot, detector, output = self.run_app(directory, stale, cancel)
                self.assertNotIn("[BALL] count", output)
                self.assertFalse((Path(directory) / "data/vision-latest.jpg").exists())
                self.assertEqual(robot.stops, 3)
                if stale:
                    self.assertIn("refusing stale results", output)
                else:
                    detector.detect.assert_not_called()

    def test_push_mode_requires_new_confirmations_for_each_bounded_pulse(self):
        with tempfile.TemporaryDirectory() as directory:
            robot, detector, output = self.run_app(directory, mode="push")
            self.assertEqual(len(robot.drives), 4)
            self.assertEqual(detector.detect.call_count, 8)
            self.assertTrue(all(args == ("forward",) and kwargs == {"speed": 100, "ms": 200}
                                for args, kwargs in robot.drives))
            self.assertIn("pulse limit reached", output)
            self.assertEqual(robot.stops, 3)
            self.assertFalse((Path(directory) / "data/captures").exists())

    def test_push_mode_camera_failure_or_boot_stop_cannot_issue_motion(self):
        for cancel, error in ((True, None), (False, TimeoutError("camera unavailable"))):
            with self.subTest(cancel=cancel), tempfile.TemporaryDirectory() as directory:
                robot, detector, output = self.run_app(directory, mode="push", cancel=cancel,
                                                       camera_error=error)
                self.assertEqual(robot.drives, [])
                self.assertEqual(robot.stops, 3)
                detector.detect.assert_not_called()


if __name__ == "__main__":
    unittest.main()
