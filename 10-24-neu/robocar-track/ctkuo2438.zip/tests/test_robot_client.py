import contextlib
import io
import json
from pathlib import Path
import runpy
import sys
import types
import unittest
from unittest.mock import Mock, call, patch

ROOT = Path(__file__).resolve().parents[1]


class DriveAcknowledgementTests(unittest.TestCase):
    def client(self, responses):
        bridge = Mock()
        bridge.call.side_effect = responses
        utils = types.ModuleType("arduino.app_utils")
        utils.Bridge = bridge
        with patch.dict(sys.modules, {"arduino": types.ModuleType("arduino"),
                                      "arduino.app_utils": utils}):
            module = runpy.run_path(str(ROOT / "python/robot_client.py"))
        return module, bridge

    def test_rejected_or_missing_acknowledgement_cannot_be_reported_as_accepted(self):
        for response in (False, None, 1):
            with self.subTest(response=response):
                module, bridge = self.client([json.dumps({"program_enabled": True}), response])
                with patch("time.sleep") as sleep, contextlib.redirect_stdout(io.StringIO()) as log:
                    with self.assertRaisesRegex(RuntimeError, "MCU rejected"):
                        module["MiniAutoRobot"]().drive("forward", speed=100, ms=200)
                sleep.assert_not_called()
                self.assertNotIn("MCU accepted", log.getvalue())
                self.assertEqual(bridge.call.call_args_list,
                                 [call("read_sensors"), call("drive", "forward", 100, 200)])

    def test_accepted_command_waits_then_checks_boot_again(self):
        for still_enabled in (True, False):
            with self.subTest(still_enabled=still_enabled):
                module, bridge = self.client([json.dumps({"program_enabled": True}), True,
                                              json.dumps({"program_enabled": still_enabled})])
                with patch("time.sleep") as sleep, contextlib.redirect_stdout(io.StringIO()) as log:
                    if still_enabled:
                        module["MiniAutoRobot"]().drive("forward", speed=100, ms=200)
                    else:
                        with self.assertRaises(module["ProgramStopped"]):
                            module["MiniAutoRobot"]().drive("forward", speed=100, ms=200)
                self.assertAlmostEqual(sleep.call_args.args[0], .3)
                self.assertIn("[DRIVE] MCU accepted: forward speed=100 ms=200", log.getvalue())
                self.assertEqual(bridge.call.call_count, 3)

    def test_disabled_boot_cannot_send_a_drive_rpc(self):
        module, bridge = self.client([json.dumps({"program_enabled": False})])
        with self.assertRaises(module["ProgramStopped"]):
            module["MiniAutoRobot"]().drive("forward", speed=100, ms=200)
        bridge.call.assert_called_once_with("read_sensors")


if __name__ == "__main__":
    unittest.main()
