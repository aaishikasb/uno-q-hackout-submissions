"""Brain: pick the next short movement from what the camera sees.

No Bridge or camera here, so it runs on a laptop too:
    python3 strategy.py      # prints the chosen action for sample scenes
"""

from dataclasses import dataclass


@dataclass
class Target:
    x: float      # -1 (left edge) .. 0 (center) .. +1 (right edge)
    y: float      # 0 (top) .. 1 (bottom); lower in the frame = closer
    score: float  # detector confidence 0..1


@dataclass
class Goal:
    x: float      # aim point between the cones, -1 .. +1
    width: float  # gap between the two cones (0 if only one cone is seen)
    cones: int    # how many cones were detected (1 or 2)


@dataclass
class Observation:
    ball: Target        # main.py only calls decide_action when the ball is seen
    goal: Goal | None
    distance_cm: float  # ultrasonic; -1 means unknown
    allow_align: bool = True  # False once the align budget is used up: just chase and push


@dataclass
class Action:
    command: str          # forward / backward / left / right / rotate_left / rotate_right
    speed: int            # 0..255
    ms: int               # keep short and > 0 (0 = drive forever!)
    final: bool = False   # True ends the run after this pulse
    starts_dribble: bool = False  # True = ball is at the bumper; drive straight from now on
    aligning: bool = False        # True = a move made to line up with the goal (counts toward ALIGN_MAX_MOVES)


# ---- Tuning constants: fill in from your calibration table ----
# Speeds raised for carpet: 110-130 didn't move the car on the field.
# Turns/strafes are kept short so corrections don't overshoot at this speed.
CENTER_BAND = 0.15    # |ball.x| inside this counts as centered (dead band)
TURN_INSTEAD_X = 0.6  # ball further to the side than this: turn (sliding would take too long)
GOAL_BAND = 0.20      # ball and goal this close in x count as lined up
NEAR_Y = 0.62         # ball center below this line in the frame = near
                      # (the ball drops out of view at y ~0.7, so push before that)
LOST_NEAR_Y = 0.58    # ball vanished after being this low and centered = it's under the camera
NEAR_CM = 20          # or the ultrasonic says the ball is this close

TURN_LEFT = Action("rotate_left", 220, 100)
TURN_RIGHT = Action("rotate_right", 220, 100)
STRAFE_LEFT = Action("left", 220, 150)
STRAFE_RIGHT = Action("right", 220, 150)
APPROACH = Action("forward", 220, 250)
PUSH = Action("forward", 220, 500, starts_dribble=True)

# Dribbling: the ball sits in the camera's blind spot at the bumper. Drive straight
# (turning makes it slide off) and every few pulses back up to check it's still there.
DRIBBLE = Action("forward", 220, 350)
BACKUP = Action("backward", 220, 150)
CHECK_EVERY = 3           # back up and look after this many dribble pulses
DRIBBLE_MAX_PULSES = 12   # stop after this many dribble pulses
ESCAPED_Y = 0.5           # ball seen again higher than this while dribbling = it rolled away
STILL_THERE_Y = 0.5       # after backing up: ball at least this low and centered = still ours
DEFAULT_GOAL_WIDTH = 0.4  # gap between the cones in x, until we've seen both (logs: 0.33-0.66)

# Lining up (when both cones are seen): face the goal, then slide so the ball is on our line
HEADING_BAND = 0.15       # goal center within this of the image center = we face the goal
LINE_BAND = 0.12          # ball within this of the goal center (in x) = ball is on our line
ALIGN_MAX_MOVES = 15      # give up lining up after this many moves; just chase and push
FACE_GOAL_LEFT = Action("rotate_left", 220, 100, aligning=True)
FACE_GOAL_RIGHT = Action("rotate_right", 220, 100, aligning=True)
SLIDE_LEFT = Action("left", 220, 150, aligning=True)
SLIDE_RIGHT = Action("right", 220, 150, aligning=True)
MAKE_ROOM = Action("backward", 220, 150, aligning=True)  # too close to slide without bumping it


def is_near(obs: Observation) -> bool:
    return obs.ball.y >= NEAR_Y or 0 < obs.distance_cm <= NEAR_CM


def decide_action(obs: Observation) -> Action | None:
    """Rules in priority order; the first match wins. Return None to end the run.

    Safety rules (stale video, lost ball, time limit) already ran in main.py.
    """
    if obs.goal is not None and obs.allow_align:
        return line_up_action(obs)
    # No reliable goal (or align budget used up). We assume we still face roughly toward
    # the goal, so SLIDE to the ball (keeps the heading) instead of turning; only turn
    # when the ball is so far to the side that sliding would take too long.
    ball = obs.ball
    if ball.x < -TURN_INSTEAD_X:
        return TURN_LEFT
    if ball.x > TURN_INSTEAD_X:
        return TURN_RIGHT
    if ball.x < -CENTER_BAND:
        return STRAFE_LEFT
    if ball.x > CENTER_BAND:
        return STRAFE_RIGHT
    if not is_near(obs):
        return APPROACH
    return PUSH


def line_up_action(obs: Observation) -> Action:
    """Both cones are seen. Control direction and position separately:
    1. direction: turn until the goal center is straight ahead
    2. position: slide sideways until the ball is on our line to the goal
       (if the ball is already close, back up first to make room)
    3. lined up: drive forward through the ball toward the goal
    """
    ball, goal = obs.ball, obs.goal
    if goal.x < -HEADING_BAND:
        return FACE_GOAL_LEFT
    if goal.x > HEADING_BAND:
        return FACE_GOAL_RIGHT
    off = ball.x - goal.x  # we face the goal, so slide toward the ball's side
    if abs(off) > LINE_BAND:
        if is_near(obs):
            return MAKE_ROOM
        return SLIDE_RIGHT if off > 0 else SLIDE_LEFT
    if not is_near(obs):
        return APPROACH
    return PUSH


def lost_ball_action(last_ball: Target | None) -> Action | None:
    """The ball just disappeared: back up a little so the camera sees more of the
    floor in front (the ball is most often in the blind spot at the bumper).
    main.py does this once per disappearance, then counts misses."""
    return BACKUP


def estimate_goal(goal: Goal | None, last_width: float | None) -> Goal | None:
    """Turn what we see into an aim point at the goal center.

    Two cones: their midpoint. One cone: we can't tell which post it is, but a cone
    on the left of the image is most likely the left post (center to its right), and
    vice versa, so aim half a goal-width inward from it rather than at the post.
    """
    if goal is None or goal.cones >= 2:
        return goal
    half = (last_width or DEFAULT_GOAL_WIDTH) / 2
    x = goal.x + half if goal.x < 0 else goal.x - half
    return Goal(x=x, width=0.0, cones=1)


def ball_still_ours(ball: Target | None) -> bool:
    """After backing up: is the ball right in front of us, centered?"""
    return ball is not None and ball.y >= STILL_THERE_Y and abs(ball.x) <= CENTER_BAND


if __name__ == "__main__":
    G = lambda x: Goal(x, 0.4, 2)
    scenes = {
        "no goal: ball a bit left -> slide":        Observation(Target(-0.33, 0.6, 0.9), None, -1),
        "no goal: ball a bit right -> slide":       Observation(Target(0.25, 0.4, 0.9), None, -1),
        "no goal: ball far to the left -> turn":    Observation(Target(-0.75, 0.4, 0.9), None, -1),
        "no goal: ball centered far":               Observation(Target(0.0, 0.4, 0.9), None, -1),
        "no goal: ball centered near":              Observation(Target(0.0, 0.7, 0.9), None, -1),
        "goal off to the right -> face it":         Observation(Target(0.0, 0.4, 0.9), G(0.5), -1),
        "facing goal, ball right of line, far":     Observation(Target(0.4, 0.4, 0.9), G(0.0), -1),
        "facing goal, ball left of line, far":      Observation(Target(-0.4, 0.4, 0.9), G(0.0), -1),
        "facing goal, ball off line but close":     Observation(Target(0.4, 0.7, 0.9), G(0.0), -1),
        "lined up, far":                            Observation(Target(0.05, 0.4, 0.9), G(0.0), -1),
        "lined up, close":                          Observation(Target(0.05, 0.7, 0.9), G(0.0), -1),
        "one cone on the left (left post)":          Observation(Target(0.0, 0.4, 0.9), estimate_goal(Goal(-0.5, 0.0, 1), None), -1),
        "one cone on the right (right post)":        Observation(Target(0.0, 0.4, 0.9), estimate_goal(Goal(0.6, 0.0, 1), 0.5), -1),
        "align budget used up (ball left)":         Observation(Target(-0.6, 0.4, 0.9), G(0.5), -1, allow_align=False),
    }
    for name, obs in scenes.items():
        a = decide_action(obs)
        print(f"{name:40s} -> {a.command} {a.speed}/{a.ms}{'  (aligning)' if a.aligning else ''}")
