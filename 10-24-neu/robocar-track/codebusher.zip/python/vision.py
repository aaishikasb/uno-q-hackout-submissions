"""Eyes: newest camera frame + Edge Impulse detector -> ball and goal positions."""

import os
import stat
import threading
import time
from pathlib import Path
from urllib.request import urlopen

import cv2
import numpy as np

from strategy import Goal, Target

STREAM_URL = "http://192.168.5.1:81/stream"
MODEL_PATH = Path(__file__).with_name("uno-q-hackout-v2.eim")

# Labels from the UNO Q Hackout Edge Impulse project
BALL_LABEL = "soccerball"
GOAL_LABEL = "goal"   # one box per cone
MIN_SCORE = 0.55


class FrameSource:
    """Reads the MJPEG stream in a background thread and keeps only the newest
    frame, so decisions never run on old, buffered images."""

    def __init__(self, url: str = STREAM_URL):
        self.url = url
        self._lock = threading.Lock()
        self._jpeg = None
        self._time = 0.0
        self._arrivals = []  # recent frame arrival times, for fps()
        threading.Thread(target=self._run, daemon=True).start()

    def _run(self) -> None:
        while True:
            try:
                with urlopen(self.url, timeout=5) as stream:
                    print(f"[INFO] camera connected: {self.url}")
                    buf = b""
                    while True:
                        chunk = stream.read(4096)
                        if not chunk:
                            break
                        buf += chunk
                        start = buf.find(b"\xff\xd8")
                        end = buf.find(b"\xff\xd9", start + 2)
                        if start != -1 and end != -1:
                            now = time.monotonic()
                            with self._lock:
                                self._jpeg, self._time = buf[start:end + 2], now
                                self._arrivals = [a for a in self._arrivals if now - a < 5] + [now]
                            buf = buf[end + 2:]
            except OSError as e:
                print(f"[WARN] camera stream: {e}; retrying in 1 s")
                time.sleep(1)

    def fps(self) -> float:
        """Frames per second over the last 5 seconds."""
        now = time.monotonic()
        with self._lock:
            return sum(1 for a in self._arrivals if now - a < 5) / 5

    def age(self) -> float:
        """Seconds since the newest frame arrived (inf if none yet)."""
        with self._lock:
            return time.monotonic() - self._time if self._jpeg else float("inf")

    def latest_time(self) -> float:
        """Arrival time of the newest frame, without decoding it."""
        with self._lock:
            return self._time

    def latest(self):
        """Return (rgb_image or None, arrival_time)."""
        with self._lock:
            jpeg, t = self._jpeg, self._time
        if jpeg is None:
            return None, 0.0
        bgr = cv2.imdecode(np.frombuffer(jpeg, np.uint8), cv2.IMREAD_COLOR)
        if bgr is None:
            return None, 0.0
        return cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB), t


class Detector:
    def __init__(self, model_path: Path = MODEL_PATH):
        from edge_impulse_linux.image import ImageImpulseRunner

        os.chmod(model_path, os.stat(model_path).st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
        self.runner = ImageImpulseRunner(str(model_path))
        info = self.runner.init()
        params = info["model_parameters"]
        self.w, self.h = params["image_input_width"], params["image_input_height"]
        print(f"[INFO] loaded Edge Impulse model: {info['project']['name']} ({self.w}x{self.h})")

    def detect(self, rgb):
        """Return (ball Target or None, goal Goal or None) for one frame."""
        features, _ = self.runner.get_features_from_image_auto_studio_settings(rgb)
        boxes = self.runner.classify(features)["result"].get("bounding_boxes", [])
        balls, cones = [], []
        for b in boxes:
            if b["value"] < MIN_SCORE:
                continue
            # Box center, normalized: x -1 (left edge) .. +1 (right edge), y 0 (top) .. 1 (bottom)
            x = (b["x"] + b["width"] / 2) / self.w * 2 - 1
            y = (b["y"] + b["height"] / 2) / self.h
            t = Target(x=x, y=y, score=b["value"])
            if b["label"] == BALL_LABEL:
                balls.append(t)
            elif b["label"] == GOAL_LABEL:
                cones.append(t)

        ball = max(balls, key=lambda t: t.score, default=None)
        goal = None
        if cones:
            two = sorted(cones, key=lambda t: t.score, reverse=True)[:2]
            xs = [c.x for c in two]
            # Aim between the two cones; width = gap between them (0 if only one is seen)
            goal = Goal(x=sum(xs) / len(xs), width=max(xs) - min(xs), cones=len(two))
        return ball, goal

    def close(self) -> None:
        self.runner.stop()
