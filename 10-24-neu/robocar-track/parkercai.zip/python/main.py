from arduino.app_utils import App
import os
import time
from pathlib import Path

from robot_client import MiniAutoRobot

robot = MiniAutoRobot()


def motion_check() -> None:
    # Raised-wheel direction check: one short pulse per direction with a pause
    # between, so each wheel's direction can be called out. Verified on Q30
    # 2026-10-24: the plain forward pulse turned all four wheels forward.
    import time

    for command in ("forward", "backward", "left", "right", "rotate_left", "rotate_right"):
        print(f"[CHECK] {command}")
        robot.drive(command, speed=100, ms=300)
        time.sleep(1.5)
    print("[CHECK] direction sequence done")


def autonomous_run() -> None:
    from autonomy.camera import open_source
    from autonomy.config import load_config
    from autonomy.perception import ColorPerception
    from autonomy.runtime import run_session

    detector = os.environ.get("ROBOCAR_DETECTOR", "color")
    if detector not in {"color", "eim", "hybrid"}:
        raise ValueError("ROBOCAR_DETECTOR must be color, eim or hybrid")

    config = load_config(os.environ.get("ROBOCAR_CONFIG", str(Path(__file__).with_name("calibration.json"))))
    url = os.environ.get("ROBOCAR_CAMERA_URL", "http://192.168.5.1:81/stream")
    if not url.startswith(("http://", "https://")):
        raise ValueError("Hardware autonomy requires a live MJPEG URL, never replay input")
    debug = None
    record = os.environ.get("ROBOCAR_RECORD_DIR", str(Path(__file__).with_name("_runs")))
    if record:  # 2026-10-24 Q30: keep the raw frames of each run for inspection on the laptop
        import cv2
        folder = Path(record) / time.strftime("%H%M%S")
        folder.mkdir(parents=True, exist_ok=True)
        debug = lambda frame, result, decision: cv2.imwrite(
            str(folder / f"{frame.sequence:06d}_{decision.state}.png"), frame.image)
    if detector == "color":
        perception = ColorPerception(config)
    else:
        model = os.environ.get("ROBOCAR_MODEL")
        if not model:
            models = sorted(Path(__file__).parent.glob("*.eim"))
            if len(models) != 1:
                raise ValueError(f"Set ROBOCAR_MODEL: expected one .eim next to main.py, found {len(models)}")
            model = models[0]
        min_confidence = float(os.environ.get("ROBOCAR_MIN_CONFIDENCE", "0.85"))
        if detector == "eim":
            from autonomy.eim_perception import EimPerception
            perception = EimPerception(model, min_confidence)
        else:
            from autonomy.hybrid_perception import HybridPerception
            perception = HybridPerception(config, model, min_confidence)
    print(f"[INFO] detector: {detector}")
    try:
        result = run_session(robot, lambda: open_source(url, config.control.frame_timeout_s),
                             perception, config, debug)
    finally:
        if hasattr(perception, "close"):
            perception.close()
    print(f"[INFO] autonomy ended: {result}")


try:
    robot.stop()
    print(f"health  : {robot.health()}")
    print(f"sensors : {robot.read_sensors()}")
    mode = os.environ.get("ROBOCAR_MODE", "autonomy")  # 2026-10-24 Q30: App Lab .env did not reach the app; default switched after the raised-wheel checks
    if mode not in {"motion-check", "autonomy"}:
        raise ValueError("ROBOCAR_MODE must be motion-check or autonomy")
    print(f"Mode: {mode}. Short-press BOOT to start/stop. Calibrate with wheels raised first.")
    routine = autonomous_run if mode == "autonomy" else motion_check
    App.run(user_loop=lambda: robot.run_program(routine))
finally:
    robot.stop()
