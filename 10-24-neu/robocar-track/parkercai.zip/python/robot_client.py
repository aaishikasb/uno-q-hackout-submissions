import json
import time
from typing import Any, Callable

from autonomy.robot import ProgramStopped, validate_drive


class MiniAutoRobot:
    def __init__(self, bridge=None, sleep=time.sleep) -> None:
        if bridge is None:
            from arduino.app_utils import Bridge
            bridge = Bridge
        self._bridge = bridge
        self._sleep = sleep
        self._session_active = False

    def is_running(self) -> bool:
        return bool(self.read_sensors().get("program_enabled"))

    def hold_toggle(self) -> bool:
        """Read-only state of the CAM boot button's 5-second-hold toggle (red/blue LED)."""
        return bool(self.read_sensors().get("hold_toggle"))

    def _require_running(self) -> None:
        if not self.is_running():
            raise ProgramStopped

    def drive(self, command: str, speed: int = 150, ms: int = 500) -> None:
        validate_drive(command, speed, ms)
        self._require_running()
        if not self._bridge.call("drive", command, speed, ms):
            raise RuntimeError("MCU rejected drive; run may have been stopped")
        self._sleep(ms / 1000.0 + 0.1)
        self._require_running()

    def stop(self) -> bool:
        return bool(self._bridge.call("stop"))

    def read_sensors(self) -> dict[str, Any]:
        raw = self._bridge.call("read_sensors")
        return json.loads(raw) if raw else {}

    def servo(self, angle: int) -> None:
        self._require_running()
        self._bridge.call("servo", int(angle))

    def buzz(self) -> bool:
        return bool(self._bridge.call("buzz"))

    def led(self, on: bool) -> bool:
        return bool(self._bridge.call("led", bool(on)))

    def drive_raw(self, m0: int, m1: int, m2: int, m3: int, ms: int = 500) -> None:
        validate_drive("forward", 0, ms)
        if any(type(v) is not int or not -255 <= v <= 255 for v in (m0, m1, m2, m3)):
            raise ValueError("Raw motor inputs must be integers in -255..255")
        self._require_running()
        if not self._bridge.call("drive_raw", m0, m1, m2, m3, ms):
            raise RuntimeError("MCU rejected raw drive")

    def health(self) -> dict[str, Any]:
        raw = self._bridge.call("health")
        return json.loads(raw) if raw else {}

    def run_program(self, routine: Callable[[], None]) -> None:
        """Pass this as App.run's user_loop. Runs routine() exactly once each time the
        start button enables the program, and waits for the next press if a run finishes
        early (routine raised ProgramStopped, e.g. via drive()/servo()) or completes."""
        if not self.is_running():
            self._session_active = False
            return
        if self._session_active:
            return
        self._session_active = True
        print("[INFO] program enabled - starting")
        try:
            routine()
            print("[INFO] run complete - press the button again to restart")
        except ProgramStopped:
            print("[INFO] program stopped - press the button again to restart")
        finally:
            try:
                if not self.stop():
                    raise RuntimeError("MCU rejected stop")
            finally:
                self._session_active = False
