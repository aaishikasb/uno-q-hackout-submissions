"""Replay sources and continuously drained live input with a one-frame mailbox."""

from pathlib import Path
import threading
from time import perf_counter as monotonic
from typing import Callable, Protocol
from urllib.request import urlopen

import cv2
import numpy as np

from .models import Frame


class SourceError(RuntimeError):
    pass


class EndOfSource(SourceError):
    pass


class FrameSource(Protocol):
    def read(self, after: float, timeout: float) -> Frame: ...
    def close(self) -> None: ...


class ReplaySource:
    """Each image is consumed once. File video advances one frame per decision.

    Timestamps describe replay time, not the original recording/exposure time.
    This is a policy rehearsal, not a simulation of a responding physical robot.
    """

    IMAGE_SUFFIXES = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}

    def __init__(self, path: str | Path):
        path = Path(path)
        self.capture = None
        self.sequence = 0
        if not path.exists():
            raise SourceError(f"Input does not exist: {path}")
        if path.is_dir():
            self.images = iter(sorted(p for p in path.iterdir() if p.suffix.lower() in self.IMAGE_SUFFIXES))
        elif path.suffix.lower() in self.IMAGE_SUFFIXES:
            self.images = iter([path])
        else:
            self.images = None
            self.capture = cv2.VideoCapture(str(path))
            if not self.capture.isOpened():
                self.close()
                raise SourceError(f"Cannot open video: {path}")

    def read(self, after: float, timeout: float) -> Frame:
        started = monotonic()
        if self.images is not None:
            path = next(self.images, None)
            if path is None:
                raise EndOfSource("image sequence exhausted")
            image = cv2.imread(str(path))
            if image is None:
                raise SourceError(f"Cannot decode image: {path}")
        else:
            ok, image = self.capture.read()
            if not ok:
                # OpenCV does not distinguish EOF from some codec failures.
                raise EndOfSource("video ended or decoder returned no frame")
        if monotonic() - started > timeout:
            raise SourceError("replay decode exceeded frame timeout")
        self.sequence += 1
        return Frame(image, started, self.sequence)

    def close(self):
        if self.capture is not None:
            self.capture.release()


class WebcamReader:
    def __init__(self, index: int):
        self.capture = cv2.VideoCapture(index)
        if not self.capture.isOpened():
            self.close()
            raise SourceError(f"Cannot open webcam {index}")
        self.capture.set(cv2.CAP_PROP_BUFFERSIZE, 1)  # best effort; backend dependent

    def read(self):
        started = monotonic()
        ok, image = self.capture.read()
        if not ok:
            raise SourceError("webcam read failed")
        return image, started

    def close(self):
        self.capture.release()


class MJPEGReader:
    MAX_BUFFER = 2 * 1024 * 1024

    def __init__(self, url: str, stall_timeout: float = 1.0):
        # 2026-10-24 Q30: the venue's 2.4 GHz band stalls the ESP32 stream for
        # up to ~3 s; a fixed one-second socket timeout ended every run.
        self.stall_timeout = stall_timeout
        self.stream = urlopen(url, timeout=stall_timeout)
        if self.stream.headers.get_content_type() != "multipart/x-mixed-replace":
            self.close()
            raise SourceError("Expected an MJPEG multipart stream")
        self.buffer = bytearray()
        self.buffer_started = monotonic()

    def read(self):
        deadline = monotonic() + self.stall_timeout
        while True:
            if monotonic() >= deadline:
                raise SourceError("MJPEG frame assembly timed out")
            start = self.buffer.find(b"\xff\xd8")
            end = self.buffer.find(b"\xff\xd9", start + 2) if start >= 0 else -1
            if end >= 0:
                payload = bytes(self.buffer[start:end + 2])
                received = self.buffer_started
                del self.buffer[:end + 2]
                # Keep the earlier timestamp for any bytes already buffered.
                image = cv2.imdecode(np.frombuffer(payload, np.uint8), cv2.IMREAD_COLOR)
                if image is None:
                    raise SourceError("corrupt JPEG frame")
                return image, received
            if not self.buffer or (start < 0 and len(self.buffer) < 1024):
                self.buffer_started = monotonic()
            chunk = self.stream.read1(8192)
            if not chunk:
                raise SourceError("camera stream disconnected")
            self.buffer.extend(chunk)
            if len(self.buffer) > self.MAX_BUFFER:
                raise SourceError("MJPEG frame or headers exceed buffer limit")

    def close(self):
        self.stream.close()


class LatestFrameSource:
    """Capture continuously; never queue a backlog while the robot is moving.

    Consumers have a deadline even if native webcam I/O blocks. The worker is
    a daemon; a blocked webcam backend may need the laptop process restarted.
    The hardware HTTP reader has a separate socket timeout (stall_timeout,
    one second unless the caller passes the control loop's frame timeout).
    """

    def __init__(self, reader_factory: Callable):
        self._condition = threading.Condition()
        self._closed = threading.Event()
        self._latest = None
        self._error = None
        self._consumed = -1
        self._worker = threading.Thread(target=self._capture, args=(reader_factory,), daemon=True)
        self._worker.start()

    def _capture(self, factory):
        reader = None
        try:
            reader = factory()
            sequence = 0
            while not self._closed.is_set():
                image, received = reader.read()
                sequence += 1
                with self._condition:
                    self._latest = Frame(image, received, sequence)
                    self._condition.notify_all()
        except Exception as exc:
            with self._condition:
                self._error = exc
                self._condition.notify_all()
        finally:
            if reader is not None:
                reader.close()

    def read(self, after: float, timeout: float) -> Frame:
        deadline = monotonic() + timeout
        with self._condition:
            while True:
                if self._closed.is_set():
                    raise SourceError("source closed")
                if self._error is not None:
                    raise SourceError(f"live capture failed: {self._error}") from self._error
                frame = self._latest
                if frame is not None and frame.sequence > self._consumed and frame.received_at > after:
                    self._consumed = frame.sequence
                    return frame
                remaining = deadline - monotonic()
                if remaining <= 0:
                    raise SourceError("timed out waiting for a fresh frame")
                self._condition.wait(remaining)

    def close(self):
        self._closed.set()
        with self._condition:
            self._condition.notify_all()
        self._worker.join(timeout=2.2)
        if self._worker.is_alive():
            raise SourceError("capture worker still blocked; restart process before reopening camera")


def open_source(source: str, stall_timeout: float = 1.0) -> FrameSource:
    if source.startswith("webcam:"):
        index = int(source.split(":", 1)[1])
        if index < 0:
            raise ValueError("Webcam index must be nonnegative")
        return LatestFrameSource(lambda: WebcamReader(index))
    if source.startswith(("http://", "https://")):
        return LatestFrameSource(lambda: MJPEGReader(source, stall_timeout))
    return ReplaySource(source)
