from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class Frame:
    image: Any  # BGR numpy array; decisions do not depend on OpenCV.
    received_at: float  # monotonic, start of local read, NOT camera exposure time
    sequence: int


@dataclass(frozen=True)
class Detection:
    x: float  # center, normalized to image width/height
    y: float
    size: float  # ball radius / image width; goal half-width / image width
    quality: float  # shape score, not a calibrated probability
    box: tuple[int, int, int, int]


@dataclass(frozen=True)
class Observation:
    received_at: float
    sequence: int
    ball: Detection | None
    goal: Detection | None


@dataclass(frozen=True)
class Motion:
    direction: str
    speed: int
    ms: int


@dataclass(frozen=True)
class Decision:
    state: str
    reason: str
    motion: Motion | None = None
    terminal: bool = False
