"""One strict, portable calibration file, shared by laptop and board."""

import json
import math
from dataclasses import dataclass, field, fields, replace
from pathlib import Path


@dataclass(frozen=True)
class ColorConfig:
    hsv_low: tuple[int, int, int] = (5, 100, 70)
    hsv_high: tuple[int, int, int] = (30, 255, 255)
    min_area_fraction: float = 0.0008
    max_area_fraction: float = 0.35
    min_shape: float = 0.65
    # Fraction of the image height ignored from the top, so a level camera does
    # not see walls, people or ceiling as targets. 0 keeps the whole frame.
    roi_top: float = 0.0
    # A goal made of two separate markers (two cones): accept the two largest
    # similar-size blobs together and report their midpoint as the goal centre.
    pair: bool = False
    open_px: int = 3  # morphological opening size; 5 breaks thin bright bridges (lit carpet) off the ball
    close_px: int = 3  # closing size; larger fills the dark patches of a soccer ball into one disc

    def __post_init__(self):
        for key in ("hsv_low", "hsv_high"):
            values = getattr(self, key)
            if len(values) != 3 or any(type(v) is not int or not 0 <= v <= limit
                                        for v, limit in zip(values, (179, 255, 255))):
                raise ValueError(f"{key} must contain H=0..179, S/V=0..255")
        if any(self.hsv_low[i] > self.hsv_high[i] for i in (1, 2)):
            raise ValueError("S/V lower bounds must not exceed upper bounds")
        if not 0 < self.min_area_fraction < self.max_area_fraction <= 1:
            raise ValueError("Require 0 < min_area_fraction < max_area_fraction <= 1")
        if not 0 < self.min_shape <= 1:
            raise ValueError("min_shape must be in (0, 1]")
        if not 0 <= self.roi_top < 1:
            raise ValueError("roi_top must be in [0, 1)")
        for key in ("open_px", "close_px"):
            value = getattr(self, key)
            if type(value) is not int or value < 1 or value > 15 or value % 2 == 0:
                raise ValueError(f"{key} must be an odd integer 1..15")


@dataclass(frozen=True)
class ControlConfig:
    center_tolerance: float = 0.08
    alignment_tolerance: float = 0.06
    near_radius: float = 0.09
    near_y: float = 1.0  # ball centre y at stand-off distance, for fixed-size model boxes; 1.0 disables
    max_radius: float = 0.30
    min_quality: float = 0.65
    confirm_frames: int = 2
    alignment_frames: int = 2
    approach_speed: int = 90
    turn_speed: int = 80
    push_speed: int = 80
    pulse_ms: int = 150
    push_ms: int = 120
    max_push_pulses: int = 5
    max_frame_age_s: float = 0.5
    frame_timeout_s: float = 1.0
    max_run_s: float = 30.0
    require_goal: bool = True  # False: push straight at a centred ball when no goal pair is visible (demo fallback)
    miss_frames: int = 1  # consecutive invalid-ball frames tolerated before stopping (motors idle meanwhile)

    def __post_init__(self):
        for f in fields(self):
            value = getattr(self, f.name)
            if f.name == "require_goal":
                if not isinstance(value, bool):
                    raise ValueError("require_goal must be a boolean")
                continue
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value <= 0:
                raise ValueError(f"{f.name} must be finite and positive")
        for key in ("confirm_frames", "alignment_frames", "max_push_pulses", "miss_frames",
                    "approach_speed", "turn_speed", "push_speed", "pulse_ms", "push_ms"):
            if type(getattr(self, key)) is not int:
                raise ValueError(f"{key} must be an integer")
        if max(self.approach_speed, self.turn_speed, self.push_speed) > 255:
            raise ValueError("Speeds must be 1..255")
        if max(self.pulse_ms, self.push_ms) > 300:
            raise ValueError("Autonomous pulses must be 1..300 ms")
        if not 0 < self.near_radius < self.max_radius <= 0.5:
            raise ValueError("Require 0 < near_radius < max_radius <= 0.5")
        if self.near_y > 1:
            raise ValueError("near_y must be in (0, 1]")
        if max(self.center_tolerance, self.alignment_tolerance) >= 0.5 or self.min_quality > 1:
            raise ValueError("Invalid normalized control threshold")
        if self.miss_frames > 10:
            raise ValueError("miss_frames must be 1..10")
        if self.max_run_s > 120 or self.frame_timeout_s > 5 or self.max_frame_age_s > 2:
            raise ValueError("Run <= 120 s, frame timeout <= 5 s, frame age <= 2 s")


@dataclass(frozen=True)
class Config:
    ball: ColorConfig = field(default_factory=ColorConfig)
    goal: ColorConfig = field(default_factory=lambda: ColorConfig((90, 90, 60), (130, 255, 255)))
    control: ControlConfig = field(default_factory=ControlConfig)


def load_config(path: str | Path) -> Config:
    raw = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(raw, dict) or set(raw) - {"ball", "goal", "control"}:
        raise ValueError("Config must contain only ball, goal, control objects")
    if any(not isinstance(value, dict) for value in raw.values()):
        raise ValueError("Each config section must be an object")
    defaults = Config()
    return Config(ball=replace(defaults.ball, **raw.get("ball", {})),
                  goal=replace(defaults.goal, **raw.get("goal", {})),
                  control=replace(defaults.control, **raw.get("control", {})))
