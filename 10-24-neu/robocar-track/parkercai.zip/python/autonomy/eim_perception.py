"""Edge Impulse .eim detector with the same Observation as ColorPerception.

Talks to the .eim's Unix-socket JSON protocol directly, so the board needs no
extra packages. Boxes come back in model-input pixels and are mapped back to
the frame. FOMO boxes are centroid cells, so size is coarse (1/12 frame).
"""

import json
import os
from pathlib import Path
import shutil
import socket
import stat
import subprocess
import tempfile
import time

import cv2
import numpy as np

from .models import Detection, Frame, Observation
from .perception import PerceptionResult

BALL_LABELS = ("soccer_ball", "soccerball", "ball")
GOAL_LABELS = ("goal",)


class EimRunner:
    """Start one .eim process and exchange id-tagged JSON messages with it."""

    def __init__(self, model: str | Path, timeout: float = 5.0):
        self.model = Path(model)
        if not self.model.is_file():
            raise FileNotFoundError(f"Edge Impulse model not found: {self.model}")
        self.timeout = timeout
        self._id = 0
        self._dir = tempfile.mkdtemp(prefix="eim-")
        executable = self.model
        if not os.access(executable, os.X_OK):  # zip/adb copies can drop the exec bit
            executable = Path(self._dir) / self.model.name
            shutil.copyfile(self.model, executable)
            executable.chmod(executable.stat().st_mode | stat.S_IXUSR)
        path = os.path.join(self._dir, "runner.sock")
        self._process = subprocess.Popen([str(executable), path], stdout=subprocess.DEVNULL,
                                         stderr=subprocess.DEVNULL)
        self._socket = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self._socket.settimeout(timeout)
        deadline = time.monotonic() + timeout
        while True:
            try:
                self._socket.connect(path)
                break
            except (FileNotFoundError, ConnectionRefusedError):
                if self._process.poll() is not None or time.monotonic() > deadline:
                    self.close()
                    raise RuntimeError(f"Edge Impulse model did not start: {self.model}")
                time.sleep(0.05)
        try:
            hello = self.send({"hello": 1})
            self.parameters = hello["model_parameters"]
        except Exception:
            self.close()
            raise

    def send(self, message: dict) -> dict:
        self._id += 1
        self._socket.sendall(json.dumps({**message, "id": self._id}).encode("utf-8"))
        data = b""
        while not data.endswith(b"\x00"):  # each reply is NUL-terminated
            chunk = self._socket.recv(65536)
            if not chunk:
                raise RuntimeError("Edge Impulse model closed its socket")
            data += chunk
        reply = json.loads(data[:-1])
        if reply.get("id") != self._id or not reply.get("success", False):
            raise RuntimeError(f"Edge Impulse model error: {reply.get('error', reply)}")
        return reply

    def classify(self, features: list[int]) -> dict:
        return self.send({"classify": features})["result"]

    def close(self) -> None:
        if getattr(self, "_socket", None) is not None:
            self._socket.close()
        if self._process.poll() is None:
            self._process.terminate()
            try:
                self._process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                self._process.kill()
        shutil.rmtree(self._dir, ignore_errors=True)


def prepare(image: np.ndarray, width: int, height: int, channels: int, mode: str):
    """Return (features, scale_x, scale_y, offset_x, offset_y) for one BGR frame."""
    h, w = image.shape[:2]
    offset_x = offset_y = 0
    if mode in ("fit-shortest", "fit-short"):  # center-crop to the model aspect
        crop = min(w / width, h / height)
        cw, ch = round(width * crop), round(height * crop)
        offset_x, offset_y = (w - cw) // 2, (h - ch) // 2
        image = image[offset_y:offset_y + ch, offset_x:offset_x + cw]
        h, w = ch, cw
    elif mode not in ("squash", "none", ""):
        raise ValueError(f"Unsupported Edge Impulse resize mode: {mode}")
    resized = cv2.resize(image, (width, height), interpolation=cv2.INTER_AREA)
    if channels == 1:
        gray = cv2.cvtColor(resized, cv2.COLOR_BGR2GRAY).astype(np.int64)
        packed = (gray << 16) | (gray << 8) | gray
    else:
        rgb = cv2.cvtColor(resized, cv2.COLOR_BGR2RGB).astype(np.int64)
        packed = (rgb[..., 0] << 16) | (rgb[..., 1] << 8) | rgb[..., 2]
    return packed.ravel().tolist(), w / width, h / height, offset_x, offset_y


class EimPerception:
    def __init__(self, model: str | Path, min_confidence: float = 0.5, runner=None):
        self.runner = runner if runner is not None else EimRunner(model)
        self.min_confidence = min_confidence
        params = self.runner.parameters
        self.width = int(params["image_input_width"])
        self.height = int(params["image_input_height"])
        self.channels = int(params.get("image_channel_count", 3))
        self.mode = params.get("image_resize_mode", "squash")
        labels = set(params.get("labels", []))
        self.ball_labels = [l for l in BALL_LABELS if l in labels] or list(BALL_LABELS)
        self.goal_labels = [l for l in GOAL_LABELS if l in labels] or list(GOAL_LABELS)
        # The .eim drops boxes below its own built-in min_score (0.5 by default), so a
        # lower min_confidence only takes effect after lowering that threshold too.
        for threshold in params.get("thresholds", []):
            if threshold.get("type") == "object_detection" and threshold.get("min_score", 0) > min_confidence:
                self.runner.send({"set_threshold": {"id": threshold["id"], "min_score": min_confidence}})

    def detect(self, frame: Frame) -> PerceptionResult:
        image = frame.image
        if image is None or image.dtype != np.uint8 or image.ndim != 3 or image.shape[2] != 3:
            raise ValueError("Expected a nonempty uint8 BGR frame")
        h, w = image.shape[:2]
        features, sx, sy, ox, oy = prepare(image, self.width, self.height, self.channels, self.mode)
        boxes = self.runner.classify(features).get("bounding_boxes", [])
        ball_mask = np.zeros((h, w), np.uint8)
        goal_mask = np.zeros((h, w), np.uint8)
        balls = self._candidates(boxes, self.ball_labels, sx, sy, ox, oy, w, h, ball_mask, radius=True)
        goals = self._candidates(boxes, self.goal_labels, sx, sy, ox, oy, w, h, goal_mask, radius=False)
        return PerceptionResult(Observation(frame.received_at, frame.sequence,
                                            self._single(balls), self._span(goals, w, h)),
                                ball_mask, goal_mask)

    def _candidates(self, boxes, labels, sx, sy, ox, oy, w, h, mask, radius) -> list[Detection]:
        candidates = []
        for box in boxes:
            if box.get("label") not in labels or box.get("value", 0) < self.min_confidence:
                continue
            x, y = round(box["x"] * sx) + ox, round(box["y"] * sy) + oy
            bw, bh = max(1, round(box["width"] * sx)), max(1, round(box["height"] * sy))
            mask[y:y + bh, x:x + bw] = 255
            size = (max(bw, bh) / 2 if radius else bw / 2) / w
            candidates.append(Detection((x + bw / 2) / w, (y + bh / 2) / h, size,
                                        float(box["value"]), (x, y, bw, bh)))
        candidates.sort(key=lambda d: d.quality, reverse=True)
        return candidates

    @staticmethod
    def _single(candidates: list[Detection]) -> Detection | None:
        # Two confident, separated candidates are ambiguous; stop rather than switch
        # targets. Nearby boxes are usually one object split across FOMO cells.
        if (len(candidates) > 1 and candidates[1].quality >= 0.9 * candidates[0].quality
                and abs(candidates[1].x - candidates[0].x) > 0.15):
            return None
        return candidates[0] if candidates else None

    @staticmethod
    def _span(candidates: list[Detection], w: int, h: int) -> Detection | None:
        # The goal is two cones; FOMO reports one centroid per cone (or several per
        # cone). Aim at the gap between them: span every goal box into one target.
        if not candidates:
            return None
        if len(candidates) == 1:
            return candidates[0]
        x0 = min(d.box[0] for d in candidates)
        y0 = min(d.box[1] for d in candidates)
        x1 = max(d.box[0] + d.box[2] for d in candidates)
        y1 = max(d.box[1] + d.box[3] for d in candidates)
        quality = sum(d.quality for d in candidates) / len(candidates)
        return Detection((x0 + x1) / (2 * w), (y0 + y1) / (2 * h), (x1 - x0) / (2 * w),
                         quality, (x0, y0, x1 - x0, y1 - y0))

    def close(self) -> None:
        self.runner.close()
