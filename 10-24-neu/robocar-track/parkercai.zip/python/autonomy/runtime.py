"""Own the observation/action loop and stop BEFORE closing a failed camera."""

from dataclasses import asdict, dataclass
import json
import time
from typing import Callable

from .camera import EndOfSource
from .config import Config
from .control import Controller
from .robot import ProgramStopped, Robot, validate_drive


@dataclass(frozen=True)
class RunResult:
    reason: str
    frames: int
    failed: bool = False


def run_session(robot: Robot, source_factory: Callable, perception, config: Config,
                debug: Callable | None = None, emit: Callable[[str], None] = print,
                clock: Callable[[], float] = time.perf_counter) -> RunResult:
    source = None
    frames = 0
    controller = Controller(config.control)  # all run state resets on deliberate restart
    deadline = clock() + config.control.max_run_s
    after = clock()
    try:
        if not robot.is_running():
            raise ProgramStopped()
        source = source_factory()
        while True:
            if not robot.is_running():
                raise ProgramStopped()
            remaining = deadline - clock()
            if remaining <= 0:
                return RunResult("run time limit reached", frames)
            frame = source.read(after=after, timeout=min(config.control.frame_timeout_s, remaining))
            if frame.received_at <= after:
                raise ValueError("source returned a frame from before the previous action completed")
            result = perception.detect(frame)
            frames += 1
            decision = controller.step(result.observation, clock())
            emit(json.dumps({"event": "decision", "observation": asdict(result.observation),
                             "decision": asdict(decision)}))
            if debug is not None:
                debug(frame, result, decision)
            # Button, frame-age and run-budget checks MUST follow perception,
            # debug output and logging, which can all take unpredictable time.
            if not robot.is_running():
                raise ProgramStopped()
            if decision.terminal:
                return RunResult(decision.reason, frames, decision.state == "STOPPED")
            now = clock()
            if now - frame.received_at > config.control.max_frame_age_s:
                return RunResult("frame expired before action", frames, True)
            duration = 0 if decision.motion is None else decision.motion.ms / 1000 + 0.1
            if now + duration >= deadline:
                return RunResult("run time limit reached", frames)
            if decision.motion is not None:
                motion = decision.motion
                validate_drive(motion.direction, motion.speed, motion.ms, max_ms=300)
                robot.drive(motion.direction, motion.speed, motion.ms)
            after = clock()  # next live frame must start arriving after drive() settles
    except ProgramStopped:
        return RunResult("program stopped; deliberate restart required", frames)
    except EndOfSource as exc:
        return RunResult(str(exc), frames)
    except Exception as exc:
        emit(json.dumps({"event": "fault", "error": f"{type(exc).__name__}: {exc}"}))
        return RunResult(str(exc), frames, True)
    finally:
        try:
            if not robot.stop():
                raise RuntimeError("stop rejected; verify motor power and MCU timed stop")
        finally:
            if source is not None:
                source.close()
