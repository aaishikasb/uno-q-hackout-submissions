"""Ball from the Edge Impulse model, goal from the color threshold (yellow cones).

The learned detector is reliable on the white ball at close range, where HSV
struggles against white sleeves and floor glare, while two yellow cones on dark
carpet are an easy color target that a small model can miss at a distance.
Use each where it is strong; the Observation stays the same for the controller.
"""

from pathlib import Path

import cv2
import numpy as np

from .config import ColorConfig, Config
from .eim_perception import EimPerception
from .models import Detection, Frame, Observation
from .perception import PerceptionResult, color_mask


def span_cones(mask: np.ndarray, config: ColorConfig) -> Detection | None:
    """Treat the two largest yellow blobs as the goal posts and aim between them."""
    height, width = mask.shape
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    blobs = []
    for contour in contours:
        area = cv2.contourArea(contour)
        if not config.min_area_fraction <= area / (height * width) <= config.max_area_fraction:
            continue
        x, y, w, h = cv2.boundingRect(contour)
        blobs.append((area, area / (w * h), (x, y, w, h)))
    blobs.sort(key=lambda item: item[0], reverse=True)
    if not blobs:
        return None
    posts = blobs[:2] if len(blobs) > 1 and blobs[1][0] >= 0.3 * blobs[0][0] else blobs[:1]
    if min(b[1] for b in posts) < 0.3:  # a cone fills ~half its box; thin streaks fill far less
        return None
    x0 = min(b[2][0] for b in posts)
    y0 = min(b[2][1] for b in posts)
    x1 = max(b[2][0] + b[2][2] for b in posts)
    y1 = max(b[2][1] + b[2][3] for b in posts)
    # Quality is a goal-fix confidence, not a fill ratio: two posts give a real
    # aiming point, one post only a direction. Both pass the controller's gate.
    quality = 0.9 if len(posts) == 2 else 0.7
    return Detection((x0 + x1) / (2 * width), (y0 + y1) / (2 * height), (x1 - x0) / (2 * width),
                     quality, (x0, y0, x1 - x0, y1 - y0))


class HybridPerception:
    def __init__(self, config: Config, model: str | Path, min_confidence: float = 0.5, runner=None):
        self.config = config
        self.eim = EimPerception(model, min_confidence, runner=runner)

    def detect(self, frame: Frame) -> PerceptionResult:
        learned = self.eim.detect(frame)
        hsv = cv2.cvtColor(frame.image, cv2.COLOR_BGR2HSV)
        goal_mask = color_mask(hsv, self.config.goal)
        observation = Observation(frame.received_at, frame.sequence,
                                  learned.observation.ball, span_cones(goal_mask, self.config.goal))
        return PerceptionResult(observation, learned.ball_mask, goal_mask)

    def close(self) -> None:
        self.eim.close()
