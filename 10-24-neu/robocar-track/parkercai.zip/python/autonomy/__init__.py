"""Hardware-independent perception and bounded robocar decisions."""
