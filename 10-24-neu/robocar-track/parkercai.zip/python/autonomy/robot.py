import json
import time
from typing import Callable, Protocol


class ProgramStopped(Exception):
    """The button or dry-run session disabled the current program."""


class Robot(Protocol):
    def is_running(self) -> bool: ...
    def drive(self, command: str, speed: int, ms: int) -> None: ...
    def stop(self) -> bool: ...


def validate_drive(command: str, speed: int, ms: int, max_ms: int = 5000) -> None:
    if command not in {"forward", "backward", "left", "right", "rotate_left", "rotate_right", "stop"}:
        raise ValueError(f"Unknown movement: {command}")
    if type(speed) is not int or not 0 <= speed <= 255:
        raise ValueError("Speed must be an integer in 0..255")
    if type(ms) is not int or not 1 <= ms <= max_ms:
        raise ValueError(f"Duration must be an integer in 1..{max_ms} ms (never continuous)")


class DryRunRobot:
    """No Bridge import or motor access. Start explicitly for each local run."""

    def __init__(self, emit: Callable[[str], None] = print, sleep: Callable = time.sleep):
        self.emit = emit
        self.sleep = sleep
        self.running = False

    def start(self):
        self.running = True
        self.emit(json.dumps({"robot": "dry-run", "event": "start"}))

    def is_running(self) -> bool:
        return self.running

    def drive(self, command: str, speed: int, ms: int):
        validate_drive(command, speed, ms, max_ms=300)
        if not self.running:
            raise ProgramStopped()
        self.emit(json.dumps({"robot": "dry-run", "event": "drive", "direction": command,
                              "speed": speed, "ms": ms}))
        self.sleep(ms / 1000 + 0.1)  # same settling wait as the starter
        if not self.running:
            raise ProgramStopped()

    def stop(self) -> bool:
        self.running = False
        self.emit(json.dumps({"robot": "dry-run", "event": "stop"}))
        return True
