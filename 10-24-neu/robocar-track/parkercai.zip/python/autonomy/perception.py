"""HSV + contour baseline. Replace detect() for a learned detector later."""

from dataclasses import dataclass
import math

import cv2
import numpy as np

from .config import ColorConfig, Config
from .models import Detection, Frame, Observation


@dataclass
class PerceptionResult:
    observation: Observation
    ball_mask: np.ndarray
    goal_mask: np.ndarray


def color_mask(hsv: np.ndarray, config: ColorConfig) -> np.ndarray:
    lo, hi = config.hsv_low, config.hsv_high
    if lo[0] <= hi[0]:
        mask = cv2.inRange(hsv, np.array(lo), np.array(hi))
    else:  # A red range may wrap through hue 179 -> 0.
        mask = cv2.bitwise_or(
            cv2.inRange(hsv, np.array((0, lo[1], lo[2])), np.array(hi)),
            cv2.inRange(hsv, np.array(lo), np.array((179, hi[1], hi[2]))))
    if config.roi_top > 0:
        mask[: int(round(mask.shape[0] * config.roi_top)), :] = 0
    opened = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((config.open_px, config.open_px), np.uint8))
    return cv2.morphologyEx(opened, cv2.MORPH_CLOSE, np.ones((config.close_px, config.close_px), np.uint8))


def find_target(mask: np.ndarray, config: ColorConfig, circular: bool) -> Detection | None:
    height, width = mask.shape
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    candidates = []
    for contour in contours:
        area = cv2.contourArea(contour)
        if not config.min_area_fraction <= area / (height * width) <= config.max_area_fraction:
            continue
        x, y, w, h = cv2.boundingRect(contour)
        if circular and y + h >= height and x > 0 and x + w < width and y > 0 and w >= 0.08 * width:
            # 2026-10-24 Q30: a ball cut by the bottom edge is at the bumper; size from width.
            candidates.append((area, Detection((x + w / 2) / width, (y + h / 2) / height,
                                               w / (2 * width), config.min_shape, (x, y, w, h))))
            continue
        if x <= 0 or y <= 0 or x + w >= width or y + h >= height:
            continue  # Partial targets cannot support a reliable size estimate.
        if circular:
            (cx, cy), radius = cv2.minEnclosingCircle(contour)
            perimeter = cv2.arcLength(contour, True)
            quality = min(1.0, 4 * math.pi * area / max(perimeter * perimeter, 1),
                          area / max(math.pi * radius * radius, 1), min(w, h) / max(w, h))
            size = radius / width
        else:
            cx, cy, size = x + w / 2, y + h / 2, w / (2 * width)
            quality = min(1.0, area / (w * h))
        if quality >= config.min_shape:
            candidates.append((area, Detection(cx / width, cy / height, size, quality, (x, y, w, h))))
    candidates.sort(key=lambda item: item[0], reverse=True)
    if config.pair and not circular:
        # Two-marker goal: need exactly two similar-size blobs side by side.
        if len(candidates) < 2 or candidates[1][0] < 0.4 * candidates[0][0]:
            return None
        if len(candidates) > 2 and candidates[2][0] >= 0.7 * candidates[1][0]:
            return None  # a third similar blob makes the pair ambiguous
        a, b = candidates[0][1], candidates[1][1]
        x0, y0 = min(a.box[0], b.box[0]), min(a.box[1], b.box[1])
        x1 = max(a.box[0] + a.box[2], b.box[0] + b.box[2])
        y1 = max(a.box[1] + a.box[3], b.box[1] + b.box[3])
        return Detection((x0 + x1) / (2 * width), (y0 + y1) / (2 * height),
                         (x1 - x0) / (2 * width), min(a.quality, b.quality), (x0, y0, x1 - x0, y1 - y0))
    # Similar-size candidates are ambiguous; stop rather than switch targets.
    if len(candidates) > 1 and candidates[1][0] >= 0.7 * candidates[0][0]:
        return None
    return candidates[0][1] if candidates else None


class ColorPerception:
    def __init__(self, config: Config):
        self.config = config

    def detect(self, frame: Frame) -> PerceptionResult:
        image = frame.image
        if image is None or image.dtype != np.uint8 or image.ndim != 3 or image.shape[2] != 3:
            raise ValueError("Expected a nonempty uint8 BGR frame")
        hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
        ball_mask = color_mask(hsv, self.config.ball)
        goal_mask = color_mask(hsv, self.config.goal)
        return PerceptionResult(Observation(frame.received_at, frame.sequence,
            find_target(ball_mask, self.config.ball, circular=True),
            find_target(goal_mask, self.config.goal, circular=False)), ball_mask, goal_mask)


def draw_debug(frame: Frame, result: PerceptionResult, state: str, reason: str, age: float) -> np.ndarray:
    image = frame.image.copy()
    h, w = image.shape[:2]
    cv2.line(image, (w // 2, 0), (w // 2, h), (180, 180, 180), 1)
    for name, target, color in (("ball", result.observation.ball, (0, 255, 255)),
                                 ("goal", result.observation.goal, (255, 180, 0))):
        if target is None:
            continue
        x, y, bw, bh = target.box
        cv2.rectangle(image, (x, y), (x + bw, y + bh), color, 2)
        cv2.putText(image, f"{name} {target.quality:.2f}", (x, max(14, y - 5)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.4, color, 1)
    panel = np.hstack((image, cv2.cvtColor(result.ball_mask, cv2.COLOR_GRAY2BGR),
                       cv2.cvtColor(result.goal_mask, cv2.COLOR_GRAY2BGR)))
    footer = np.zeros((66, 3 * w, 3), np.uint8)
    for i, line in enumerate((f"{state} | frame {frame.sequence} | receive age {age:.3f}s",
                               reason, "left: detections | middle: ball mask | right: goal mask")):
        cv2.putText(footer, line, (8, 17 + 21 * i), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
    return np.vstack((panel, footer))
