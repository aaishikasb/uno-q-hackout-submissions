"""Small deterministic policy. No image, clock, network or motor dependencies."""

import math

from .config import ControlConfig
from .models import Decision, Detection, Motion, Observation


class Controller:
    def __init__(self, config: ControlConfig):
        self.config = config
        self.confirmed = 0
        self.aligned = 0
        self.pushes = 0
        self.misses = 0
        self.last_sequence = -1
        self.last_time = -math.inf
        self.terminal: Decision | None = None

    def finish(self, reason: str, state: str = "STOPPED") -> Decision:
        self.terminal = Decision(state, reason, terminal=True)
        return self.terminal

    def valid(self, target: Detection | None) -> bool:
        return target is not None and all(math.isfinite(v) for v in (
            target.x, target.y, target.size, target.quality)) and (
            0 <= target.x <= 1 and 0 <= target.y <= 1 and 0 < target.size <= 0.5
            and self.config.min_quality <= target.quality <= 1)

    def step(self, observation: Observation, now: float) -> Decision:
        if self.terminal is not None:
            return self.terminal
        c = self.config
        age = now - observation.received_at
        if not math.isfinite(age) or not 0 <= age <= c.max_frame_age_s:
            return self.finish("stale or invalid frame time")
        if observation.sequence <= self.last_sequence or observation.received_at < self.last_time:
            return self.finish("repeated or out-of-order frame")
        self.last_sequence = observation.sequence
        self.last_time = observation.received_at
        ball, goal = observation.ball, observation.goal
        if not self.valid(ball):
            self.misses += 1
            if self.misses >= c.miss_frames or self.pushes:
                return self.finish("ball missing or uncertain")
            return Decision("ACQUIRE", f"ball missed {self.misses}/{c.miss_frames}; waiting")
        self.misses = 0
        if ball.size >= c.max_radius:
            return self.finish("ball exceeds calibrated size limit")
        self.confirmed += 1
        if self.confirmed < c.confirm_frames:
            return Decision("ACQUIRE", "confirm ball in another fresh frame")
        if self.pushes >= c.max_push_pulses:
            return self.finish("push budget exhausted; score unverified", "ATTEMPT_FINISHED")
        error = ball.x - 0.5
        if abs(error) > c.center_tolerance:
            self.aligned = 0
            if self.pushes:
                return self.finish("ball drifted off center during push")
            return Decision("APPROACH", "center ball", Motion(
                "rotate_right" if error > 0 else "rotate_left", c.turn_speed, c.pulse_ms))
        # Near by size (color blobs grow) or by image height (model boxes do not).
        if ball.size < c.near_radius and ball.y < c.near_y:
            self.aligned = 0
            if self.pushes:
                return self.finish("ball moved away after contact; inspect before restart")
            return Decision("APPROACH", "approach stand-off distance",
                            Motion("forward", c.approach_speed, c.pulse_ms))
        if not self.valid(goal):
            if c.require_goal:
                return self.finish("goal missing or uncertain at stand-off distance")
            goal = None  # demo fallback: push straight at the centred ball
        if goal is not None and goal.y >= ball.y:
            return self.finish("goal marker must appear above the ball")
        # When the farther goal is to the right of the ball, move LEFT behind
        # the ball; parallax brings the nearer ball right faster than the goal.
        # Then recenter by rotation on the NEXT observation. Requires a level,
        # forward camera and calibrated mecanum directions; test on the floor.
        difference = 0.0 if goal is None else goal.x - ball.x
        if abs(difference) > c.alignment_tolerance:
            self.aligned = 0
            if self.pushes:
                return self.finish("alignment lost during push")
            return Decision("ALIGN", "move behind ball-goal line", Motion(
                "left" if difference > 0 else "right", c.turn_speed, c.pulse_ms))
        self.aligned += 1
        if self.aligned < c.alignment_frames:
            return Decision("ALIGN", "confirm goal alignment in another fresh frame")
        self.pushes += 1
        return Decision("PUSH", "aligned push; observe again before next pulse",
                        Motion("forward", c.push_speed, c.push_ms))
