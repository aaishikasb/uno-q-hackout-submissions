"""Laptop-only entry point. It cannot instantiate the real robot."""

import argparse
from dataclasses import asdict
import json
from pathlib import Path
import time

import cv2

from autonomy.camera import EndOfSource, open_source
from autonomy.config import load_config
from autonomy.models import Decision
from autonomy.perception import ColorPerception, draw_debug
from autonomy.robot import DryRunRobot
from autonomy.runtime import run_session


class DebugOutput:
    def __init__(self, show: bool, output: Path | None):
        self.show = show
        self.output = output
        if output:
            output.mkdir(parents=True, exist_ok=True)
            (output / "raw").mkdir(exist_ok=True)

    def __call__(self, frame, result, decision):
        if not self.show and not self.output:
            return
        panel = draw_debug(frame, result, decision.state, decision.reason, time.perf_counter() - frame.received_at)
        if self.output:
            path = self.output / f"{frame.sequence:06d}.jpg"
            if not cv2.imwrite(str(path), panel):
                raise OSError(f"Cannot write debug image: {path}")
            raw_path = self.output / "raw" / f"{frame.sequence:06d}.png"
            if not cv2.imwrite(str(raw_path), frame.image):
                raise OSError(f"Cannot write captured frame: {raw_path}")
        if self.show:
            cv2.imshow("Robocar: q to stop", panel)
            if cv2.waitKey(1) & 0xFF in (ord("q"), 27):
                raise KeyboardInterrupt()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", required=True, help="image, image folder, video, webcam:0, or MJPEG URL")
    parser.add_argument("--config", type=Path, default=Path(__file__).with_name("calibration.json"))
    parser.add_argument("--inspect", action="store_true", help="only inspect detections, including empty frames")
    parser.add_argument("--show", action="store_true", help="open visual debug window; q/Escape stops")
    parser.add_argument("--debug-dir", type=Path, help="save annotated frames and masks")
    parser.add_argument("--max-frames", type=int, default=300, help="inspection frame limit")
    parser.add_argument("--model", type=Path, help="Edge Impulse .eim built for this computer; default: color detector")
    parser.add_argument("--min-confidence", type=float, default=0.5, help="Edge Impulse box confidence threshold")
    parser.add_argument("--detector", choices=("color", "eim", "hybrid"),
                        help="color, eim, or hybrid (model ball + color goal); default: eim with --model, else color")
    args = parser.parse_args()
    if args.max_frames <= 0:
        parser.error("--max-frames must be positive")
    if args.detector in ("eim", "hybrid") and not args.model:
        parser.error(f"--detector {args.detector} needs --model")
    robot = DryRunRobot()
    perception = None
    try:
        config = load_config(args.config)
        detector = args.detector or ("eim" if args.model else "color")
        if detector == "eim":
            from autonomy.eim_perception import EimPerception
            perception = EimPerception(args.model, args.min_confidence)
        elif detector == "hybrid":
            from autonomy.hybrid_perception import HybridPerception
            perception = HybridPerception(config, args.model, args.min_confidence)
        else:
            perception = ColorPerception(config)
        debug = DebugOutput(args.show, args.debug_dir)
        if args.inspect:
            source = open_source(args.source)
            try:
                after = time.perf_counter()
                for _ in range(args.max_frames):
                    frame = source.read(after, config.control.frame_timeout_s)
                    result = perception.detect(frame)
                    print(json.dumps({"event": "inspection", "observation": asdict(result.observation)}))
                    debug(frame, result, Decision("INSPECT", "motors disabled"))
                    after = time.perf_counter()
            except EndOfSource as exc:
                print(json.dumps({"event": "input_finished", "reason": str(exc)}))
            finally:
                source.close()
            return 0
        robot.start()  # invoking this dry-run CLI is the explicit local start
        result = run_session(robot, lambda: open_source(args.source), perception, config, debug)
        print(json.dumps({"event": "run_finished", **asdict(result)}))
        return 1 if result.failed else 0
    except KeyboardInterrupt:
        print(json.dumps({"event": "interrupted"}))
        return 130
    except Exception as exc:
        print(json.dumps({"event": "error", "error": f"{type(exc).__name__}: {exc}"}))
        return 1
    finally:
        robot.stop()
        if perception is not None and hasattr(perception, "close"):
            perception.close()
        if args.show:
            cv2.destroyAllWindows()


if __name__ == "__main__":
    raise SystemExit(main())
