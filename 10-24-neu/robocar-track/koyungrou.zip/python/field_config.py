"""Settings measured on the event robot. The robot runs with FIELD and tools/turn_calc.py reads it.

ControlConfig keeps its defaults for the simulator and the tests, whose numbers are quoted in the docs.
"""
from control import ControlConfig

# Turn settings for miniAutoQ28. turn_check on 2026-10-24 with the defaults: ten left look steps
# turned about 270 degrees, the right ones came back to the start, and the 20 ms ladder pulse
# barely moved it, so the next value, 40, is used. A run with these settings turned about 380
# degrees where 350 were expected.
# The event field has no obstacles and no boundary, and the start may or may not put robot, ball
# and goal in one line. A lost ball gets one search lap, a back-off to uncover a ball under the
# camera and a second lap, then the run stops. In simulation that scored 297 of 300, against 281
# with a single lap and no back-off.
# In eight play runs the goal was seen once, and the robot spent the rest of each run scanning for
# it until the 60 s limit, so a ball with no goal in view or memory is pushed straight.
FIELD = ControlConfig(
    turn_rad_per_speed_ms=8.08e-6,
    pulse_dead_ms=40,
    right_turn_scale=1.0,
    center_band=0.08,
    sidestep_pulses=3,
    max_search_laps=2,
    search_back_pulses=2,
    scan_for_goal=False,
)
