"""Serves what the robot sees, with its detections drawn on, as a web page from the UNO Q.

The camera serves one stream, which the robot app holds, so a phone or laptop cannot watch the
camera while the app runs. This page re-serves the app's own frames instead. Join the camera's
Wi-Fi and open http://192.168.5.2:8000/, the UNO Q's address on that network.

Frames are drawn and encoded only while a page is open, on the server's threads, so the control
loop only pays for storing a reference to the newest frame.
"""
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Optional, Sequence

import cv2
import numpy as np

from camera import LatestFrameReader
from control import BALL, GOAL, ControlConfig, Detection

PORT = 8000
BOUNDARY = "frame"
FPS = 5.0
# Detections older than this are not drawn, since the robot has moved or stopped observing.
DETECTION_MAX_AGE_S = 1.0

COLOURS = {BALL: (0, 165, 255), GOAL: (255, 128, 0)}  # BGR: orange ball, blue goal
OTHER_COLOUR = (200, 200, 200)
GRID_COLOUR = (90, 90, 90)
BAND_COLOUR = (0, 220, 0)
NEAR_COLOUR = (0, 220, 220)

INDEX_HTML = b"""<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>Robocar view</title>
<style>body{margin:0;background:#111;color:#ddd;font:14px sans-serif;text-align:center}
img{width:100%;max-width:960px;image-rendering:pixelated}p{margin:8px}</style></head>
<body><img src="/stream"><p>orange: ball &middot; blue: goal &middot; green: centre band
&middot; yellow: near_y &middot; grey: model grid</p></body></html>"""


def annotate(bgr: np.ndarray, detections: Sequence[Detection], cfg: ControlConfig,
             grid_cells: Optional[int], status: str) -> np.ndarray:
    """Copy of bgr with the model grid, the controller's bands and every detection drawn on."""
    img = bgr.copy()
    h, w = img.shape[:2]
    if grid_cells:
        for i in range(1, grid_cells):
            x, y = round(i * w / grid_cells), round(i * h / grid_cells)
            cv2.line(img, (x, 0), (x, h), GRID_COLOUR, 1)
            cv2.line(img, (0, y), (w, y), GRID_COLOUR, 1)
    for edge in (0.5 - cfg.center_band, 0.5 + cfg.center_band):
        x = round(edge * w)
        cv2.line(img, (x, 0), (x, h), BAND_COLOUR, 1)
    near = round(cfg.near_y * h)
    cv2.line(img, (0, near), (w, near), NEAR_COLOUR, 1)
    for d in detections:
        colour = COLOURS.get(d.label, OTHER_COLOUR)
        centre = (round(d.x * w), round(d.y * h))
        cv2.circle(img, centre, 8, colour, 2)
        text = f"{d.label} {d.score:.2f} x{d.x:.2f} y{d.y:.2f}"
        (text_w, _), _ = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, 0.4, 1)
        # Right of the circle, or left of it when the text would run off the right edge.
        text_x = centre[0] + 10 if centre[0] + 10 + text_w <= w else max(0, centre[0] - 10 - text_w)
        cv2.putText(img, text, (text_x, max(10, centre[1] - 6)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.4, colour, 1, cv2.LINE_AA)
    cv2.putText(img, status, (4, h - 6), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1, cv2.LINE_AA)
    return img


class DebugView:
    """Keeps the newest observed frame and serves it, annotated, as MJPEG on PORT."""

    def __init__(self, reader: LatestFrameReader, cfg: ControlConfig, grid_cells: Optional[int],
                 port: int = PORT) -> None:
        self._reader = reader
        self._cfg = cfg
        self._grid_cells = grid_cells
        self._port = port
        self._lock = threading.Lock()
        self._observed: Optional[tuple] = None  # (bgr, detections, seq, time.monotonic())
        self._server: Optional[ThreadingHTTPServer] = None

    def publish(self, bgr: np.ndarray, detections: Sequence[Detection], seq: int) -> None:
        """Called by CameraPerception with every frame it ran the detector on."""
        with self._lock:
            self._observed = (bgr, tuple(detections), seq, time.monotonic())

    def render(self) -> Optional[bytes]:
        """JPEG of the newest frame: the observed one with detections while the robot observes,
        else the camera's latest frame, so the camera can be aimed before BOOT is pressed."""
        with self._lock:
            observed = self._observed
        if observed is not None and time.monotonic() - observed[3] <= DETECTION_MAX_AGE_S:
            bgr, detections, seq, _ = observed
            status = f"seq {seq}, detector running"
        else:
            frame = self._reader.latest()
            bgr = frame.decode() if frame is not None else None
            if bgr is None:
                return None
            detections, status = (), f"seq {frame.seq}, detector idle until BOOT"
        img = annotate(bgr, detections, self._cfg, self._grid_cells, status)
        ok, jpeg = cv2.imencode(".jpg", img, [cv2.IMWRITE_JPEG_QUALITY, 70])
        return jpeg.tobytes() if ok else None

    def start(self) -> None:
        view = self

        class Handler(BaseHTTPRequestHandler):
            def do_GET(self) -> None:
                if self.path == "/":
                    self.send_response(200)
                    self.send_header("Content-Type", "text/html; charset=utf-8")
                    self.send_header("Content-Length", str(len(INDEX_HTML)))
                    self.end_headers()
                    self.wfile.write(INDEX_HTML)
                elif self.path == "/stream":
                    self.send_response(200)
                    self.send_header("Content-Type", f"multipart/x-mixed-replace; boundary={BOUNDARY}")
                    self.send_header("Cache-Control", "no-store")
                    self.end_headers()
                    try:
                        while True:
                            jpeg = view.render()
                            if jpeg is not None:
                                self.wfile.write(f"--{BOUNDARY}\r\nContent-Type: image/jpeg\r\n"
                                                 f"Content-Length: {len(jpeg)}\r\n\r\n".encode())
                                self.wfile.write(jpeg + b"\r\n")
                            time.sleep(1.0 / FPS)
                    except (BrokenPipeError, ConnectionResetError):
                        pass  # the page was closed
                else:
                    self.send_error(404)

            def log_message(self, *args) -> None:
                pass  # one line per request would bury the robot's own log

        try:
            self._server = ThreadingHTTPServer(("0.0.0.0", self._port), Handler)
        except OSError as exc:
            # The view is a debugging aid, so the robot still runs without it.
            print(f"[WARN] debug view disabled, cannot listen on port {self._port}: {exc}")
            return
        self._server.daemon_threads = True
        threading.Thread(target=self._server.serve_forever, name="debug-view", daemon=True).start()
        print(f"[INFO] debug view on port {self._port}: join the camera Wi-Fi and open "
              f"http://192.168.5.2:{self._port}/")

    def stop(self) -> None:
        if self._server is not None:
            self._server.shutdown()
            self._server.server_close()
