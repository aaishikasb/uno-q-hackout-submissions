# Essence Thief

A black-and-white platformer for the Arduino UNO Q arcade console, in the spirit of Limbo and Hollow Knight. **You become what you kill:** slay an animal, absorb its body, and shapeshift into it. Only element effects (ice, fire, lightning, water) are in colour.

## Controls

| Input | Human | Frost crab | Fox | Mammoth |
|---|---|---|---|---|
| Stick | Move | Crawl | Run | Stomp |
| A | Jump | Dance | Jump, again in the air (stick up + A: fire howl) | Jump |
| B | Sword (tap for a 3-hit combo; down-slash in the air) | Ice spit (short range) | Fireball (burns brambles and trees) | Trumpet |
| C | Cycle through the forms you own | | | |
| Hold stick click | Absorb the body you're standing over | | | |
| Shake the console | Lightning special (human only, after 3 kills): strikes every enemy on screen | | | |

The top bar always lists your current moves, the lightning charge and your hearts.

## Stages

1. **Caves:** crabs. Absorb one to open the exit.
2. **Crawlspaces:** a horde of crabs; walls you only pass as the crab.
3. **The pool:** hop the stones as the human, freeze the waterfall with crab ice, walk the ice.
4. **Grasslands:** foxes. Absorb one to open the exit.
5. **Obstacles:** a horde of foxes, bramble hedges to burn, double-jump cliffs, a crab-only exit.
6. **The giant tree:** burn the thicket, shoot the trunk over the stone wall and watch it burn, crawl out as the crab.
7. **The dragon:** alternates fire aura (only ice hurts) and ice armour (only fire hurts); immune to the sword and the special.
8. **The canyon:** absorb the mammoth and charge through the boulder piles.
9. **The gauntlet:** every form in one run: burn, double-jump, freeze, lightning, charge, crawl.
10. **The prisoner:** free the caged Storm Walker to win, then replay as them: B chain lightning (also one-shots the dragon, evaporates waterfalls, burns hedges), C electric dash through any obstacle.

## Run it

**App Lab:** import the ZIP, select the UNO Q, run. The first run downloads and compiles the sketch libraries (a few minutes).

**Terminal (Windows Git Bash or macOS/Linux, with `adb`):** from this folder, `sh scripts/deploy.sh` pushes the app to the App Lab copy on the board. Python-only changes restart in about a second; sketch changes rebuild the MCU (about a minute). `sh scripts/deploy.sh logs` follows the Python output.

## Setup and calibration

- Display: DIYables 3.5" TFT, HX8357D (`ARCADE_TFT_HX8357D 1` in `sketch/sketch.ino`; `0` for RM68140).
- Controls on Qwiic/Wire1 at 400 kHz: Buttons `0x3E`, Joystick `0x2C`, Movement `0x6A`.
- `python/preview.py`: `DEAD_ZONE 26`, `INVERT_X False`, `INVERT_Y True`, `MOVEMENT_ZERO_MG (50, -75, 1034)`, `MOVEMENT_DEAD_ZONE_MG 20`.
- `python/main.py`: tunable constants at the top (movement, forms, sword, enemies, fire spread, shake `SHAKE_THRESHOLD_MG`/`SHAKE_JOLTS`/`SHAKE_WINDOW`, `START_STAGE` 1-10 for testing).
- The MCU needs the Zephyr 0.55.2 firmware that matches the pinned core.

## How it's built

Python on the Linux side owns all rules: physics with slopes and one-way ledges, forms, combat, fire spreading, the dragon, rooms. The sketch on the MCU only draws: Python sends each room once (`game_room_row` / `game_room_draw`), single changed tiles (`game_set_tile`), and every frame a packed sprite list (`game_frame`), which returns the controls so each frame is one round trip. Changed areas are composed off-screen and sent to the display in one transfer, so nothing flickers.

## Credits

Built on the uno-q-hackout arcade starter (Arduino/Qualcomm). Libraries: DIYables TFT Touch Shield, Adafruit GFX, Arduino_RouterBridge, Arduino_Modulino. All art and levels are original and drawn in code; no external assets.
