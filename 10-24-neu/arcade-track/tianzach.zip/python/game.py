"""Sprite Tamer: catch elemental sprites and battle tamers on the UNO Q console.

The game turns calibrated controls into drawing requests; main.py sends them
over Bridge. The TFT is written pixel by pixel, so screens are drawn once and
then only the parts that change are repainted.
"""

import random

# Tilt is shown on the control test only; battles use the joystick to dodge.
TILT_AXIS = "ax"   # Movement axis that changes when the console tips left/right.
TILT_SIGN = 1      # Use -1 if tipping the console right reads LEFT.
TILT_MG = 300      # Acceleration change, from the calibrated neutral, that counts as a tilt.

STICK_THRESHOLD = 64   # Calibrated stick value (out of 128) that counts as a direction.
MOVE_REPEAT = 0.22     # Seconds between map steps while the stick is held.
MENU_REPEAT = 0.25     # Seconds between menu moves while the stick is held.
MESSAGE_SECONDS = 1.6  # Battle messages advance by themselves, or sooner with A.
ENCOUNTER_CHANCE = 0.2  # Chance of a wild sprite on each step into tall grass.
PARTY_SIZE = 3

BUTTON_A, BUTTON_B, BUTTON_C = 1, 2, 4
HAS_BUTTONS, HAS_STICK, HAS_MOVEMENT = 1, 2, 4

SCREEN_W = 480
TILE = 32
MAP_Y = 32
CHAR_W = 6  # Font cell width at text size 1; size n is n times wider.
DIALOG_WIDTH = 34


def rgb(r, g, b):
    return ((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3)


BLACK = 0
WHITE = 0xFFFF
GRAY = rgb(150, 150, 160)
YELLOW = rgb(255, 220, 60)
RED = rgb(240, 60, 60)
GREEN = rgb(90, 220, 100)
CYAN = rgb(80, 220, 255)

TYPES = ("FIRE", "WATER", "LEAF", "VOLT", "ROCK", "SHADE")
TYPE_COLORS = {"FIRE": rgb(255, 110, 60), "WATER": rgb(90, 160, 255), "LEAF": rgb(100, 220, 90),
               "VOLT": rgb(255, 220, 60), "ROCK": rgb(200, 170, 120), "SHADE": rgb(180, 130, 240)}
MOVES = {"FIRE": "FLARE", "WATER": "SPLASH", "LEAF": "VINE", "VOLT": "ZAP", "ROCK": "SLAM",
         "SHADE": "HEX"}
# Each type is strong against two others and weak against two others.
STRONG = {"FIRE": ("LEAF", "SHADE"), "WATER": ("FIRE", "ROCK"), "LEAF": ("WATER", "ROCK"),
          "VOLT": ("WATER", "SHADE"), "ROCK": ("FIRE", "VOLT"), "SHADE": ("LEAF", "VOLT")}

# (name, type, tier, variant feature drawn by the sketch, colour)
SPRITES = [
    ("EMBERKIT", "FIRE", 1, 1, rgb(255, 120, 40)), ("FLAREBIT", "FIRE", 1, 0, rgb(255, 90, 60)),
    ("PYROFOX", "FIRE", 2, 1, rgb(240, 80, 20)), ("SCORCHY", "FIRE", 2, 3, rgb(255, 150, 0)),
    ("BLAZEWING", "FIRE", 3, 2, rgb(255, 60, 40)), ("MAGMAW", "FIRE", 3, 4, rgb(200, 40, 20)),
    ("BUBBIT", "WATER", 1, 0, rgb(80, 160, 255)), ("PUDDLET", "WATER", 1, 3, rgb(100, 190, 240)),
    ("TIDEFIN", "WATER", 2, 2, rgb(40, 120, 230)), ("SPLASHY", "WATER", 2, 1, rgb(120, 200, 255)),
    ("CORALORD", "WATER", 3, 5, rgb(60, 100, 220)), ("WAVELORD", "WATER", 3, 4, rgb(30, 80, 200)),
    ("SPROUTLE", "LEAF", 1, 0, rgb(90, 200, 80)), ("MOSSBUN", "LEAF", 1, 1, rgb(110, 170, 70)),
    ("LEAFKIN", "LEAF", 2, 3, rgb(60, 180, 90)), ("THORNET", "LEAF", 2, 4, rgb(40, 140, 60)),
    ("BLOOMY", "LEAF", 3, 2, rgb(220, 120, 200)), ("OAKLING", "LEAF", 3, 5, rgb(80, 120, 40)),
    ("ZAPLING", "VOLT", 1, 0, rgb(250, 220, 60)), ("SPARKIT", "VOLT", 1, 1, rgb(255, 240, 90)),
    ("BUZZBY", "VOLT", 2, 2, rgb(230, 200, 40)), ("VOLTAIL", "VOLT", 2, 3, rgb(255, 200, 0)),
    ("AMPEROO", "VOLT", 3, 4, rgb(240, 180, 30)), ("THUNDRAKE", "VOLT", 3, 5, rgb(220, 160, 0)),
    ("PEBBLET", "ROCK", 1, 0, rgb(160, 140, 110)), ("CRAGPAW", "ROCK", 1, 1, rgb(140, 120, 90)),
    ("GRAVLIN", "ROCK", 2, 3, rgb(120, 110, 100)), ("STONEX", "ROCK", 2, 4, rgb(170, 150, 120)),
    ("QUARRION", "ROCK", 3, 2, rgb(110, 90, 70)), ("BOULDERON", "ROCK", 3, 5, rgb(150, 130, 100)),
    ("WISPY", "SHADE", 1, 0, rgb(170, 140, 230)), ("GLOOMY", "SHADE", 1, 1, rgb(130, 100, 200)),
    ("SHADEKIT", "SHADE", 2, 3, rgb(110, 70, 170)), ("DUSKFANG", "SHADE", 2, 4, rgb(90, 60, 150)),
    ("PHANTOAD", "SHADE", 3, 2, rgb(150, 90, 210)), ("UMBRAX", "SHADE", 3, 5, rgb(80, 40, 130)),
]
SPRITE_IDS = {entry[0]: i for i, entry in enumerate(SPRITES)}
STARTERS = ("EMBERKIT", "BUBBIT", "SPROUTLE")

DODGE_PROMPTS = {(-1, 0): "<<< PUSH LEFT", (1, 0): "PUSH RIGHT >>>",
                 (0, -1): "^^ PUSH UP ^^", (0, 1): "vv PUSH DOWN vv"}
WALLS = set("#T~c")  # An opened chest stays in place as an obstacle.
INTRO = [
    ("", "", "In the land of PIXELIA, people team up with SPRITES: little creatures of six elements."),
    ("", "", "FIRE beats LEAF, WATER beats FIRE, LEAF beats WATER... learn the matchups!"),
    ("", "", "But the SHADOW KING is stealing sprites to rule the land."),
    ("PROFESSOR", "", "Young tamer, choose your first sprite and stop him!"),
]
ENDING = [
    ("SHADOW KING", "B", "Impossible... beaten by a rookie tamer!"),
    ("", "", "The stolen sprites run free again. PIXELIA has a new CHAMPION!"),
]

# Tamers ('N' on the map) are listed per stage in reading order; the last one is
# the stage leader guarding the exit. Each team is [(sprite name, level), ...].
STAGES = [
    {
        "name": "MEADOW", "theme": 0, "wall": "T", "types": ("LEAF", "VOLT", "ROCK"),
        "tier": 1, "wild": (3, 5), "orbs": 3, "window": 1.7,
        "rows": [
            "TTTTTTTTTTTTTTT",
            'TP..""".T....CT',
            'T...""".......T',
            "T.......N.....T",
            'TT.""".TTTT...T',
            'T..""".T""""..T',
            'T......T"""".TT',
            "T...........NET",
            "TTTTTTTTTTTTTTT",
        ],
        "intro": "Stage 1: Sunny Meadow. Wild sprites hide in tall grass. Weaken one, then CATCH it!",
        "tamers": [
            ("YOUNGSTER JO", "My sprite is the cutest! Battle!", [("MOSSBUN", 4)]),
            ("LEADER FERN", "Show me the bond with your sprites!", [("PEBBLET", 6), ("LEAFKIN", 6)]),
        ],
    },
    {
        "name": "RIVER", "theme": 0, "wall": "T", "types": ("WATER", "LEAF", "VOLT"),
        "tier": 1, "wild": (5, 7), "orbs": 3, "window": 1.6,
        "rows": [
            "TTTTTTTTTTTTTTT",
            'TP..~~~..""".CT',
            'T...~~~.."""..T',
            "T..N.......~~.T",
            'T"""..~~...~~.T',
            'T"""..~~..N...T',
            'T.....~~.""".TT',
            "T...........NET",
            "TTTTTTTTTTTTTTT",
        ],
        "intro": "Stage 2: Rushing River. WATER sprites are strong here. LEAF and VOLT beat them!",
        "tamers": [
            ("SWIMMER MAY", "The river makes my sprites tough!", [("PUDDLET", 6)]),
            ("FISHER RON", "Hooked a battle!", [("ZAPLING", 7), ("BUBBIT", 7)]),
            ("LEADER MARINA", "Can you weather my waves?", [("TIDEFIN", 9), ("SPLASHY", 9)]),
        ],
    },
    {
        "name": "CAVE", "theme": 1, "wall": "#", "types": ("ROCK", "SHADE", "VOLT"),
        "tier": 2, "wild": (7, 9), "orbs": 3, "window": 1.5,
        "rows": [
            "###############",
            '#P..#.."".#..C#',
            '#.#.#."".#....#',
            "#.#...N.....#.#",
            "#.####.###.##.#",
            '#.."""....#...#',
            '##.""".##.#..##',
            "#.........#.NE#",
            "###############",
        ],
        "intro": "Stage 3: Echo Cave. ROCK and SHADE sprites lurk in the dark.",
        "tamers": [
            ("HIKER BO", "Rock solid!", [("PEBBLET", 9), ("GLOOMY", 9)]),
            ("LEADER STONE", "Nothing breaks my wall!", [("GRAVLIN", 11), ("STONEX", 11)]),
        ],
    },
    {
        "name": "VOLCANO", "theme": 1, "wall": "#", "types": ("FIRE", "ROCK"),
        "tier": 2, "wild": (9, 11), "orbs": 3, "window": 1.4,
        "rows": [
            "###############",
            '#P...#"""....C#',
            '#.##.#"""#.##.#',
            "#..#...N.#..#.#",
            "##.#.###.#.##.#",
            '#""".....N....#',
            '#""".####.#.###',
            "#.........#.NE#",
            "###############",
        ],
        "intro": "Stage 4: Ember Volcano. It is hot! WATER sprites shine here.",
        "tamers": [
            ("FIREBOY KAI", "Feel the heat!", [("FLAREBIT", 10)]),
            ("RANGER SUE", "Two at once? Sure!", [("CRAGPAW", 11), ("PYROFOX", 11)]),
            ("LEADER BLAZE", "My flames never go out!", [("SCORCHY", 13), ("PYROFOX", 13), ("MAGMAW", 12)]),
        ],
    },
    {
        "name": "STORM", "theme": 2, "wall": "=", "types": ("VOLT", "WATER", "SHADE"),
        "tier": 3, "wild": (11, 13), "orbs": 4, "window": 1.3,
        "rows": [
            "###############",
            '#P.""""..#..C.#',
            '#..""""..#.##.#',
            "#......N.#....#",
            "####.#####.#..#",
            '#..N....."""N.#',
            "#.####.####..##",
            "#...........NE#",
            "###############",
        ],
        "intro": "Stage 5: Storm Peak. Thunder rolls. Rare sprites live up here!",
        "tamers": [
            ("PILOT LIN", "Buzz buzz!", [("BUZZBY", 12)]),
            ("RAIDER ZED", "The storm hides my shadows!", [("SHADEKIT", 13), ("SPLASHY", 13)]),
            ("SKIER DEX", "Zap you!", [("VOLTAIL", 13)]),
            ("LEADER VOLTA", "One million volts!", [("AMPEROO", 15), ("WAVELORD", 14)]),
        ],
    },
    {
        "name": "TOWER", "theme": 2, "wall": "=", "types": TYPES,
        "tier": 3, "wild": (13, 15), "orbs": 4, "window": 1.2,
        "rows": [
            "###############",
            '#P..""".....N.#',
            '######"""####.#',
            "#...N.........#",
            "#.#C###########",
            '#...""""...N..#',
            "#############.#",
            "#B............#",
            "###############",
        ],
        "intro": "Stage 6: Shadow Tower. The SHADOW KING waits at the top. Good luck, tamer!",
        "tamers": [
            ("AGENT ACE", "The King's guard stops you here!", [("DUSKFANG", 14), ("BLOOMY", 14)]),
            ("AGENT NIX", "Hop to it!", [("PHANTOAD", 15)]),
            ("AGENT VEX", "You won't reach the King!", [("QUARRION", 15), ("CORALORD", 15)]),
        ],
        "boss": ("SHADOW KING", "These sprites are MINE now. Try and take them!",
                 [("UMBRAX", 17), ("MAGMAW", 16), ("THUNDRAKE", 16)]),
    },
]


def wrap(text, width):
    lines, line = [], ""
    for word in text.split():
        if line and len(line) + 1 + len(word) > width:
            lines.append(line)
            line = word
        else:
            line = f"{line} {word}" if line else word
    if line:
        lines.append(line)
    return lines


def make_sprite(name, level):
    sprite = {"id": SPRITE_IDS[name], "level": level, "xp": 0}
    restat(sprite)
    sprite["hp"] = sprite["max_hp"]
    return sprite


def restat(sprite):
    tier = SPRITES[sprite["id"]][2]
    sprite["max_hp"] = 16 + 3 * tier + 3 * sprite["level"]
    sprite["atk"] = 4 + tier + sprite["level"]


def spec(sprite):
    return SPRITES[sprite["id"]]


def effectiveness(attacker, defender):
    a, d = spec(attacker)[1], spec(defender)[1]
    if d in STRONG[a]:
        return 1.5
    if a in STRONG[d]:
        return 0.67
    return 1.0


class Canvas:
    """Collects the Bridge drawing calls for one update."""

    def __init__(self):
        self.calls = []

    def rect(self, x, y, w, h, color, fill=True):
        self.calls.append(("arcade_rect", x, y, w, h, color, 1 if fill else 0))

    def frame(self, x, y, w, h, color=WHITE):
        self.rect(x, y, w, h, BLACK)
        self.rect(x, y, w, h, color, False)
        self.rect(x + 2, y + 2, w - 4, h - 4, color, False)

    def text(self, x, y, text, color=WHITE, size=2):
        self.calls.append(("arcade_text", x, y, size, color, text))

    def center(self, y, text, color=WHITE, size=2):
        self.text((SCREEN_W - len(text) * CHAR_W * size) // 2, y, text, color, size)

    def tile(self, x, y, glyph, size=TILE, theme=3):
        self.calls.append(("arcade_tile", x, y, size, theme, glyph))

    def tiles(self, row, theme, text):
        self.calls.append(("arcade_tiles", row, theme, text))

    def sprite(self, x, y, sprite, size=64):
        _, kind, _, variant, color = spec(sprite)
        self.calls.append(("arcade_sprite", x, y, size, TYPES.index(kind), variant, color))

    def clear(self):
        self.rect(0, 0, SCREEN_W, 320, BLACK)


class Controls:
    """One calibrated input snapshot plus the buttons newly pressed since the last one."""

    def __init__(self, values, previous_buttons):
        self.values = values
        self.connected = values["connected"]
        self.held = values["buttons"]
        self.pressed = self.held & ~previous_buttons
        x, y = values["x"], values["y"]
        if max(abs(x), abs(y)) < STICK_THRESHOLD:
            self.direction = (0, 0)
        elif abs(x) >= abs(y):
            self.direction = (1 if x > 0 else -1, 0)
        else:
            self.direction = (0, 1 if y > 0 else -1)
        tilt = values[TILT_AXIS] * TILT_SIGN
        if not self.connected & HAS_MOVEMENT or abs(tilt) < TILT_MG:
            self.tilt = 0
        else:
            self.tilt = 1 if tilt > 0 else -1

    def hit(self, button):
        return bool(self.pressed & button)


class Game:
    TIMERS = ("started_at", "blink_at", "next_move", "menu_next", "message_until",
              "deadline", "step_started", "test_at")

    def __init__(self, rng=None):
        self.rng = rng or random.Random()
        self.previous_buttons = 0
        self.epoch = None
        self.paused_missing = 0
        self.paused_at = 0
        self.now = 0
        self.ctrl = Controls({"connected": 0, "buttons": 0, "x": 0, "y": 0,
                              "ax": 0, "ay": 0, "az": 0}, 0)
        self.party = []
        self.title()

    # ---- Called by main.py -------------------------------------------------

    def screen_lost(self):
        """The display may hold something else now; repaint everything next update."""
        self.redraw = True

    def update(self, values, epoch, now):
        ctrl = Controls(values, self.previous_buttons)
        self.previous_buttons = ctrl.held
        self.ctrl, self.now = ctrl, now
        c = Canvas()
        if epoch != self.epoch:
            self.epoch = epoch
            self.redraw = True

        # The control test stays live so it can show which module is missing.
        missing = (HAS_BUTTONS | HAS_STICK) & ~ctrl.connected
        if missing and self.state != "controls":
            if not self.paused_missing:
                self.paused_at = now
            if missing != self.paused_missing or self.redraw:
                self.draw_paused(c, missing)
                self.redraw = False
            self.paused_missing = missing
            return c.calls
        if self.paused_missing:
            for name in self.TIMERS:
                if getattr(self, name, None) is not None:
                    setattr(self, name, getattr(self, name) + now - self.paused_at)
            self.paused_missing = 0
            self.redraw = True
            ctrl.pressed = 0  # Buttons held while reconnecting are not new presses.

        if self.redraw:
            self.redraw = False
            getattr(self, "draw_" + self.state)(c)
        getattr(self, "step_" + self.state)(c)
        return c.calls

    def draw_paused(self, c, missing):
        c.frame(60, 96, 360, 128, RED)
        c.center(110, "CONTROLS DISCONNECTED", RED)
        c.center(142, "Buttons:%s  Stick:%s" % ("--" if missing & HAS_BUTTONS else "OK",
                                                "--" if missing & HAS_STICK else "OK"))
        c.center(168, "Check the Qwiic cable.", GRAY)
        c.center(194, "The game is paused.", GRAY)

    # ---- Title and control test -------------------------------------------

    def title(self):
        self.state = "title"
        self.redraw = True
        self.blink_at = 0
        self.blink_on = False

    def draw_title(self, c):
        c.clear()
        c.center(30, "SPRITE TAMER", YELLOW, 4)
        c.center(74, "Catch them. Train them. Win!", GRAY)
        for i, name in enumerate(STARTERS):
            c.sprite(112 + i * 96, 108, make_sprite(name, 1))
        c.center(232, "B  Control test", GRAY)
        self.blink_at = self.now

    def step_title(self, c):
        if self.now >= self.blink_at:
            self.blink_at = self.now + 0.7
            self.blink_on = not self.blink_on
            c.rect(100, 200, 280, 16, BLACK)
            if self.blink_on:
                c.center(200, "PRESS A TO START", WHITE)
        if self.ctrl.hit(BUTTON_A):
            self.new_game()
        elif self.ctrl.hit(BUTTON_B):
            self.state = "controls"
            self.redraw = True

    def draw_controls(self, c):
        c.clear()
        c.center(12, "CONTROL TEST", YELLOW, 3)
        c.text(20, 252, "In battle, push the stick the way", GRAY)
        c.text(20, 272, "the arrow points to dodge.", GRAY)
        c.text(20, 298, "B or C: back to title", GRAY)
        self.test_lines = [None] * 5
        self.test_at = 0

    def step_controls(self, c):
        ctrl = self.ctrl
        if ctrl.hit(BUTTON_B) or ctrl.hit(BUTTON_C):
            self.title()
            return
        if self.now < self.test_at:
            return
        self.test_at = self.now + 0.2
        v = ctrl.values
        ok = lambda bit: "OK" if ctrl.connected & bit else "--"
        names = {(0, 0): "--", (1, 0): "RIGHT", (-1, 0): "LEFT", (0, 1): "DOWN", (0, -1): "UP"}
        lines = [
            f"Buttons:{ok(HAS_BUTTONS)} Stick:{ok(HAS_STICK)} Move:{ok(HAS_MOVEMENT)}",
            "A:%d B:%d C:%d Stick press:%d" % tuple(
                int(bool(ctrl.held & bit)) for bit in (1, 2, 4, 8)),
            f"Stick {v['x']:4} {v['y']:4}  {names[ctrl.direction]}",
            f"Move mg {v['ax']:6} {v['ay']:6}",
            "Tilt: " + {-1: "LEFT", 0: "--", 1: "RIGHT"}[ctrl.tilt],
        ]
        for i, line in enumerate(lines):
            if line != self.test_lines[i]:
                self.test_lines[i] = line
                c.rect(20, 64 + i * 34, 440, 16, BLACK)
                c.text(20, 64 + i * 34, line, CYAN if i == 4 else WHITE)

    # ---- Story pages and map dialogs --------------------------------------

    def story(self, pages, then, c=None):
        """Show pages one by one; A turns the page, then `then(canvas)` runs.

        With a canvas the pages open as a dialog over the map instead of a new screen.
        """
        self.state = "story"
        self.pages = pages
        self.page = 0
        self.after_story = then
        self.overlay = c is not None
        if self.overlay:
            c.frame(8, 200, 464, 112)
            self.draw_page(c)
        else:
            self.redraw = True

    def draw_story(self, c):
        if self.overlay:
            self.draw_map(c)
        else:
            c.clear()
        c.frame(8, 200, 464, 112)
        self.draw_page(c)

    def draw_page(self, c):
        speaker, glyph, text = self.pages[self.page]
        if not self.overlay:
            if glyph:
                c.tile(192, 48, glyph, 96)
            elif self.party:
                c.sprite(192, 48, self.party[0], 96)
            else:
                c.rect(192, 48, 96, 96, BLACK)
        c.rect(12, 204, 456, 104, BLACK)
        if speaker:
            c.text(20, 210, speaker, YELLOW)
        for i, line in enumerate(wrap(text, DIALOG_WIDTH)[:3]):
            c.text(20, 234 + i * 24, line)
        c.text(440, 290, "A>", GREEN)

    def step_story(self, c):
        if not self.ctrl.hit(BUTTON_A):
            return
        self.page += 1
        if self.page < len(self.pages):
            self.draw_page(c)
        else:
            self.after_story(c)

    def say_on_map(self, c, text):
        self.story([("", "", text)], self.close_dialog, c)

    def close_dialog(self, c):
        self.state = "map"
        self.next_move = 0
        for row in range(5, 9):  # The dialog box covers these map rows.
            c.tiles(row, self.stage["theme"], self.row_text(row))

    # ---- Game flow ---------------------------------------------------------

    def new_game(self):
        self.party = []
        self.orbs = 5
        self.caught = set()
        self.started_at = self.now
        self.story(INTRO, self.choose_starter)

    def choose_starter(self, c):
        self.state = "starter"
        self.redraw = True
        self.starter_index = 0
        self.menu_next = 0

    def draw_starter(self, c):
        c.clear()
        c.center(20, "CHOOSE YOUR SPRITE", YELLOW, 3)
        for i, name in enumerate(STARTERS):
            sprite = make_sprite(name, 5)
            kind = spec(sprite)[1]
            c.sprite(64 + i * 128, 90, sprite, 96)
            c.text(112 + i * 128 - len(name) * 6, 204, name)
            c.text(112 + i * 128 - len(kind) * 6, 228, kind, TYPE_COLORS[kind])
        c.center(288, "Stick: choose   A: confirm", GRAY)
        self.draw_starter_cursor(c)

    def draw_starter_cursor(self, c):
        for i in range(3):
            c.rect(56 + i * 128, 82, 112, 112, YELLOW if i == self.starter_index else BLACK, False)

    def step_starter(self, c):
        dx = self.ctrl.direction[0]
        if dx == 0:
            self.menu_next = 0
        elif self.now >= self.menu_next:
            self.menu_next = self.now + MENU_REPEAT
            self.starter_index = (self.starter_index + dx) % 3
            self.draw_starter_cursor(c)
        if self.ctrl.hit(BUTTON_A):
            name = STARTERS[self.starter_index]
            self.party = [make_sprite(name, 5)]
            self.caught.add(SPRITE_IDS[name])
            self.story([("PROFESSOR", "", f"{name} is yours! Take 5 CATCH ORBS too. Off you go!")],
                       lambda c: self.enter_stage(0))

    def enter_stage(self, index):
        self.load_stage(index)
        for sprite in self.party:
            sprite["hp"] = sprite["max_hp"]
        self.saved = ([dict(s) for s in self.party], self.orbs)
        self.story([("", "", self.stage["intro"])], self.to_map)

    def load_stage(self, index):
        self.stage_index = index
        self.stage = STAGES[index]
        self.grid = [list(row) for row in self.stage["rows"]]
        self.tamer_at = {}
        tamers = iter(self.stage["tamers"])
        for y, row in enumerate(self.grid):
            for x, glyph in enumerate(row):
                if glyph == "P":
                    self.pos = (x, y)
                    row[x] = "."
                elif glyph == "N":
                    self.tamer_at[(x, y)] = next(tamers)
        self.leader_pos = list(self.tamer_at)[-1] if self.tamer_at else None
        self.facing = (1, 0)

    def to_map(self, c=None):
        self.state = "map"
        self.redraw = True
        self.next_move = 0

    # ---- Map ---------------------------------------------------------------

    def map_glyph(self, x, y):
        if (x, y) == self.pos:
            return "@"
        glyph = self.grid[y][x]
        return self.stage["wall"] if glyph == "#" else glyph

    def row_text(self, y):
        return "".join(self.map_glyph(x, y) for x in range(len(self.grid[y])))

    def draw_tile(self, c, x, y):
        c.tile(x * TILE, MAP_Y + y * TILE, self.map_glyph(x, y), TILE, self.stage["theme"])

    def draw_hud(self, c):
        lead = self.party[0]
        c.rect(0, 0, SCREEN_W, MAP_Y, BLACK)
        c.text(8, 8, self.stage["name"], YELLOW)
        c.text(116, 8, f"HP {lead['hp']}/{lead['max_hp']}  ORB {self.orbs}  DEX {len(self.caught)}/{len(SPRITES)}")

    def draw_map(self, c):
        self.draw_hud(c)
        for row in range(len(self.grid)):
            c.tiles(row, self.stage["theme"], self.row_text(row))

    def step_map(self, c):
        direction = self.ctrl.direction
        if direction == (0, 0):
            self.next_move = 0
        elif self.now >= self.next_move:
            self.next_move = self.now + MOVE_REPEAT
            self.facing = direction
            self.try_move(c, direction)
            if self.state != "map":
                return
        if self.ctrl.hit(BUTTON_A):
            x, y = self.pos
            self.interact(c, x + self.facing[0], y + self.facing[1])

    def try_move(self, c, direction):
        x, y = self.pos
        nx, ny = x + direction[0], y + direction[1]
        glyph = self.grid[ny][nx]
        if glyph in WALLS:
            return
        if glyph in "CNB":
            self.interact(c, nx, ny)
            return
        self.pos = (nx, ny)
        self.draw_tile(c, x, y)
        self.draw_tile(c, nx, ny)
        if glyph == "E":
            self.stage_complete()
        elif glyph == '"' and self.rng.random() < ENCOUNTER_CHANCE:
            self.wild_battle()

    def interact(self, c, x, y):
        glyph = self.grid[y][x]
        if glyph == "C":
            self.grid[y][x] = "c"
            self.draw_tile(c, x, y)
            self.orbs += self.stage["orbs"]
            self.draw_hud(c)
            self.say_on_map(c, f"You found {self.stage['orbs']} CATCH ORBS!")
        elif glyph == "c":
            self.say_on_map(c, "The chest is empty.")
        elif glyph == "N":
            name, line, team = self.tamer_at[(x, y)]
            self.story([(name, "", line)], lambda c: self.tamer_battle(name, team, (x, y)), c)
        elif glyph == "B":
            name, line, team = self.stage["boss"]
            self.story([(name, "", line)],
                       lambda c: self.tamer_battle(name, team, (x, y), boss=True), c)

    def stage_complete(self):
        index = self.stage_index + 1
        self.story([("", "", f"Stage clear! Your sprites are rested. On to the {STAGES[index]['name']}...")],
                   lambda c: self.enter_stage(index))

    # ---- Battle ------------------------------------------------------------

    def wild_battle(self):
        stage = self.stage
        pool = [s[0] for s in SPRITES if s[1] in stage["types"] and s[2] <= stage["tier"]]
        low, high = stage["wild"]
        foe = make_sprite(self.rng.choice(pool), self.rng.randint(low, high))
        self.start_battle(None, [foe], None, f"A wild {spec(foe)[0]} appeared!")

    def tamer_battle(self, name, team, at, boss=False):
        foes = [make_sprite(sprite, level) for sprite, level in team]
        self.start_battle(name, foes, at, f"{name} sends out {spec(foes[0])[0]}!", boss)

    def start_battle(self, tamer, foes, at, text, boss=False):
        self.tamer, self.foes, self.tamer_pos, self.boss = tamer, foes, at, boss
        self.foe = foes[0]
        self.active = next(s for s in self.party if s["hp"] > 0)
        self.party.remove(self.active)
        self.party.insert(0, self.active)
        self.state = "battle"
        self.redraw = True
        self.menu_index = 0
        self.menu_next = 0
        self.turn = 0
        self.say(None, text, self.player_turn)

    def draw_battle(self, c):
        c.clear()
        c.frame(8, 136, 464, 56)
        c.frame(8, 200, 228, 112)
        c.frame(244, 200, 228, 112)
        self.draw_foe(c)
        self.draw_message(c)
        self.draw_menu(c)
        self.draw_active(c)

    def draw_foe(self, c):
        name, kind = spec(self.foe)[:2]
        c.rect(12, 8, 300, 60, BLACK)
        c.text(20, 12, name, YELLOW)
        c.text(20, 32, f"Lv{self.foe['level']}", WHITE)
        c.text(80, 32, kind, TYPE_COLORS[kind])
        if self.tamer:
            c.text(176, 32, f"x{sum(f['hp'] > 0 for f in self.foes)}", GRAY)
        c.sprite(352, 16, self.foe, 96)
        self.draw_foe_hp(c)

    def draw_foe_hp(self, c):
        foe = self.foe
        width = 160 * foe["hp"] // foe["max_hp"]
        c.rect(20, 54, 160, 10, BLACK)
        c.rect(20, 54, width, 10, RED if foe["hp"] * 4 < foe["max_hp"] else GREEN)
        c.rect(20, 54, 160, 10, WHITE, False)

    def menu_options(self):
        wild = self.tamer is None
        return [("FIGHT", True), (f"CATCH x{self.orbs}", wild and self.orbs > 0),
                ("SWAP", sum(s["hp"] > 0 for s in self.party) > 1), ("RUN", wild)]

    def draw_menu(self, c):
        c.rect(12, 204, 220, 104, BLACK)
        active = self.phase == "menu"
        for i, (label, usable) in enumerate(self.menu_options()):
            c.text(40, 214 + i * 24, label, WHITE if active and usable else GRAY)
        if active:
            c.text(18, 214 + self.menu_index * 24, ">", YELLOW)

    def draw_active(self, c):
        s = self.active
        name, kind = spec(s)[:2]
        c.sprite(64, 68, s, 64)
        c.rect(248, 204, 220, 104, BLACK)
        c.text(260, 214, name, YELLOW)
        c.text(260, 238, f"Lv{s['level']}", WHITE)
        c.text(320, 238, kind, TYPE_COLORS[kind])
        c.text(260, 262, f"HP {s['hp']}/{s['max_hp']}", RED if s["hp"] * 4 < s["max_hp"] else WHITE)
        c.text(260, 286, f"XP {s['xp']}/{s['level'] * 10}", GRAY)

    def draw_message(self, c):
        c.rect(12, 140, 456, 48, BLACK)
        if self.phase == "dodge":
            prompt = DODGE_PROMPTS[self.dodge_dir]
            c.center(146, prompt, CYAN, 3)
            if self.dodge_total > 1:
                c.text(424, 150, f"{self.dodge_total - len(self.dodge_queue)}/{self.dodge_total}", YELLOW)
            self.bar_width = 440
            c.rect(20, 176, 440, 6, CYAN)
        else:
            for i, line in enumerate(wrap(self.message_text, 36)[:2]):
                c.text(24, 146 + i * 22, line)

    def say(self, c, text, then, seconds=MESSAGE_SECONDS):
        """Show a battle message; `then(canvas)` runs after a timeout or an A press."""
        self.phase = "message"
        self.message_text = text
        self.message_until = self.now + seconds
        self.after_message = then
        if c is not None:
            self.draw_message(c)

    def step_battle(self, c):
        ctrl = self.ctrl
        if self.phase == "message":
            if ctrl.hit(BUTTON_A) or self.now >= self.message_until:
                self.after_message(c)
        elif self.phase == "menu":
            self.step_menu(c)
        elif self.phase == "prepare":
            if self.now >= self.deadline:
                self.next_dodge(c)
        elif self.phase == "dodge":
            self.step_dodge(c)
        elif self.phase == "recover":
            # Wait for the stick to return to the centre before the next arrow.
            settled = ctrl.direction == (0, 0) and self.now - self.step_started > 0.25
            if settled or self.now - self.step_started > 0.8:
                self.next_dodge(c)

    def player_turn(self, c):
        self.phase = "menu"
        self.message_text = f"What will {spec(self.active)[0]} do?"
        self.draw_message(c)
        self.draw_menu(c)

    def step_menu(self, c):
        dy = self.ctrl.direction[1]
        if dy == 0:
            self.menu_next = 0
        elif self.now >= self.menu_next:
            self.menu_next = self.now + MENU_REPEAT
            old = self.menu_index
            self.menu_index = (self.menu_index + dy) % 4
            c.rect(18, 214 + old * 24, 12, 16, BLACK)
            c.text(18, 214 + self.menu_index * 24, ">", YELLOW)
        if self.ctrl.hit(BUTTON_A):
            self.choose(c)

    def choose(self, c):
        choice = self.menu_index
        if choice == 0:
            self.attack(c)
        elif choice == 1:
            self.throw_orb(c)
        elif choice == 2:
            others = [s for s in self.party if s["hp"] > 0 and s is not self.active]
            if not others:
                self.say(c, "No other sprite can fight!", self.player_turn, 1.0)
            else:
                self.bring_out(c, others[0])
                self.say(c, f"Go, {spec(self.active)[0]}!", self.enemy_turn)
        elif self.tamer:
            self.say(c, "You can't run from a tamer battle!", self.player_turn, 1.0)
        else:
            self.say(c, "Got away safely!", self.to_map, 1.0)
        self.draw_menu(c)

    def bring_out(self, c, sprite):
        self.active = sprite
        self.party.remove(sprite)
        self.party.insert(0, sprite)
        self.draw_active(c)

    def attack(self, c):
        a, foe = self.active, self.foe
        mult = effectiveness(a, foe)
        damage = max(1, round((a["atk"] + self.rng.randint(0, 2)) * mult))
        foe["hp"] = max(0, foe["hp"] - damage)
        note = " Super effective!" if mult > 1 else " Not very effective." if mult < 1 else ""
        self.draw_foe_hp(c)
        self.say(c, f"{MOVES[spec(a)[1]]}! {damage} damage.{note}", self.after_attack)

    def throw_orb(self, c):
        if self.tamer:
            self.say(c, "You can't catch a tamer's sprite!", self.player_turn, 1.0)
            return
        if not self.orbs:
            self.say(c, "No CATCH ORBS left!", self.player_turn, 1.0)
            return
        self.orbs -= 1
        foe = self.foe
        chance = 0.25 + 0.65 * (1 - foe["hp"] / foe["max_hp"])
        if self.rng.random() < chance:
            self.caught.add(foe["id"])
            foe["hp"] = foe["max_hp"]
            if len(self.party) < PARTY_SIZE:
                self.party.append(foe)
                text = f"Gotcha! {spec(foe)[0]} joined your team!"
            else:
                text = f"Gotcha! {spec(foe)[0]} was sent to your PC."
            self.say(c, text, self.to_map, 2.0)
        else:
            self.say(c, f"Oh no! {spec(foe)[0]} broke free!", self.enemy_turn)

    def after_attack(self, c):
        if self.foe["hp"] > 0:
            self.enemy_turn(c)
            return
        a = self.active
        gain = self.foe["level"] * 4
        a["xp"] += gain
        text = f"{spec(self.foe)[0]} fainted! +{gain} XP"
        if a["xp"] >= a["level"] * 10:
            a["xp"] -= a["level"] * 10
            a["level"] += 1
            restat(a)
            a["hp"] = a["max_hp"]
            text = f"{spec(a)[0]} grew to Lv{a['level']}! HP restored."
        self.draw_active(c)
        self.say(c, text, self.next_foe)

    def next_foe(self, c):
        alive = [f for f in self.foes if f["hp"] > 0]
        if alive:
            self.foe = alive[0]
            self.draw_foe(c)
            self.say(c, f"{self.tamer} sends out {spec(self.foe)[0]}!", self.player_turn)
        elif self.boss:
            self.story(ENDING, self.victory)
        elif self.tamer:
            x, y = self.tamer_pos
            self.grid[y][x] = "."
            for sprite in self.party:
                sprite["hp"] = min(sprite["max_hp"], sprite["hp"] + sprite["max_hp"] // 2)
            self.say(c, f"You beat {self.tamer}! Your sprites rest a bit.", self.to_map, 2.0)
        else:
            self.to_map()

    def enemy_turn(self, c):
        self.turn += 1
        strong = self.boss or (self.tamer is not None and self.tamer_pos == self.leader_pos)
        combo = strong and self.turn % 3 == 0
        count = (3 if combo else 2) if self.boss else (2 if combo else 1)
        self.dodge_queue = [self.rng.choice(list(DODGE_PROMPTS)) for _ in range(count)]
        self.dodge_total = count
        self.dodge_window = self.stage["window"] * (0.85 if self.boss else 1)
        self.damage_taken = 0
        self.phase = "prepare"
        self.deadline = self.now + 0.9
        name = spec(self.foe)[0]
        self.message_text = f"{name} unleashes a combo!" if count > 1 else f"{name} attacks!"
        self.draw_message(c)

    def next_dodge(self, c):
        if not self.dodge_queue:
            self.finish_enemy_turn(c)
            return
        self.dodge_dir = self.dodge_queue.pop(0)
        self.phase = "dodge"
        self.step_started = self.now
        self.deadline = self.now + self.dodge_window
        self.draw_message(c)

    def step_dodge(self, c):
        push = self.ctrl.direction
        success, failed = push == self.dodge_dir, push not in ((0, 0), self.dodge_dir)
        if not success and (failed or self.now >= self.deadline):
            a, foe = self.active, self.foe
            damage = max(1, round((foe["atk"] + self.rng.randint(0, 2)) * effectiveness(foe, a)))
            if self.dodge_total > 1:
                damage = max(1, round(damage * 0.7))
            a["hp"] = max(0, a["hp"] - damage)
            self.damage_taken += damage
            self.end_dodge(c, f"HIT! -{damage} HP", RED)
            self.draw_active(c)
        elif success:
            self.end_dodge(c, "DODGED!", GREEN)
        else:
            # Shrink the timer bar in 40-pixel steps to keep redraws small.
            left = 440 * (self.deadline - self.now) / self.dodge_window
            width = int(left // 40 * 40)
            if width < self.bar_width:
                c.rect(20 + width, 176, self.bar_width - width, 6, BLACK)
                self.bar_width = width

    def end_dodge(self, c, text, color):
        self.phase = "recover"
        self.step_started = self.now
        c.rect(12, 140, 456, 48, BLACK)
        c.center(152, text, color, 3)
        if self.active["hp"] <= 0:
            self.dodge_queue = []

    def finish_enemy_turn(self, c):
        name = spec(self.active)[0]
        if self.active["hp"] > 0:
            text = ("Perfect! No damage taken." if not self.damage_taken
                    else f"{name} took {self.damage_taken} damage.")
            self.say(c, text, self.player_turn, 1.0)
        elif any(s["hp"] > 0 for s in self.party):
            self.say(c, f"{name} fainted!", self.send_next)
        else:
            self.say(c, "All your sprites fainted...", self.lose_battle, 2.0)

    def send_next(self, c):
        self.bring_out(c, next(s for s in self.party if s["hp"] > 0))
        self.say(c, f"Go, {spec(self.active)[0]}!", self.player_turn)

    def lose_battle(self, c):
        self.state = "gameover"
        self.redraw = True

    # ---- Endings -----------------------------------------------------------

    def draw_gameover(self, c):
        c.clear()
        c.center(80, "GAME OVER", RED, 4)
        c.center(140, "Your sprites need a rest...", GRAY)
        c.center(200, "C  Retry this stage", WHITE)

    def step_gameover(self, c):
        if self.ctrl.hit(BUTTON_C):
            party, self.orbs = self.saved
            self.party = [dict(s) for s in party]
            self.load_stage(self.stage_index)
            self.to_map()

    def victory(self, c):
        self.finished_in = self.now - self.started_at
        self.state = "victory"
        self.redraw = True

    def draw_victory(self, c):
        minutes, seconds = divmod(int(self.finished_in), 60)
        c.clear()
        c.center(30, "CHAMPION!", YELLOW, 4)
        c.center(80, "PIXELIA's sprites are free again!", WHITE)
        for i, sprite in enumerate(self.party):
            c.sprite(112 + i * 96, 112, sprite)
        c.center(200, f"DEX {len(self.caught)}/{len(SPRITES)}   Time {minutes}:{seconds:02d}", CYAN)
        c.center(260, "C  Play again", WHITE)

    def step_victory(self, c):
        if self.ctrl.hit(BUTTON_C):
            self.title()
