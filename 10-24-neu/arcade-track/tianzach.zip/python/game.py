"""Chip Quest: a small turn-based RPG for the UNO Q console.

The game turns calibrated controls into drawing requests; main.py sends them
over Bridge. The TFT is written pixel by pixel, so screens are drawn once and
then only the parts that change are repainted.
"""

import random

# Tilt tuning: check it on the title screen's control test (press B).
TILT_AXIS = "ax"   # Movement axis that changes when the console tips left/right.
TILT_SIGN = 1      # Use -1 if tipping the console right reads LEFT.
TILT_MG = 300      # Acceleration change, from the calibrated neutral, that counts as a tilt.

STICK_THRESHOLD = 64   # Calibrated stick value (out of 128) that counts as a direction.
MOVE_REPEAT = 0.22     # Seconds between map steps while the stick is held.
MENU_REPEAT = 0.25     # Seconds between menu moves while the stick is held.
MESSAGE_SECONDS = 1.6  # Battle messages advance by themselves, or sooner with A.

BUTTON_A, BUTTON_B, BUTTON_C = 1, 2, 4
HAS_BUTTONS, HAS_STICK, HAS_MOVEMENT = 1, 2, 4

SCREEN_W = 480
TILE = 32
MAP_Y = 32
CHAR_W = 6  # Font cell width at text size 1; size n is n times wider.
DIALOG_WIDTH = 34
FIRE_COST = 4
POTION_HEAL = 20
XP_TO_LEVEL = (10, 25, 45, 70, 100)


def rgb(r, g, b):
    return ((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3)


BLACK = 0
WHITE = 0xFFFF
GRAY = rgb(150, 150, 160)
YELLOW = rgb(255, 220, 60)
RED = rgb(240, 60, 60)
GREEN = rgb(90, 220, 100)
CYAN = rgb(80, 220, 255)
ORANGE = rgb(255, 150, 40)

WALLS = set("#T~c")  # An opened chest stays in place as an obstacle.
ENEMIES = {
    "s": {"name": "SLIME", "hp": 12, "atk": 6, "df": 0, "xp": 6, "window": 1.6},
    "b": {"name": "CAVE BAT", "hp": 18, "atk": 9, "df": 1, "xp": 9, "window": 1.3},
    "k": {"name": "SKELETON", "hp": 26, "atk": 12, "df": 3, "xp": 14, "window": 1.2},
    "B": {"name": "DEMON KING", "hp": 110, "atk": 15, "df": 4, "xp": 0, "window": 1.0},
}

# A page is (speaker, glyph drawn above a full-screen page, text).
INTRO = [
    ("", "@", "The Pixel Kingdom runs on one tiny treasure: the Core Chip."),
    ("", "B", "Last night the Demon King stole it. Colors fade. Screens flicker."),
    ("", "@", "You are BIT, the smallest knight in the land. Bring the Core Chip home!"),
]
BOSS_TAUNT = [
    ("DEMON KING", "B", "A tiny knight? The Core Chip is MINE! Come, if you dare!"),
]
ENDING = [
    ("", "B", "The Demon King falls. The Core Chip shines in BIT's hands."),
    ("", "@", "Color returns to the Pixel Kingdom. Well done, little knight!"),
]
DODGE_TILT = "TILT the console the way the arrow points to dodge!"
DODGE_BLOCK = "press B to block! (No Movement module found.)"

LEVELS = [
    {
        "name": "FOREST", "theme": 0, "wall": "T", "chest": ("potion", 1),
        "rows": [
            "TTTTTTTTTTTTTTT",
            "TP....T.....C.T",
            "T.TT..T..s....T",
            "T.N.......TT..T",
            "TTT..TTT......T",
            "T....T...TTT..T",
            "T.s..T.......ET",
            "T....~~~..T...T",
            "TTTTTTTTTTTTTTT",
        ],
        "intro": [("", "T", "Stage 1: Whisper Forest. Find the stairs to go deeper.")],
        "npc": [
            ("SAGE", "N", "BIT! Monsters strike fast. When they attack, {dodge}"),
            ("SAGE", "N", "Walk into a monster to fight it. Chests hold potions."),
        ],
        "outro": [("", "@", "The forest is quiet again. The trail leads down into the caves...")],
    },
    {
        "name": "CAVES", "theme": 1, "wall": "#", "chest": ("potion", 2),
        "rows": [
            "###############",
            "#P..#.....#..K#",
            "#.#.#.###.#.#.#",
            "#.#...#b..#.#.#",
            "#.###.#.###.#.#",
            "#...#.....b...#",
            "###.#####.###D#",
            "#C....b.....#E#",
            "###############",
        ],
        "intro": [("", "#", "Stage 2: Echo Caves. A locked door guards the stairs. Find the key!")],
        "npc": [],
        "outro": [("", "@", "Beyond the caves stands the Demon King's castle.")],
    },
    {
        "name": "CASTLE", "theme": 2, "wall": "=", "chest": ("sword", 3),
        "rows": [
            "###############",
            "#P............#",
            "#######N#####.#",
            "#...k.........#",
            "#.##C##########",
            "#.........k...#",
            "#############.#",
            "#B............#",
            "###############",
        ],
        "intro": [("", "=", "Stage 3: Dark Castle. The Core Chip glows somewhere inside.")],
        "npc": [
            ("GUARD", "N", "Careful! Every third turn the King unleashes a combo. Dodge every arrow!"),
            ("GUARD", "N", "An old HERO SWORD lies in a chest below. Take it!"),
        ],
        "outro": [],
    },
]


def wrap(text, width):
    lines, line = [], ""
    for word in text.split():
        if line and len(line) + 1 + len(word) > width:
            lines.append(line)
            line = word
        else:
            line = f"{line} {word}" if line else word
    if line:
        lines.append(line)
    return lines


class Canvas:
    """Collects the Bridge drawing calls for one update."""

    def __init__(self):
        self.calls = []

    def rect(self, x, y, w, h, color, fill=True):
        self.calls.append(("arcade_rect", x, y, w, h, color, 1 if fill else 0))

    def frame(self, x, y, w, h, color=WHITE):
        self.rect(x, y, w, h, BLACK)
        self.rect(x, y, w, h, color, False)
        self.rect(x + 2, y + 2, w - 4, h - 4, color, False)

    def text(self, x, y, text, color=WHITE, size=2):
        self.calls.append(("arcade_text", x, y, size, color, text))

    def center(self, y, text, color=WHITE, size=2):
        self.text((SCREEN_W - len(text) * CHAR_W * size) // 2, y, text, color, size)

    def tile(self, x, y, glyph, size=TILE, theme=3):
        self.calls.append(("arcade_tile", x, y, size, theme, glyph))

    def tiles(self, row, theme, text):
        self.calls.append(("arcade_tiles", row, theme, text))

    def clear(self):
        self.rect(0, 0, SCREEN_W, 320, BLACK)


class Controls:
    """One calibrated input snapshot plus the buttons newly pressed since the last one."""

    def __init__(self, values, previous_buttons):
        self.values = values
        self.connected = values["connected"]
        self.held = values["buttons"]
        self.pressed = self.held & ~previous_buttons
        x, y = values["x"], values["y"]
        if max(abs(x), abs(y)) < STICK_THRESHOLD:
            self.direction = (0, 0)
        elif abs(x) >= abs(y):
            self.direction = (1 if x > 0 else -1, 0)
        else:
            self.direction = (0, 1 if y > 0 else -1)
        tilt = values[TILT_AXIS] * TILT_SIGN
        if not self.connected & HAS_MOVEMENT or abs(tilt) < TILT_MG:
            self.tilt = 0
        else:
            self.tilt = 1 if tilt > 0 else -1

    def hit(self, button):
        return bool(self.pressed & button)


class Game:
    TIMERS = ("started_at", "blink_at", "next_move", "menu_next", "message_until",
              "deadline", "step_started", "test_at")

    def __init__(self, rng=None):
        self.rng = rng or random.Random()
        self.previous_buttons = 0
        self.epoch = None
        self.paused_missing = 0
        self.paused_at = 0
        self.now = 0
        self.ctrl = Controls({"connected": 0, "buttons": 0, "x": 0, "y": 0,
                              "ax": 0, "ay": 0, "az": 0}, 0)
        self.player = None
        self.title()

    # ---- Called by main.py -------------------------------------------------

    def screen_lost(self):
        """The display may hold something else now; repaint everything next update."""
        self.redraw = True

    def update(self, values, epoch, now):
        ctrl = Controls(values, self.previous_buttons)
        self.previous_buttons = ctrl.held
        self.ctrl, self.now = ctrl, now
        c = Canvas()
        if epoch != self.epoch:
            self.epoch = epoch
            self.redraw = True

        # The control test stays live so it can show which module is missing.
        missing = (HAS_BUTTONS | HAS_STICK) & ~ctrl.connected
        if missing and self.state != "controls":
            if not self.paused_missing:
                self.paused_at = now
            if missing != self.paused_missing or self.redraw:
                self.draw_paused(c, missing)
                self.redraw = False
            self.paused_missing = missing
            return c.calls
        if self.paused_missing:
            for name in self.TIMERS:
                if getattr(self, name, None) is not None:
                    setattr(self, name, getattr(self, name) + now - self.paused_at)
            self.paused_missing = 0
            self.redraw = True
            ctrl.pressed = 0  # Buttons held while reconnecting are not new presses.

        if self.redraw:
            self.redraw = False
            getattr(self, "draw_" + self.state)(c)
        getattr(self, "step_" + self.state)(c)
        return c.calls

    def draw_paused(self, c, missing):
        c.frame(60, 96, 360, 128, RED)
        c.center(110, "CONTROLS DISCONNECTED", RED)
        c.center(142, "Buttons:%s  Stick:%s" % ("--" if missing & HAS_BUTTONS else "OK",
                                                "--" if missing & HAS_STICK else "OK"))
        c.center(168, "Check the Qwiic cable.", GRAY)
        c.center(194, "The game is paused.", GRAY)

    # ---- Title and control test -------------------------------------------

    def title(self):
        self.state = "title"
        self.redraw = True
        self.blink_at = 0
        self.blink_on = False

    def draw_title(self, c):
        c.clear()
        c.center(36, "CHIP QUEST", YELLOW, 4)
        c.center(80, "A tiny knight. A stolen chip.", GRAY)
        c.tile(152, 112, "@", 64)
        c.tile(264, 112, "B", 64)
        c.center(228, "B  Control test", GRAY)
        if not self.ctrl.connected & HAS_MOVEMENT:
            c.center(290, "No Movement module: B blocks", ORANGE)
        self.blink_at = self.now

    def step_title(self, c):
        if self.now >= self.blink_at:
            self.blink_at = self.now + 0.7
            self.blink_on = not self.blink_on
            c.rect(100, 196, 280, 16, BLACK)
            if self.blink_on:
                c.center(196, "PRESS A TO START", WHITE)
        if self.ctrl.hit(BUTTON_A):
            self.new_game()
        elif self.ctrl.hit(BUTTON_B):
            self.state = "controls"
            self.redraw = True

    def draw_controls(self, c):
        c.clear()
        c.center(12, "CONTROL TEST", YELLOW, 3)
        c.text(20, 252, "Tip the console right: tilt should", GRAY)
        c.text(20, 272, "read RIGHT. Else change TILT_SIGN.", GRAY)
        c.text(20, 298, "B or C: back to title", GRAY)
        self.test_lines = [None] * 5
        self.test_at = 0

    def step_controls(self, c):
        ctrl = self.ctrl
        if ctrl.hit(BUTTON_B) or ctrl.hit(BUTTON_C):
            self.title()
            return
        if self.now < self.test_at:
            return
        self.test_at = self.now + 0.2
        v = ctrl.values
        ok = lambda bit: "OK" if ctrl.connected & bit else "--"
        names = {(0, 0): "--", (1, 0): "RIGHT", (-1, 0): "LEFT", (0, 1): "DOWN", (0, -1): "UP"}
        lines = [
            f"Buttons:{ok(HAS_BUTTONS)} Stick:{ok(HAS_STICK)} Move:{ok(HAS_MOVEMENT)}",
            "A:%d B:%d C:%d Stick press:%d" % tuple(
                int(bool(ctrl.held & bit)) for bit in (1, 2, 4, 8)),
            f"Stick {v['x']:4} {v['y']:4}  {names[ctrl.direction]}",
            f"Move mg {v['ax']:6} {v['ay']:6}",
            "Tilt: " + {-1: "LEFT", 0: "--", 1: "RIGHT"}[ctrl.tilt],
        ]
        for i, line in enumerate(lines):
            if line != self.test_lines[i]:
                self.test_lines[i] = line
                c.rect(20, 64 + i * 34, 440, 16, BLACK)
                c.text(20, 64 + i * 34, line, CYAN if i == 4 else WHITE)

    # ---- Story pages and map dialogs --------------------------------------

    def story(self, pages, then, c=None):
        """Show pages one by one; A turns the page, then `then(canvas)` runs.

        With a canvas the pages open as a dialog over the map instead of a new screen.
        """
        self.state = "story"
        self.pages = pages
        self.page = 0
        self.after_story = then
        self.overlay = c is not None
        if self.overlay:
            c.frame(8, 200, 464, 112)
            self.draw_page(c)
        else:
            self.redraw = True

    def draw_story(self, c):
        if self.overlay:
            self.draw_map(c)
        else:
            c.clear()
        c.frame(8, 200, 464, 112)
        self.draw_page(c)

    def draw_page(self, c):
        speaker, glyph, text = self.pages[self.page]
        if not self.overlay:
            if glyph:
                c.tile(192, 48, glyph, 96)
            else:
                c.rect(192, 48, 96, 96, BLACK)
        c.rect(12, 204, 456, 104, BLACK)
        if speaker:
            c.text(20, 210, speaker, YELLOW)
        text = text.replace("{dodge}", DODGE_TILT if self.ctrl.connected & HAS_MOVEMENT
                            else DODGE_BLOCK)
        for i, line in enumerate(wrap(text, DIALOG_WIDTH)[:3]):
            c.text(20, 234 + i * 24, line)
        c.text(440, 290, "A>", GREEN)

    def step_story(self, c):
        if not self.ctrl.hit(BUTTON_A):
            return
        self.page += 1
        if self.page < len(self.pages):
            self.draw_page(c)
        else:
            self.after_story(c)

    def say_on_map(self, c, text):
        self.story([("", "", text)], self.close_dialog, c)

    def close_dialog(self, c):
        self.state = "map"
        self.next_move = 0
        for row in range(5, 9):  # The dialog box covers these map rows.
            c.tiles(row, self.level["theme"], self.row_text(row))

    # ---- Game flow ---------------------------------------------------------

    def new_game(self):
        self.player = {"hp": 30, "max_hp": 30, "mp": 8, "max_mp": 8, "atk": 6, "df": 1,
                       "level": 1, "xp": 0, "potions": 1}
        self.started_at = self.now
        self.story(INTRO, lambda c: self.enter_level(0))

    def enter_level(self, index):
        self.load_level(index)
        self.saved_player = dict(self.player)
        self.story(self.level["intro"], self.to_map)

    def load_level(self, index):
        self.level_index = index
        self.level = LEVELS[index]
        self.grid = [list(row) for row in self.level["rows"]]
        for y, row in enumerate(self.grid):
            for x, glyph in enumerate(row):
                if glyph == "P":
                    self.pos = (x, y)
                    row[x] = "."
        self.facing = (1, 0)
        self.has_key = False

    def to_map(self, c=None):
        self.state = "map"
        self.redraw = True
        self.next_move = 0

    # ---- Map ---------------------------------------------------------------

    def map_glyph(self, x, y):
        if (x, y) == self.pos:
            return "@"
        glyph = self.grid[y][x]
        return self.level["wall"] if glyph == "#" else glyph

    def row_text(self, y):
        return "".join(self.map_glyph(x, y) for x in range(len(self.grid[y])))

    def draw_tile(self, c, x, y):
        c.tile(x * TILE, MAP_Y + y * TILE, self.map_glyph(x, y), TILE, self.level["theme"])

    def draw_hud(self, c):
        p = self.player
        c.rect(0, 0, SCREEN_W, MAP_Y, BLACK)
        c.text(8, 8, self.level["name"], YELLOW)
        stats = f"HP {p['hp']}/{p['max_hp']}  MP {p['mp']}/{p['max_mp']}  LV{p['level']}  P{p['potions']}"
        c.text(104, 8, stats + ("  KEY" if self.has_key else ""))

    def draw_map(self, c):
        self.draw_hud(c)
        for row in range(len(self.grid)):
            c.tiles(row, self.level["theme"], self.row_text(row))

    def step_map(self, c):
        direction = self.ctrl.direction
        if direction == (0, 0):
            self.next_move = 0
        elif self.now >= self.next_move:
            self.next_move = self.now + MOVE_REPEAT
            self.facing = direction
            self.try_move(c, direction)
            if self.state != "map":
                return
        if self.ctrl.hit(BUTTON_A):
            x, y = self.pos
            self.interact(c, x + self.facing[0], y + self.facing[1])

    def try_move(self, c, direction):
        x, y = self.pos
        nx, ny = x + direction[0], y + direction[1]
        glyph = self.grid[ny][nx]
        if glyph in WALLS:
            return
        if glyph in "CND" or glyph in ENEMIES:
            self.interact(c, nx, ny)
            return
        self.pos = (nx, ny)
        self.draw_tile(c, x, y)
        if glyph == "K":
            self.grid[ny][nx] = "."
            self.has_key = True
            self.draw_tile(c, nx, ny)
            self.draw_hud(c)
            self.say_on_map(c, "You found a rusty KEY! It must open a door.")
        elif glyph == "E":
            self.draw_tile(c, nx, ny)
            self.level_complete()
        else:
            self.draw_tile(c, nx, ny)

    def interact(self, c, x, y):
        glyph = self.grid[y][x]
        if glyph == "C":
            self.grid[y][x] = "c"
            self.draw_tile(c, x, y)
            kind, amount = self.level["chest"]
            if kind == "potion":
                self.player["potions"] += amount
                text = f"You found {amount} POTION{'S' if amount > 1 else ''}! Each heals {POTION_HEAL} HP."
            else:
                self.player["atk"] += amount
                text = f"You found the HERO SWORD! ATK +{amount}."
            self.draw_hud(c)
            self.say_on_map(c, text)
        elif glyph == "c":
            self.say_on_map(c, "The chest is empty.")
        elif glyph == "N":
            self.story(self.level["npc"], self.close_dialog, c)
        elif glyph == "D":
            if self.has_key:
                self.grid[y][x] = "."
                self.has_key = False
                self.draw_tile(c, x, y)
                self.draw_hud(c)
                self.say_on_map(c, "The key turns. The door creaks open!")
            else:
                self.say_on_map(c, "The door is locked. There must be a key somewhere.")
        elif glyph == "B":
            self.story(BOSS_TAUNT, lambda c: self.start_battle("B", (x, y)), c)
        elif glyph in ENEMIES:
            self.start_battle(glyph, (x, y))

    def level_complete(self):
        index = self.level_index + 1
        self.story(self.level["outro"], lambda c: self.enter_level(index))

    # ---- Battle ------------------------------------------------------------

    def start_battle(self, glyph, at):
        self.enemy = dict(ENEMIES[glyph], glyph=glyph, at=at, max_hp=ENEMIES[glyph]["hp"], turn=0)
        self.state = "battle"
        self.redraw = True
        self.menu_index = 0
        self.menu_next = 0
        self.guarding = False
        self.say(None, f"{self.enemy['name']} appears!", self.player_turn)

    def draw_battle(self, c):
        e = self.enemy
        c.clear()
        c.text(20, 16, e["name"], YELLOW)
        c.tile(340, 20, e["glyph"], 96)
        c.tile(48, 64, "@", 64)
        c.frame(8, 136, 464, 56)
        c.frame(8, 200, 228, 112)
        c.frame(244, 200, 228, 112)
        self.draw_enemy_hp(c)
        self.draw_message(c)
        self.draw_menu(c)
        self.draw_stats(c)

    def draw_enemy_hp(self, c):
        e = self.enemy
        width = 160 * e["hp"] // e["max_hp"]
        c.rect(20, 40, 160, 12, BLACK)
        c.rect(20, 40, width, 12, RED if e["hp"] * 4 < e["max_hp"] else GREEN)
        c.rect(20, 40, 160, 12, WHITE, False)

    def menu_options(self):
        p = self.player
        return [("ATTACK", True), (f"FIRE   {FIRE_COST}MP", p["mp"] >= FIRE_COST),
                (f"POTION x{p['potions']}", p["potions"] > 0), ("GUARD", True)]

    def draw_menu(self, c):
        c.rect(12, 204, 220, 104, BLACK)
        active = self.phase == "menu"
        for i, (label, usable) in enumerate(self.menu_options()):
            c.text(40, 214 + i * 24, label, WHITE if active and usable else GRAY)
        if active:
            c.text(18, 214 + self.menu_index * 24, ">", YELLOW)

    def draw_stats(self, c):
        p = self.player
        c.rect(248, 204, 220, 104, BLACK)
        c.text(260, 214, f"BIT   LV {p['level']}", YELLOW)
        c.text(260, 238, f"HP {p['hp']}/{p['max_hp']}", RED if p["hp"] * 4 < p["max_hp"] else WHITE)
        c.text(260, 262, f"MP {p['mp']}/{p['max_mp']}")
        goal = XP_TO_LEVEL[p["level"] - 1] if p["level"] <= len(XP_TO_LEVEL) else "--"
        c.text(260, 286, f"XP {p['xp']}/{goal}", GRAY)

    def draw_message(self, c):
        c.rect(12, 140, 456, 48, BLACK)
        if self.phase == "dodge":
            if self.ctrl.connected & HAS_MOVEMENT:
                prompt = "<<< TILT LEFT" if self.dodge_dir < 0 else "TILT RIGHT >>>"
            else:
                prompt = "PRESS B: BLOCK!"
            c.center(146, prompt, CYAN, 3)
            if self.dodge_total > 1:
                c.text(424, 150, f"{self.dodge_total - len(self.dodge_queue)}/{self.dodge_total}", YELLOW)
            self.bar_width = 440
            c.rect(20, 176, 440, 6, CYAN)
        else:
            for i, line in enumerate(wrap(self.message_text, 36)[:2]):
                c.text(24, 146 + i * 22, line)

    def say(self, c, text, then, seconds=MESSAGE_SECONDS):
        """Show a battle message; `then(canvas)` runs after a timeout or an A press."""
        self.phase = "message"
        self.message_text = text
        self.message_until = self.now + seconds
        self.after_message = then
        if c is not None:
            self.draw_message(c)

    def step_battle(self, c):
        ctrl = self.ctrl
        if self.phase == "message":
            if ctrl.hit(BUTTON_A) or self.now >= self.message_until:
                self.after_message(c)
        elif self.phase == "menu":
            self.step_menu(c)
        elif self.phase == "prepare":
            if self.now >= self.deadline:
                self.next_dodge(c)
        elif self.phase == "dodge":
            self.step_dodge(c)
        elif self.phase == "recover":
            # Wait for the console to come back to neutral before the next arrow.
            settled = ctrl.tilt == 0 and self.now - self.step_started > 0.25
            if settled or self.now - self.step_started > 0.8:
                self.next_dodge(c)

    def player_turn(self, c):
        self.phase = "menu"
        self.draw_message_text(c, "What will BIT do?")
        self.draw_menu(c)

    def draw_message_text(self, c, text):
        self.message_text = text
        self.draw_message(c)

    def step_menu(self, c):
        dy = self.ctrl.direction[1]
        if dy == 0:
            self.menu_next = 0
        elif self.now >= self.menu_next:
            self.menu_next = self.now + MENU_REPEAT
            old = self.menu_index
            self.menu_index = (self.menu_index + dy) % 4
            c.rect(18, 214 + old * 24, 12, 16, BLACK)
            c.text(18, 214 + self.menu_index * 24, ">", YELLOW)
        if self.ctrl.hit(BUTTON_A):
            self.choose(c)

    def choose(self, c):
        p, e = self.player, self.enemy
        choice = self.menu_index
        if choice == 0:
            damage = max(1, p["atk"] + self.rng.randint(0, 2) - e["df"])
            e["hp"] = max(0, e["hp"] - damage)
            text = f"BIT attacks! {damage} damage."
        elif choice == 1:
            if p["mp"] < FIRE_COST:
                self.say(c, "Not enough MP!", self.player_turn, 1.0)
                return
            p["mp"] -= FIRE_COST
            damage = p["atk"] + 6 + self.rng.randint(0, 3)
            e["hp"] = max(0, e["hp"] - damage)
            text = f"FIRE! {damage} damage."
        elif choice == 2:
            if not p["potions"]:
                self.say(c, "No potions left!", self.player_turn, 1.0)
                return
            p["potions"] -= 1
            heal = min(POTION_HEAL, p["max_hp"] - p["hp"])
            p["hp"] += heal
            text = f"BIT drinks a potion. +{heal} HP."
        else:
            self.guarding = True
            p["mp"] = min(p["max_mp"], p["mp"] + 2)
            text = "BIT raises the shield. +2 MP."
        self.say(c, text, self.after_player_action)
        self.draw_menu(c)
        self.draw_stats(c)
        self.draw_enemy_hp(c)

    def after_player_action(self, c):
        if self.enemy["hp"] <= 0:
            self.win_battle(c)
        else:
            self.enemy_turn(c)

    def enemy_turn(self, c):
        e = self.enemy
        e["turn"] += 1
        boss = e["glyph"] == "B"
        self.charge = boss and e["turn"] % 3 == 0
        count = 3 if self.charge else 2 if boss else 1
        self.dodge_queue = [self.rng.choice((-1, 1)) for _ in range(count)]
        self.dodge_total = count
        self.dodge_window = e["window"] * (0.9 if self.charge else 1)
        self.damage_taken = 0
        self.dodged = 0
        self.phase = "prepare"
        self.deadline = self.now + 0.9
        self.draw_message_text(c, f"{e['name']} unleashes a combo!" if self.charge
                               else f"{e['name']} attacks!")

    def next_dodge(self, c):
        if not self.dodge_queue:
            self.finish_enemy_turn(c)
            return
        self.dodge_dir = self.dodge_queue.pop(0)
        self.phase = "dodge"
        self.step_started = self.now
        self.deadline = self.now + self.dodge_window
        self.draw_message(c)

    def step_dodge(self, c):
        ctrl = self.ctrl
        if ctrl.connected & HAS_MOVEMENT:
            success, failed = ctrl.tilt == self.dodge_dir, ctrl.tilt == -self.dodge_dir
        else:
            success, failed = ctrl.hit(BUTTON_B), False
        if not success and (failed or self.now >= self.deadline):
            p, e = self.player, self.enemy
            damage = max(1, e["atk"] + self.rng.randint(0, 2) - p["df"])
            if self.charge:
                damage = max(1, round(damage * 0.7))
            if self.guarding:
                damage = (damage + 1) // 2
            p["hp"] = max(0, p["hp"] - damage)
            self.damage_taken += damage
            self.end_dodge(c, f"HIT! -{damage} HP", RED)
            self.draw_stats(c)
        elif success:
            self.dodged += 1
            self.end_dodge(c, "DODGED!", GREEN)
        else:
            # Shrink the timer bar in 40-pixel steps to keep redraws small.
            left = 440 * (self.deadline - self.now) / self.dodge_window
            width = int(left // 40 * 40)
            if width < self.bar_width:
                c.rect(20 + width, 176, self.bar_width - width, 6, BLACK)
                self.bar_width = width

    def end_dodge(self, c, text, color):
        self.phase = "recover"
        self.step_started = self.now
        c.rect(12, 140, 456, 48, BLACK)
        c.center(152, text, color, 3)
        if self.player["hp"] <= 0:
            self.dodge_queue = []

    def finish_enemy_turn(self, c):
        self.guarding = False
        if self.player["hp"] <= 0:
            self.say(c, "BIT has fallen...", self.lose_battle, 2.0)
        elif not self.damage_taken:
            self.say(c, "Perfect! No damage taken.", self.player_turn, 1.0)
        else:
            self.say(c, f"BIT took {self.damage_taken} damage.", self.player_turn, 1.0)

    def win_battle(self, c):
        e, p = self.enemy, self.player
        if e["glyph"] == "B":
            self.story(ENDING, self.victory)
            return
        x, y = e["at"]
        self.grid[y][x] = "."
        p["xp"] += e["xp"]
        levels = 0
        while p["level"] <= len(XP_TO_LEVEL) and p["xp"] >= XP_TO_LEVEL[p["level"] - 1]:
            p["level"] += 1
            p["max_hp"] += 6
            p["max_mp"] += 2
            p["atk"] += 2
            p["df"] += 1
            levels += 1
        if levels:
            p["hp"], p["mp"] = p["max_hp"], p["max_mp"]
        self.draw_stats(c)
        text = f"{e['name']} is defeated! +{e['xp']} XP"
        if levels:
            self.say(c, text, lambda c: self.say(
                c, f"LEVEL UP! BIT is now LV {p['level']}. HP and MP restored.", self.to_map, 2.0))
        else:
            self.say(c, text, self.to_map)

    def lose_battle(self, c):
        self.state = "gameover"
        self.redraw = True

    # ---- Endings -----------------------------------------------------------

    def draw_gameover(self, c):
        c.clear()
        c.center(80, "GAME OVER", RED, 4)
        c.center(140, "BIT has fallen...", GRAY)
        c.center(200, "C  Retry this stage", WHITE)

    def step_gameover(self, c):
        if self.ctrl.hit(BUTTON_C):
            self.player = dict(self.saved_player)
            self.load_level(self.level_index)
            self.to_map()

    def victory(self, c):
        self.finished_in = self.now - self.started_at
        self.state = "victory"
        self.redraw = True

    def draw_victory(self, c):
        p = self.player
        minutes, seconds = divmod(int(self.finished_in), 60)
        c.clear()
        c.center(40, "THE END", YELLOW, 4)
        c.center(96, "The Pixel Kingdom is saved!", WHITE)
        c.tile(208, 128, "@", 64)
        c.center(212, f"LV {p['level']}   Time {minutes}:{seconds:02d}", CYAN)
        c.center(260, "C  Play again", WHITE)

    def step_victory(self, c):
        if self.ctrl.hit(BUTTON_C):
            self.title()
