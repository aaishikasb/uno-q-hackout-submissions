import json
import time

from arduino.app_utils import App, Bridge
from game import Game
from preview import calibrate

game = Game()


def loop():
    try:
        response = Bridge.call("arcade_read_inputs")
        if not isinstance(response, (str, bytes, bytearray)):
            raise TypeError("Expected JSON text from arcade_read_inputs")
        inputs = json.loads(response)
        if inputs.get("video", 0):
            game.screen_lost()  # RetroArch owns the display; repaint when it returns.
            time.sleep(0.5)
            return
        for request in game.update(calibrate(inputs), inputs.get("screen", 0), time.monotonic()):
            Bridge.call(*request)
    except Exception as error:
        # Without fresh calls the MCU shows its waiting screen after 1.5 seconds.
        print(f"Arcade connection/input error: {error}")
        game.screen_lost()
        time.sleep(1)
        return
    time.sleep(0.03)


print("Sprite Tamer is running: press A on the console to start.")
App.run(user_loop=loop)
