#include <Arduino.h>
#include <Arduino_RouterBridge.h>
#include <Arduino_Modulino.h>
#include <DIYables_TFT_Touch_Shield.h>
#include <math.h>
#include "video_protocol.h"

#if !defined(ARDUINO_UNO_Q)
#error "Select Arduino UNO Q for this starter."
#endif

// Hosts select the controller fitted to their preassembled consoles.
#ifndef ARCADE_TFT_HX8357D
#define ARCADE_TFT_HX8357D 1
#endif
#if ARCADE_TFT_HX8357D
DIYables_TFT_HX8357D_Shield display;
#else
DIYables_TFT_RM68140_Shield display;
#endif

const uint8_t BUTTONS_ADDRESS = 0x3E;
const uint8_t JOYSTICK_ADDRESS = 0x2C;
ModulinoButtons buttons(BUTTONS_ADDRESS);
ModulinoMovement movement;
bool movementReady = false;

const int SCREEN_W = 480;
const int SCREEN_H = 320;
const int TILE = 32;
const int MAP_Y = 32;  // The top tile row sits below Python's 32-pixel status bar.
const int MAP_COLS = 15;
const int MAP_ROWS = 9;
const int MAX_TEXT = 40;

constexpr uint16_t rgb(uint8_t r, uint8_t g, uint8_t b) {
  return ((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3);
}

const uint16_t TFT_BLACK = 0x0000;
const uint16_t TFT_WHITE = 0xFFFF;
const uint16_t GRASS = rgb(46, 120, 52);
const uint16_t GRASS_DARK = rgb(34, 92, 40);
const uint16_t CAVE = rgb(70, 60, 52);
const uint16_t CAVE_DOT = rgb(96, 84, 70);
const uint16_t STONE = rgb(84, 84, 104);
const uint16_t STONE_LINE = rgb(64, 64, 82);
const uint16_t ROCK = rgb(116, 104, 92);
const uint16_t ROCK_DARK = rgb(58, 50, 44);
const uint16_t BRICK = rgb(150, 56, 48);
const uint16_t MORTAR = rgb(86, 38, 34);
const uint16_t LEAF = rgb(22, 84, 32);
const uint16_t LEAF_LIGHT = rgb(48, 140, 56);
const uint16_t TRUNK = rgb(112, 72, 32);
const uint16_t WATER = rgb(40, 90, 200);
const uint16_t WAVE = rgb(140, 190, 255);
const uint16_t WOOD = rgb(140, 90, 40);
const uint16_t WOOD_DARK = rgb(88, 56, 26);
const uint16_t GOLD = rgb(250, 200, 40);
const uint16_t SKIN = rgb(250, 210, 170);
const uint16_t KNIGHT = rgb(50, 110, 230);
const uint16_t STEEL = rgb(200, 200, 212);
const uint16_t STEEL_DARK = rgb(110, 110, 124);
const uint16_t SLIME = rgb(80, 220, 90);
const uint16_t BAT = rgb(140, 70, 180);
const uint16_t BONE = rgb(235, 235, 220);
const uint16_t DEMON = rgb(200, 30, 40);
const uint16_t DEMON_DARK = rgb(110, 16, 28);
const uint16_t ROBE = rgb(150, 80, 200);
const uint16_t EYE_RED = rgb(255, 60, 60);
const uint16_t EYE_GLOW = rgb(255, 230, 60);

unsigned long lastContactAt = 0;
bool waiting = true;
int screenEpoch = 0;  // Changes whenever the sketch repaints on its own; Python then redraws.
int videoSession = 0;
int nextVideoSession = 0;

bool readPacket(uint8_t address, uint8_t payload[3]) {
  // update() means "changed", not "read succeeded"; reject incomplete wire packets.
  int count = Wire1.requestFrom(address, (uint8_t)4);
  if (count != 4) {
    while (Wire1.available()) Wire1.read();
    return false;
  }
  Wire1.read();  // Modulino pinstrap address precedes the three input bytes.
  for (int i = 0; i < 3; ++i) payload[i] = Wire1.read();
  return true;
}

void textAt(int x, int y, int size, uint16_t color, const char* text) {
  display.setTextSize(size);
  display.setCursor(x, y);
  display.setTextColor(color);
  display.print(text);
}

void showWaiting() {
  videoSession = 0;
  screenEpoch = screenEpoch == 32767 ? 1 : screenEpoch + 1;
  display.fillScreen(TFT_BLACK);
  textAt(12, 10, 2, TFT_WHITE, "CHIP QUEST");
  textAt(12, 40, 2, TFT_WHITE, "Waiting for App Lab...");
  waiting = true;
}

// Any Bridge traffic proves Python is alive and keeps the game on screen.
void contact() {
  lastContactAt = millis();
}

String readInputs() {
  contact();
  uint8_t buttonData[3] = {};
  uint8_t stickData[3] = {};
  bool buttonsOk = readPacket(BUTTONS_ADDRESS, buttonData);
  bool joystickOk = readPacket(JOYSTICK_ADDRESS, stickData);
  bool movementOk = movementReady && movement.update();
  float ax = movementOk ? movement.getX() : 0;
  float ay = movementOk ? movement.getY() : 0;
  float az = movementOk ? movement.getZ() : 0;
  movementOk = movementOk && isfinite(ax) && isfinite(ay) && isfinite(az);
  int connected = (buttonsOk ? 1 : 0) | (joystickOk ? 2 : 0) | (movementOk ? 4 : 0);
  int pressed = 0;
  if (buttonsOk) {
    for (int i = 0; i < 3; ++i) if (buttonData[i]) pressed |= 1 << i;
    buttons.setLeds(buttonData[0], buttonData[1], buttonData[2]);
  }
  if (joystickOk && stickData[2]) pressed |= 8;
  char json[200];
  snprintf(json, sizeof(json),
           "{\"video\":%d,\"screen\":%d,\"connected\":%d,\"buttons\":%d,\"x\":%d,\"y\":%d,"
           "\"ax\":%d,\"ay\":%d,\"az\":%d}",
           videoSession, screenEpoch, connected, pressed,
           joystickOk ? 128 - (int)stickData[0] : 0,
           joystickOk ? 128 - (int)stickData[1] : 0,
           movementOk ? (int)(constrain(ax, -16.0f, 16.0f) * 1000) : 0,
           movementOk ? (int)(constrain(ay, -16.0f, 16.0f) * 1000) : 0,
           movementOk ? (int)(constrain(az, -16.0f, 16.0f) * 1000) : 0);
  return String(json);
}

// Drawing calls are refused while RetroArch owns the display.
bool startDrawing() {
  if (videoSession) return false;
  contact();
  waiting = false;
  return true;
}

uint16_t floorColor(int theme) {
  switch (theme) {
    case 0: return GRASS;
    case 1: return CAVE;
    case 2: return STONE;
    default: return TFT_BLACK;
  }
}

void drawFloor(int x, int y, int s, int theme) {
  int u = s / 8;
  display.fillRect(x, y, s, s, floorColor(theme));
  if (theme == 0) {
    display.fillRect(x + u, y + 2 * u, u / 2, u, GRASS_DARK);
    display.fillRect(x + 5 * u, y + 5 * u, u / 2, u, GRASS_DARK);
  } else if (theme == 1) {
    display.fillRect(x + 2 * u, y + 5 * u, u / 2, u / 2, CAVE_DOT);
    display.fillRect(x + 6 * u, y + 2 * u, u / 2, u / 2, CAVE_DOT);
  } else if (theme == 2) {
    display.drawRect(x, y, s, s, STONE_LINE);
  }
}

// Each glyph is drawn from simple shapes on an 8x8 grid of u-sized cells.
void drawGlyph(char glyph, int x, int y, int s, int theme) {
  int u = s / 8;
  int h = u / 2 > 0 ? u / 2 : 1;
  switch (glyph) {
    case 'T':
      drawFloor(x, y, s, theme);
      display.fillRect(x + 3 * u, y + 5 * u, 2 * u, 3 * u, TRUNK);
      display.fillCircle(x + 4 * u, y + 3 * u, 3 * u, LEAF);
      display.fillCircle(x + 3 * u, y + 2 * u, u, LEAF_LIGHT);
      break;
    case '#':
      display.fillRect(x, y, s, s, ROCK);
      display.drawRect(x, y, s, s, ROCK_DARK);
      display.drawLine(x + 2 * u, y + u, x + 4 * u, y + 4 * u, ROCK_DARK);
      display.drawLine(x + 5 * u, y + 5 * u, x + 7 * u, y + 6 * u, ROCK_DARK);
      break;
    case '=':
      display.fillRect(x, y, s, s, BRICK);
      display.drawFastHLine(x, y, s, MORTAR);
      display.drawFastHLine(x, y + 4 * u, s, MORTAR);
      display.drawFastVLine(x + 4 * u, y, 4 * u, MORTAR);
      display.drawFastVLine(x + 2 * u, y + 4 * u, 4 * u, MORTAR);
      display.drawFastVLine(x + 6 * u, y + 4 * u, 4 * u, MORTAR);
      break;
    case '~':
      display.fillRect(x, y, s, s, WATER);
      display.drawFastHLine(x + u, y + 2 * u, 2 * u, WAVE);
      display.drawFastHLine(x + 5 * u, y + 4 * u, 2 * u, WAVE);
      display.drawFastHLine(x + 2 * u, y + 6 * u, 2 * u, WAVE);
      break;
    case 'C':
      drawFloor(x, y, s, theme);
      display.fillRect(x + u, y + 3 * u, 6 * u, 4 * u, WOOD);
      display.fillRect(x + u, y + 3 * u, 6 * u, u, WOOD_DARK);
      display.fillRect(x + u, y + 5 * u, 6 * u, h, GOLD);
      display.fillRect(x + 7 * u / 2, y + 4 * u, u, 2 * u, GOLD);
      break;
    case 'c':
      drawFloor(x, y, s, theme);
      display.fillRect(x + u, y + 2 * u, 6 * u, 2 * u, WOOD_DARK);
      display.fillRect(x + u, y + 4 * u, 6 * u, 3 * u, WOOD);
      display.fillRect(x + 2 * u, y + 4 * u, 4 * u, u, TFT_BLACK);
      break;
    case 'N':
      drawFloor(x, y, s, theme);
      display.fillTriangle(x + 4 * u, y + 2 * u, x + u, y + 8 * u - 1, x + 7 * u, y + 8 * u - 1, ROBE);
      display.fillCircle(x + 4 * u, y + 2 * u, u + h, SKIN);
      display.fillTriangle(x + 3 * u, y + 3 * u, x + 5 * u, y + 3 * u, x + 4 * u, y + 5 * u, TFT_WHITE);
      break;
    case 'D':
      display.fillRect(x, y, s, s, WOOD);
      display.drawRect(x, y, s, s, ROCK_DARK);
      display.drawFastVLine(x + 4 * u, y, s, WOOD_DARK);
      display.fillCircle(x + 6 * u, y + 4 * u, h, GOLD);
      display.fillRect(x + 6 * u - h / 2, y + 5 * u, h, u, TFT_BLACK);
      break;
    case 'K':
      drawFloor(x, y, s, theme);
      display.fillCircle(x + 3 * u, y + 4 * u, u + h, GOLD);
      display.fillCircle(x + 3 * u, y + 4 * u, h, floorColor(theme));
      display.fillRect(x + 4 * u, y + 4 * u - h / 2, 3 * u, h, GOLD);
      display.fillRect(x + 6 * u, y + 4 * u, h, u, GOLD);
      break;
    case 'E':
      drawFloor(x, y, s, theme);
      display.fillRect(x + u, y + u, 6 * u, 6 * u, TFT_BLACK);
      display.fillRect(x + 3 * u, y + u, 4 * u, u, STEEL_DARK);
      display.fillRect(x + 2 * u, y + 3 * u, 5 * u, u, STEEL_DARK);
      display.fillRect(x + u, y + 5 * u, 6 * u, u, STEEL);
      break;
    case '@':
      drawFloor(x, y, s, theme);
      display.fillRect(x + 3 * u, y + 6 * u, 2 * u, 2 * u, STEEL_DARK);
      display.fillRect(x + 2 * u, y + 3 * u, 4 * u, 3 * u, KNIGHT);
      display.fillCircle(x + 4 * u, y + 2 * u, u + h, STEEL);
      display.fillRect(x + 3 * u, y + 2 * u, 2 * u, h, TFT_BLACK);
      display.fillRect(x + 6 * u + h, y + u, h, 5 * u, TFT_WHITE);
      display.fillRect(x + 6 * u, y + 5 * u, 2 * u, h, GOLD);
      break;
    case 's':
      drawFloor(x, y, s, theme);
      display.fillCircle(x + 4 * u, y + 5 * u, 3 * u - 1, SLIME);
      display.fillRect(x + u + 1, y + 5 * u, 6 * u - 2, 3 * u - 1, SLIME);
      display.fillCircle(x + 3 * u, y + 4 * u, h, TFT_BLACK);
      display.fillCircle(x + 5 * u, y + 4 * u, h, TFT_BLACK);
      break;
    case 'b':
      drawFloor(x, y, s, theme);
      display.fillTriangle(x + 4 * u, y + 3 * u, x, y + 2 * u, x + u, y + 6 * u, BAT);
      display.fillTriangle(x + 4 * u, y + 3 * u, x + 8 * u - 1, y + 2 * u, x + 7 * u, y + 6 * u, BAT);
      display.fillCircle(x + 4 * u, y + 4 * u, u + h, BAT);
      display.fillRect(x + 3 * u, y + 4 * u - h, h, h, EYE_RED);
      display.fillRect(x + 5 * u - h, y + 4 * u - h, h, h, EYE_RED);
      break;
    case 'k':
      drawFloor(x, y, s, theme);
      display.fillCircle(x + 4 * u, y + 2 * u, u + h, BONE);
      display.fillRect(x + 3 * u, y + 2 * u, h, h, TFT_BLACK);
      display.fillRect(x + 5 * u - h, y + 2 * u, h, h, TFT_BLACK);
      display.fillRect(x + 3 * u, y + 4 * u, 2 * u, 2 * u, BONE);
      display.drawFastHLine(x + 3 * u, y + 5 * u, 2 * u, TFT_BLACK);
      display.fillRect(x + 3 * u, y + 6 * u, h, 2 * u, BONE);
      display.fillRect(x + 5 * u - h, y + 6 * u, h, 2 * u, BONE);
      display.fillRect(x + 6 * u, y + 2 * u, h, 5 * u, STEEL);
      break;
    case 'B':
      drawFloor(x, y, s, theme);
      display.fillTriangle(x + 4 * u, y + 2 * u, x, y + 8 * u - 1, x + 8 * u - 1, y + 8 * u - 1, DEMON_DARK);
      display.fillRect(x + 2 * u, y + 4 * u, 4 * u, 4 * u, DEMON);
      display.fillCircle(x + 4 * u, y + 3 * u, u + h, DEMON);
      display.fillTriangle(x + 2 * u, y + 3 * u, x + 3 * u, y + 2 * u, x + u, y, TFT_WHITE);
      display.fillTriangle(x + 6 * u, y + 3 * u, x + 5 * u, y + 2 * u, x + 7 * u, y, TFT_WHITE);
      display.fillRect(x + 3 * u, y + 3 * u, h, h, EYE_GLOW);
      display.fillRect(x + 5 * u - h, y + 3 * u, h, h, EYE_GLOW);
      display.fillRect(x + 3 * u, y + u, 2 * u, h, GOLD);
      break;
    default:
      drawFloor(x, y, s, theme);
      break;
  }
}

bool drawBox(int x, int y, int w, int h, int color, int fill) {
  if (!startDrawing()) return false;
  // Bound every RPC input before using it for drawing.
  x = constrain(x, 0, SCREEN_W);
  y = constrain(y, 0, SCREEN_H);
  w = constrain(w, 0, SCREEN_W - x);
  h = constrain(h, 0, SCREEN_H - y);
  if (w == 0 || h == 0) return true;
  if (fill) display.fillRect(x, y, w, h, color & 0xFFFF);
  else display.drawRect(x, y, w, h, color & 0xFFFF);
  return true;
}

bool drawText(int x, int y, int size, int color, String text) {
  if (!startDrawing()) return false;
  size = constrain(size, 1, 4);
  char line[MAX_TEXT + 1];
  int length = min((int)text.length(), MAX_TEXT);
  for (int i = 0; i < length; ++i) {
    char c = text[i];
    line[i] = c >= 32 && c < 127 ? c : '?';
  }
  line[length] = 0;
  textAt(constrain(x, 0, SCREEN_W - 1), constrain(y, 0, SCREEN_H - 1), size, color & 0xFFFF, line);
  return true;
}

bool drawTiles(int row, int theme, String tiles) {
  if (!startDrawing()) return false;
  if (row < 0 || row >= MAP_ROWS) return false;
  int count = min((int)tiles.length(), MAP_COLS);
  for (int i = 0; i < count; ++i) drawGlyph(tiles[i], i * TILE, MAP_Y + row * TILE, TILE, theme);
  return true;
}

bool drawTile(int x, int y, int size, int theme, String glyph) {
  if (!startDrawing()) return false;
  size = constrain(size, 8, 128) / 8 * 8;
  x = constrain(x, 0, SCREEN_W - size);
  y = constrain(y, 0, SCREEN_H - size);
  drawGlyph(glyph.length() ? glyph[0] : ' ', x, y, size, theme);
  return true;
}

int beginVideo() {
  if (videoSession) return 0;  // Only one stream may own the display.
  nextVideoSession = nextVideoSession == 2147483647 ? 1 : nextVideoSession + 1;
  videoSession = nextVideoSession;
  display.fillScreen(TFT_BLACK);
  textAt(12, 10, 2, TFT_WHITE, "RetroArch / TFT bridge");
  textAt(12, 294, 2, TFT_WHITE, "C + stick press: menu");
  contact();
  waiting = false;
  return videoSession;
}

String pollVideo(int session) {
  if (!videoSession || session != videoSession) return String("");
  return readInputs();
}

String videoTile(int session, int tile, MsgPack::bin_t<uint8_t> data) {
  static uint16_t pixels[ArcadeVideo::TILE_PIXELS * 4];
  if (!videoSession || session != videoSession ||
      !ArcadeVideo::decode(tile, data.data(), data.size(), pixels)) return String("");
  display.drawRGBBitmap(80 + (tile % 10) * 32, 40 + (tile / 10) * 16, pixels, 32, 16);
  return pollVideo(session);  // Return fresh controls after each acknowledged tile.
}

bool endVideo(int session) {
  if (!videoSession || session != videoSession) return false;
  showWaiting();
  return true;
}

void setup() {
  // Light the screen first so a stalled module or Bridge start is visible.
  display.begin();
  display.setRotation(1);  // Landscape: 480 x 320.
  display.setTextWrap(false);
  display.fillScreen(TFT_BLACK);
  textAt(12, 10, 2, TFT_WHITE, "CHIP QUEST");
  textAt(12, 40, 2, TFT_WHITE, "Starting controls...");
  Modulino.begin(Wire1);
  buttons.begin();
  movementReady = movement.begin();
  textAt(12, 70, 2, TFT_WHITE, "Starting Bridge...");
  if (Bridge.begin()) {
    Bridge.provide_safe("arcade_read_inputs", readInputs);
    Bridge.provide_safe("arcade_rect", drawBox);
    Bridge.provide_safe("arcade_text", drawText);
    Bridge.provide_safe("arcade_tiles", drawTiles);
    Bridge.provide_safe("arcade_tile", drawTile);
    Bridge.provide_safe("arcade_video_begin", beginVideo);
    Bridge.provide_safe("arcade_video_tile", videoTile);
    Bridge.provide_safe("arcade_video_poll", pollVideo);
    Bridge.provide_safe("arcade_video_end", endVideo);
    showWaiting();
  } else {
    textAt(12, 100, 2, TFT_WHITE, "Bridge failed: restart app");
  }
}

void loop() {
  if (!waiting && millis() - lastContactAt > 1500) showWaiting();
  delay(1);
}
