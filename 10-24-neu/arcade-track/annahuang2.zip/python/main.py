import time

from arduino.app_utils import App


def loop():
    time.sleep(1)


print("Steady-Hand Target Blitz runs on the console's MCU.")
App.run(user_loop=loop)
