#include <Arduino.h>
#include <Arduino_Modulino.h>
#include <DIYables_TFT_Touch_Shield.h>
#include <math.h>
#include <string.h>
#include <Adafruit_GFX.h>

#if !defined(ARDUINO_UNO_Q)
#error "Select Arduino UNO Q for this game."
#endif

// Hosts select the controller fitted to their preassembled consoles.
#ifndef ARCADE_TFT_HX8357D
#define ARCADE_TFT_HX8357D 1
#endif
#if ARCADE_TFT_HX8357D
DIYables_TFT_HX8357D_Shield display;
#else
DIYables_TFT_RM68140_Shield display;
#endif

// ===== Tuning knobs: change these if a direction feels wrong =====
const int   STICK_X_SIGN  = -1;     // -1 if left/right is reversed (this console needs -1)
const int   STICK_Y_SIGN  = 1;      // -1 if up/down is reversed
const int   TILT_X_SIGN   = 1;      // -1 if tilt drift left/right is reversed
const int   TILT_Y_SIGN   = 1;      // -1 if tilt drift up/down is reversed
const bool  TILT_SWAP     = false;  // true if tilt moves the wrong axis
const float TILT_GAIN     = 240.0f; // px per second per g of tilt
const float STICK_SPEED   = 260.0f; // px per second at full stick
const int   ROUND_SECONDS = 30;

const uint8_t BUTTONS_ADDRESS = 0x3E;
const uint8_t JOYSTICK_ADDRESS = 0x2C;
ModulinoButtons buttons(BUTTONS_ADDRESS);
ModulinoMovement movement;
bool movementReady = false;

const uint16_t COL_BLACK = 0x0000;
const uint16_t COL_WHITE = 0xFFFF;
const uint16_t COL_CYAN = 0x07FF;
const uint16_t COL_RED = 0xF800;
const uint16_t COL_GREEN = 0x07E0;
const uint16_t COL_YELLOW = 0xFFE0;

const int ST_TITLE = 0;
const int ST_PLAY = 1;
const int ST_OVER = 2;
const int ST_SNAKE = 3;
const int ST_SNAKE_OVER = 4;
int state = ST_TITLE;

int rawSX = 128, rawSY = 128;
int stickCx = 128, stickCy = 128;
float tiltX = 0, tiltY = 0, tiltX0 = 0, tiltY0 = 0;
bool btnA = false, btnB = false, btnC = false;
bool prevA = false, prevB = false, prevC = false;
bool btnOk = false, stickOk = false;

int score = 0, combo = 0, hits = 0, shots = 0, timeLeft = 0;
unsigned long roundStart = 0, targetBorn = 0, lastHud = 0, lastDebug = 0, lastFrame = 0, hudMsgUntil = 0;
int targetX = 240, targetY = 180, targetR = 38;
bool targetOn = false;
float crossXf = 240, crossYf = 180;
int crossX = 240, crossY = 180, prevX = 240, prevY = 180;
const char* hudMsg = "";
bool crossNeedsRepaint = false;
GFXcanvas16 bgPatch(24, 24);
unsigned long lastMoveAt = 0;
char lastHudText[64] = "";
char hudBuf[16] = "";
const int HIT_SLACK = 6;   // extra pixels of forgiveness around the target
const unsigned long FAST_MS = 1000;   // hit within this time = FAST
const unsigned long QUICK_MS = 1800;  // hit within this time = QUICK
uint16_t hudColor = COL_WHITE;
unsigned long reactSum = 0;
int bestScore = 0;
bool stickPress = false, prevFire = false;
bool pendA = false, pendB = false, pendC = false, pendFire = false;

bool readPacket(uint8_t address, uint8_t payload[3]) {
  int count = Wire1.requestFrom(address, (uint8_t)4);
  if (count != 4) {
    while (Wire1.available()) Wire1.read();
    return false;
  }
  Wire1.read();
  for (int i = 0; i < 3; ++i) payload[i] = Wire1.read();
  return true;
}

void say(int x, int y, int size, uint16_t color, const char* text) {
  display.setTextSize(size);
  display.setCursor(x, y);
  display.setTextColor(color, COL_BLACK);
  display.print(text);
}

void readControls() {
  uint8_t bd[3] = {};
  uint8_t sd[3] = {};
  btnOk = readPacket(BUTTONS_ADDRESS, bd);
  if (btnOk) { btnA = bd[0] != 0; btnB = bd[1] != 0; btnC = bd[2] != 0; }
  else { btnA = false; btnB = false; btnC = false; }
  stickOk = readPacket(JOYSTICK_ADDRESS, sd);
  if (stickOk) { rawSX = sd[0]; rawSY = sd[1]; stickPress = sd[2] != 0; }
  else { rawSX = stickCx; rawSY = stickCy; stickPress = false; }
  if (movementReady) {
    movement.update();
    float x = movement.getX();
    float y = movement.getY();
    if (isfinite(x) && isfinite(y)) { tiltX = x; tiltY = y; }
  }
}

void drawTarget() {
  display.fillCircle(targetX, targetY, targetR, COL_WHITE);
  display.fillCircle(targetX, targetY, targetR * 2 / 3, COL_RED);
  display.fillCircle(targetX, targetY, targetR / 3, COL_YELLOW);
}

void newTarget() {
  if (targetOn) display.fillRect(targetX - targetR - 1, targetY - targetR - 1, 2 * targetR + 3, 2 * targetR + 3, COL_BLACK);
  targetR = 38 - hits * 2;
  if (targetR < 18) targetR = 18;
  targetX = (int)random(60, 421);
  targetY = (int)random(80, 271);
  targetBorn = millis();
  targetOn = true;
  drawTarget();
  crossNeedsRepaint = true;
}

void drawCross(int x, int y) {
  display.fillRect(x - 10, y - 1, 21, 3, COL_GREEN);
  display.fillRect(x - 1, y - 10, 3, 21, COL_GREEN);
}

void restoreBox(int cx, int cy) {
  int x0 = cx - 12, y0 = cy - 12;
  bgPatch.fillScreen(COL_BLACK);
  if (targetOn) {
    int tx = targetX - x0, ty = targetY - y0;
    bgPatch.fillCircle(tx, ty, targetR, COL_WHITE);
    bgPatch.fillCircle(tx, ty, targetR * 2 / 3, COL_RED);
    bgPatch.fillCircle(tx, ty, targetR / 3, COL_YELLOW);
  }
  display.drawRGBBitmap(x0, y0, bgPatch.getBuffer(), 24, 24);
}

void drawHud() {
  char left[32];
  char msg[24];
  char key[64];
  snprintf(left, sizeof(left), "Score:%-3d Time:%-2d x%-2d ", score, timeLeft, combo);
  snprintf(msg, sizeof(msg), "%-14s", hudMsg);
  snprintf(key, sizeof(key), "%s|%s|%u", left, msg, (unsigned)hudColor);
  if (strcmp(key, lastHudText) == 0) return;
  strncpy(lastHudText, key, sizeof(lastHudText) - 1);
  lastHudText[sizeof(lastHudText) - 1] = 0;
  say(10, 10, 2, COL_WHITE, left);
  say(10 + 22 * 12, 10, 2, hudColor, msg);
}

// zone: 1 = outer ring, 2 = red ring, 3 = bullseye
// speed: 0 = slow, 1 = quick, 2 = fast
void setGrade(int zone, int speed) {
  const char* m = "HIT";
  uint16_t c = COL_WHITE;
  if (zone == 3) {
    if (speed == 2) { m = "EXTRAORDINARY!"; c = COL_YELLOW; }
    else if (speed == 1) { m = "EXCELLENT!"; c = COL_GREEN; }
    else { m = "PRECISE!"; c = COL_CYAN; }
  } else if (zone == 2) {
    if (speed == 2) { m = "BLAZING!"; c = COL_YELLOW; }
    else if (speed == 1) { m = "GREAT!"; c = COL_GREEN; }
    else { m = "GOOD"; c = COL_WHITE; }
  } else {
    if (speed == 2) { m = "QUICK DRAW!"; c = COL_CYAN; }
    else if (speed == 1) { m = "NICE!"; c = COL_WHITE; }
    else { m = "HIT"; c = COL_WHITE; }
  }
  hudMsg = m;
  hudColor = c;
}

void showTitle() {
  state = ST_TITLE;
  targetOn = false;
  display.fillScreen(COL_BLACK);
  say(30, 20, 3, COL_YELLOW, "STEADY-HAND TARGET");
  say(30, 56, 3, COL_YELLOW, "BLITZ");
  say(10, 120, 2, COL_WHITE, "1. Hold the console flat");
  say(10, 146, 2, COL_WHITE, "2. Let go of the stick");
  say(10, 172, 2, COL_GREEN, "3. Press A to calibrate + start");
  say(10, 208, 2, COL_WHITE, "Stick aims, A or stick-press fires");
  say(10, 234, 2, COL_CYAN, "C restarts. Tilt pushes your aim!");
}

void startRound() {
  state = ST_PLAY;
  score = 0; combo = 0; hits = 0; shots = 0;
  roundStart = millis();
  lastMoveAt = millis();
  lastHudText[0] = 0;
  reactSum = 0;
  hudColor = COL_GREEN;
  timeLeft = ROUND_SECONDS;
  display.fillScreen(COL_BLACK);
  display.drawRect(4, 36, 472, 280, COL_WHITE);
  crossXf = 240; crossYf = 180;
  crossX = 240; crossY = 180; prevX = 240; prevY = 180;
  targetOn = false;
  newTarget();
  drawCross(crossX, crossY);
  hudMsg = "GO!";
  hudMsgUntil = millis() + 800;
  drawHud();
  lastHud = millis();
}

void endRound() {
  state = ST_OVER;
  targetOn = false;
  if (score > bestScore) bestScore = score;
  display.fillScreen(COL_BLACK);
  char line[40];
  say(130, 16, 4, COL_YELLOW, "TIME UP!");
  snprintf(line, sizeof(line), "Score: %d", score);
  say(150, 72, 3, COL_WHITE, line);
  int acc = shots > 0 ? (hits * 100) / shots : 0;
  snprintf(line, sizeof(line), "Hits %d/%d (%d%%)", hits, shots, acc);
  say(110, 114, 2, COL_CYAN, line);
  int avg = hits > 0 ? (int)(reactSum / hits) : 0;
  snprintf(line, sizeof(line), "Avg reaction %d.%02d s", avg / 1000, (avg % 1000) / 10);
  say(110, 140, 2, COL_CYAN, line);
  const char* rank = "WARMING UP";
  uint16_t rc = COL_WHITE;
  if (score >= 70) { rank = "LEGEND"; rc = COL_YELLOW; }
  else if (score >= 45) { rank = "SHARPSHOOTER"; rc = COL_YELLOW; }
  else if (score >= 25) { rank = "STEADY HAND"; rc = COL_GREEN; }
  else if (score >= 10) { rank = "ROOKIE"; rc = COL_CYAN; }
  snprintf(line, sizeof(line), "Rank: %s", rank);
  say(60, 176, 3, rc, line);
  snprintf(line, sizeof(line), "Best: %d", bestScore);
  say(110, 218, 2, COL_WHITE, line);
  say(60, 254, 2, COL_GREEN, "C: play again   B: recalibrate");
  say(60, 288, 2, COL_YELLOW, "A: LEVEL 2 - SNAKE!");
}

void updateTitle(bool aEdge, unsigned long now) {
  if (aEdge) {
    stickCx = rawSX; stickCy = rawSY;
    tiltX0 = tiltX; tiltY0 = tiltY;
    startRound();
    return;
  }
  if (now - lastDebug > 150) {
    lastDebug = now;
    char line[48];
    snprintf(line, sizeof(line), "%-34s", (btnOk && stickOk) ? "" : "Controls not found - check wiring");
    say(10, 262, 2, COL_RED, line);
    snprintf(line, sizeof(line), "stick %3d,%3d  tilt %5d,%5d mg  ", rawSX, rawSY, (int)(tiltX * 1000), (int)(tiltY * 1000));
    say(10, 290, 2, COL_CYAN, line);
  }
}

void updatePlay(bool fireEdge, bool cEdge, unsigned long now) {
  if (cEdge) { startRound(); return; }
  int left = ROUND_SECONDS - (int)((now - roundStart) / 1000);
  if (left <= 0) { timeLeft = 0; endRound(); return; }
  timeLeft = left;

  int dxs = rawSX - stickCx;
  int dys = rawSY - stickCy;
  if (abs(dxs) < 8) dxs = 0;
  if (abs(dys) < 8) dys = 0;
  float vx = STICK_X_SIGN * (dxs / 127.0f) * STICK_SPEED;
  float vy = STICK_Y_SIGN * (dys / 127.0f) * STICK_SPEED;
  float tx = tiltX - tiltX0;
  float ty = tiltY - tiltY0;
  if (TILT_SWAP) { float t = tx; tx = ty; ty = t; }
  vx += TILT_X_SIGN * tx * TILT_GAIN;
  vy += TILT_Y_SIGN * ty * TILT_GAIN;
  float dt = (now - lastMoveAt) / 1000.0f;
  lastMoveAt = now;
  if (dt > 0.1f) dt = 0.1f;
  crossXf = constrain(crossXf + vx * dt, 20.0f, 460.0f);
  crossYf = constrain(crossYf + vy * dt, 52.0f, 300.0f);
  crossX = (int)crossXf;
  crossY = (int)crossYf;

  if (fireEdge) {
    shots++;
    int dx = crossX - targetX;
    int dy = crossY - targetY;
    long d2 = (long)dx * dx + (long)dy * dy;
    long reachR = targetR + HIT_SLACK;
    if (d2 <= reachR * reachR) {
      long yel = targetR / 3;
      long red = targetR * 2 / 3;
      int zone = 1;
      if (d2 <= red * red) zone = 2;
      if (d2 <= yel * yel) zone = 3;
      unsigned long react = (now >= targetBorn) ? (now - targetBorn) : 0;
      int speed = 0;
      if (react < QUICK_MS) speed = 1;
      if (react < FAST_MS) speed = 2;
      setGrade(zone, speed);
      combo++;
      int pts = zone + speed;
      if (combo >= 3) pts += 1;
      score += pts;
      hits++;
      reactSum += react;
      newTarget();
    } else {
      combo = 0;
      snprintf(hudBuf, sizeof(hudBuf), "MISS %dpx", (int)sqrtf((float)d2));
      hudMsg = hudBuf;
      hudColor = COL_RED;
    }
    hudMsgUntil = now + 800;
    lastHud = 0;
  }

  int life = 5000 - hits * 100;
  if (life < 2200) life = 2200;
  if ((long)(now - targetBorn) > (long)life) {
    combo = 0;
    hudMsg = "TOO LATE";
    hudColor = COL_RED;
    hudMsgUntil = now + 700;
    newTarget();
    lastHud = 0;
  }
  if (hudMsgUntil != 0 && now > hudMsgUntil) {
    hudMsg = "";
    hudMsgUntil = 0;
    lastHud = 0;
  }

  if (crossX != prevX || crossY != prevY || crossNeedsRepaint) {
    restoreBox(prevX, prevY);
    drawCross(crossX, crossY);
    prevX = crossX;
    prevY = crossY;
    crossNeedsRepaint = false;
  }

  if (now - lastHud > 150) { drawHud(); lastHud = now; }
}


// ================= Level 2: Snake =================
const int SN_COLS = 29, SN_ROWS = 17, SN_CELL = 16, SN_OX = 8, SN_OY = 44;
const int SN_MAX = SN_COLS * SN_ROWS;
const int SN_DX[4] = {1, 0, -1, 0};   // 0 = right, 1 = down, 2 = left, 3 = up
const int SN_DY[4] = {0, 1, 0, -1};
uint8_t snX[SN_MAX], snY[SN_MAX];     // body cells, tail first, head last
int snLen = 0, snDir = 0, snNextDir = 0, snScore = 0, snApples = 0, snBest = 0;
int appleX = 0, appleY = 0;
unsigned long snLastStep = 0;

void drawCell(int gx, int gy, uint16_t color) {
  display.fillRect(SN_OX + gx * SN_CELL + 1, SN_OY + gy * SN_CELL + 1, SN_CELL - 2, SN_CELL - 2, color);
}

void drawSnakeHud() {
  char line[48];
  snprintf(line, sizeof(line), "SNAKE  Score:%-4d Length:%-3d     ", snScore, snLen);
  say(10, 10, 2, COL_GREEN, line);
}

void placeApple() {
  for (int tries = 0; tries < 300; tries++) {
    int ax = (int)random(0, SN_COLS);
    int ay = (int)random(0, SN_ROWS);
    bool onSnake = false;
    for (int i = 0; i < snLen; i++) {
      if (snX[i] == ax && snY[i] == ay) { onSnake = true; break; }
    }
    if (!onSnake) { appleX = ax; appleY = ay; break; }
  }
  display.fillCircle(SN_OX + appleX * SN_CELL + SN_CELL / 2, SN_OY + appleY * SN_CELL + SN_CELL / 2, 6, COL_RED);
}

void startSnake() {
  state = ST_SNAKE;
  snLen = 3;
  for (int i = 0; i < 3; i++) { snX[i] = 12 + i; snY[i] = 8; }
  snDir = 0; snNextDir = 0; snScore = 0; snApples = 0;
  display.fillScreen(COL_BLACK);
  display.drawRect(SN_OX - 2, SN_OY - 2, SN_COLS * SN_CELL + 4, SN_ROWS * SN_CELL + 4, COL_WHITE);
  for (int i = 0; i < snLen - 1; i++) drawCell(snX[i], snY[i], COL_GREEN);
  drawCell(snX[snLen - 1], snY[snLen - 1], COL_YELLOW);
  placeApple();
  drawSnakeHud();
  snLastStep = millis();
}

void endSnake() {
  state = ST_SNAKE_OVER;
  if (snScore > snBest) snBest = snScore;
  display.fillScreen(COL_BLACK);
  char line[40];
  say(100, 20, 4, COL_RED, "GAME OVER");
  snprintf(line, sizeof(line), "Snake score: %d", snScore);
  say(110, 90, 3, COL_WHITE, line);
  snprintf(line, sizeof(line), "Apples: %d  Length: %d", snApples, snLen);
  say(110, 140, 2, COL_CYAN, line);
  snprintf(line, sizeof(line), "Best: %d", snBest);
  say(110, 170, 2, COL_YELLOW, line);
  say(60, 230, 2, COL_GREEN, "C: play again   B: title");
}

void updateSnake(bool bEdge, bool cEdge, unsigned long now) {
  if (cEdge) { startSnake(); return; }
  if (bEdge) { showTitle(); return; }

  int ddx = STICK_X_SIGN * (rawSX - stickCx);
  int ddy = STICK_Y_SIGN * (rawSY - stickCy);
  int want = -1;
  if (abs(ddx) > 40 || abs(ddy) > 40) {
    if (abs(ddx) >= abs(ddy)) want = (ddx > 0) ? 0 : 2;
    else want = (ddy > 0) ? 1 : 3;
  }
  if (want >= 0 && want != ((snDir + 2) % 4)) snNextDir = want;

  int stepMs = 170 - (snLen - 3) * 4;
  if (stepMs < 70) stepMs = 70;
  if ((long)(now - snLastStep) < (long)stepMs) return;
  snLastStep = now;
  snDir = snNextDir;

  int nx = (int)snX[snLen - 1] + SN_DX[snDir];
  int ny = (int)snY[snLen - 1] + SN_DY[snDir];
  bool ate = (nx == appleX && ny == appleY && snLen < SN_MAX);
  bool dead = (nx < 0 || nx >= SN_COLS || ny < 0 || ny >= SN_ROWS);
  if (!dead) {
    for (int i = ate ? 0 : 1; i < snLen; i++) {
      if ((int)snX[i] == nx && (int)snY[i] == ny) { dead = true; break; }
    }
  }
  if (dead) { endSnake(); return; }

  drawCell(snX[snLen - 1], snY[snLen - 1], COL_GREEN);
  if (!ate) {
    drawCell(snX[0], snY[0], COL_BLACK);
    for (int i = 0; i < snLen - 1; i++) { snX[i] = snX[i + 1]; snY[i] = snY[i + 1]; }
  } else {
    snLen++;
  }
  snX[snLen - 1] = (uint8_t)nx;
  snY[snLen - 1] = (uint8_t)ny;
  drawCell(nx, ny, COL_YELLOW);

  if (ate) {
    snApples++;
    snScore += 10;
    placeApple();
    drawSnakeHud();
  }
}

void updateSnakeOver(bool bEdge, bool cEdge) {
  if (cEdge) startSnake();
  else if (bEdge) showTitle();
}

void updateOver(bool aEdge, bool bEdge, bool cEdge) {
  if (aEdge) startSnake();
  else if (cEdge) startRound();
  else if (bEdge) showTitle();
}

void setup() {
  Modulino.begin(Wire1);
  buttons.begin();
  movementReady = movement.begin();
  display.begin();
  display.setRotation(1);
  display.setTextWrap(false);
  randomSeed(micros());
  showTitle();
}

void loop() {
  unsigned long now = millis();
  readControls();                       // poll every pass so short taps are not missed
  bool fireNow = btnA || stickPress;
  if (btnA && !prevA) pendA = true;
  if (btnB && !prevB) pendB = true;
  if (btnC && !prevC) pendC = true;
  if (fireNow && !prevFire) pendFire = true;
  if (btnOk && (btnA != prevA || btnB != prevB || btnC != prevC)) {
    buttons.setLeds(btnA, btnB, btnC);
  }
  prevA = btnA; prevB = btnB; prevC = btnC; prevFire = fireNow;

  if (now - lastFrame < 25) return;
  lastFrame = now;
  bool aEdge = pendA, bEdge = pendB, cEdge = pendC, fireEdge = pendFire;
  pendA = false; pendB = false; pendC = false; pendFire = false;

  if (state == ST_TITLE) updateTitle(aEdge, now);
  else if (state == ST_PLAY) updatePlay(fireEdge, cEdge, now);
  else if (state == ST_OVER) updateOver(aEdge, bEdge, cEdge);
  else if (state == ST_SNAKE) updateSnake(bEdge, cEdge, now);
  else updateSnakeOver(bEdge, cEdge);
}
