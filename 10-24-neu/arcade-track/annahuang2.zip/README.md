# Steady-Hand Target Blitz

A 30-second target shooting game for the UNO Q arcade console.
The stick aims, and tilting the console pushes your aim off target,
so you need a steady hand.

## How to play
1. Hold the console flat, let go of the stick, press A. This calibrates the
   stick center and the tilt zero point, then starts a round.
2. Move the crosshair with the stick. Fire with A or by pressing the stick.
3. Hit as many targets as you can in 30 seconds. Targets shrink and expire
   faster as you score.
4. C restarts at any time. On the end screen, C plays again and B returns
   to calibration.

## Scoring
- Position: bullseye (yellow) 3, red ring 2, outer ring 1.
- Speed bonus: +2 if hit within 1.0 s, +1 within 1.8 s.
- Combo: +1 on every hit from the 3rd in a row.
- Feedback: HIT, NICE!, GOOD, GREAT!, PRECISE!, QUICK DRAW!, BLAZING!,
  EXCELLENT!, EXTRAORDINARY! depending on position and speed. A miss shows
  its distance in pixels; a target that expires shows TOO LATE.
- End screen: score, hit rate, average reaction time, rank (WARMING UP,
  ROOKIE, STEADY HAND, SHARPSHOOTER, LEGEND) and best score.

## Level 2: Snake
After the target round, press A on the end screen to play Snake.
Steer with the stick (same calibration as Level 1). Eat the red apples to
grow and score 10 points each; the snake speeds up as it grows. Hitting a
wall or yourself ends the game. C restarts, B returns to the title.

## Controls
| Control | Action |
| --- | --- |
| Stick | Aim |
| Tilt | Pushes the aim (drift) |
| A | Calibrate and start / fire |
| Stick press | Fire |
| B | Back to calibration (end screen) |
| C | Restart / play again |
| A (end screen) | Start Level 2: Snake |

## Run
1. Open the app in Arduino App Lab and select the UNO Q console.
2. Press Run. The game runs on the MCU; python/main.py is a placeholder.
3. If the TFT stays white, set ARCADE_TFT_HX8357D to 0 in sketch/sketch.ino.
4. Direction and speed settings are at the top of sketch/sketch.ino:
   STICK_X_SIGN, STICK_Y_SIGN, TILT_X_SIGN, TILT_Y_SIGN, TILT_SWAP,
   TILT_GAIN, STICK_SPEED.

## Credits
Built on the Qualcomm UNO Q Hackout arcade starter (display and Modulino
setup). Game design by Xingyu Huang; code written with AI assistance
(Claude, Anthropic).
