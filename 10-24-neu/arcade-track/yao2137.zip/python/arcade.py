"""Shared game flow (Ready -> Playing -> Over, pause on missing controls) and screen helpers."""

import random

from display import BLACK, GRAY, GREEN, RED, WHITE, YELLOW

READY, PLAYING, OVER, PAUSED = 0, 1, 2, 3
STATE_NAMES = {READY: "Ready", PLAYING: "Playing", OVER: "Over", PAUSED: "Paused"}
BUTTON_A, BUTTON_B, BUTTON_C, BUTTON_STICK = 1, 2, 4, 8
BUTTONS, STICK, MOVEMENT = 1, 2, 4  # bits of inputs["connected"]
CONTROL_NAMES = ((BUTTONS, "Buttons"), (STICK, "Stick"), (MOVEMENT, "IMU"))

MAX_DT = 0.25           # a stalled frame must not teleport anything
RESTART_GUARD_S = 1.0   # ignore buttons right after a round ends
BOX_X, BOX_Y, BOX_W, BOX_H = 70, 96, 340, 150
HUD_Y = 6


def missing_text(missing):
    return "Connect: " + " ".join(name for bit, name in CONTROL_NAMES if missing & bit)


def hud(d, x, label, value, color=WHITE, width=0):
    """A HUD field: grey label, then a value padded to `width` characters."""
    d.text(x, HUD_Y, label, 2, GRAY)
    d.text(x + 12 * (len(label) + 1), HUD_Y, str(value).ljust(width), 2, color)


def hud_value(d, x, label, value, color=WHITE, width=0):
    d.text(x + 12 * (len(label) + 1), HUD_Y, str(value).ljust(width), 2, color)


class StickRepeat:
    """Turns a held stick direction into steps: one at once, then repeats after a delay."""

    def __init__(self, first_s=0.3, repeat_s=0.15, threshold=64):
        self.first_s, self.repeat_s, self.threshold = first_s, repeat_s, threshold
        self.direction = None
        self.timer = 0.0

    def update(self, dt, stick):
        x, y = stick
        if abs(x) >= abs(y) and abs(x) > self.threshold:
            direction = (1 if x > 0 else -1, 0)
        elif abs(y) > self.threshold:
            direction = (0, 1 if y > 0 else -1)
        else:
            direction = None
        if direction != self.direction:
            self.direction = direction
            self.timer = self.first_s
            return direction
        if direction is None:
            return None
        self.timer -= dt
        if self.timer <= 0:
            self.timer += self.repeat_s
            return direction
        return None


class ArcadeGame:
    NAME = "Game"
    REQUIRED = BUTTONS | STICK
    HELP = ()  # up to three Ready-screen lines, 24 characters each

    def __init__(self, rng=None):
        self.rng = rng or random.Random()
        self.best = None
        self.prev_buttons = 0
        self.state = READY
        self.missing = 0
        self.wants_menu = False
        self.won = False
        self.over_age = 0.0
        self.drawn_key = None
        self.redraw = False  # a game sets this when its whole screen changes (new level)
        self.reset()

    # ---- hooks for each game ----
    def reset(self):
        """New round: reset score, positions and timers."""

    def play(self, dt, stick, tilt, pressed, buttons):
        """One Playing frame."""

    def draw_screen(self, d, full):
        """full: the screen was cleared, draw everything; otherwise only what changed."""

    def result_lines(self):
        return [("GAME OVER", RED)]

    def record(self):
        """Update self.best when a round ends."""

    def best_text(self):
        return "-" if self.best is None else str(self.best)

    def status(self):
        return f"{self.NAME}: {STATE_NAMES[self.state]}"

    # ---- shared flow ----
    def update(self, dt, stick, tilt, buttons, connected):
        dt = max(0.0, min(dt, MAX_DT))
        pressed = buttons & ~self.prev_buttons  # only new presses count
        self.prev_buttons = buttons
        self.missing = self.REQUIRED & ~connected

        if self.state == READY:
            if pressed & BUTTON_B:
                self.wants_menu = True
            elif pressed & BUTTON_A and not self.missing:
                self.reset()
                self.state = PLAYING
        elif self.state == OVER:
            self.over_age += dt
            if self.over_age >= RESTART_GUARD_S:
                if pressed & BUTTON_B:
                    self.wants_menu = True
                elif pressed & BUTTON_C:
                    self.state = READY
        elif self.state == PAUSED:
            if not self.missing:
                self.state = PLAYING
        elif self.missing:
            self.state = PAUSED  # the game stops until every control is back
        else:
            self.play(dt, stick, tilt, pressed, buttons)

    def finish(self, won=False):
        self.won = won
        self.over_age = 0.0
        self.state = OVER
        self.record()

    def render(self, d, lost):
        key = (self.state, self.missing if self.state != PLAYING else 0)
        if lost or key != self.drawn_key or self.redraw:
            self.redraw = False
            d.clear()
            self.draw_screen(d, True)
            if self.state != PLAYING:
                self.draw_box(d, self.box_lines())
            self.drawn_key = key
        elif self.state == PLAYING:
            self.draw_screen(d, False)

    def box_lines(self):
        if self.state == READY:
            lines = [(self.NAME, YELLOW)] + [(line, WHITE) for line in self.HELP]
            lines += [("", WHITE)] * (4 - len(lines))
            if self.missing:
                return lines + [(missing_text(self.missing), RED)]
            return lines + [("A: start    B: menu", GREEN)]
        if self.state == PAUSED:
            return [("PAUSED", YELLOW), ("", WHITE), (missing_text(self.missing), RED),
                    ("", WHITE), ("Resumes automatically", GRAY)]
        lines = self.result_lines()[:4]
        lines += [("", WHITE)] * (4 - len(lines))
        return lines + [("C: again    B: menu", GREEN)]

    @staticmethod
    def draw_box(d, lines):
        d.fill(BOX_X, BOX_Y, BOX_W, BOX_H, BLACK)
        d.frame(BOX_X, BOX_Y, BOX_W, BOX_H, WHITE)
        for row, (text, color) in enumerate(lines):
            if text:
                d.text(BOX_X + 14, BOX_Y + 12 + row * 26, text, 2, color)
