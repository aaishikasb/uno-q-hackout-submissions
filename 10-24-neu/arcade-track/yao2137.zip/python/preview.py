"""Map validated hardware input to a display preview; replace this with game rules."""

DEAD_ZONE = 26
INVERT_X = False
INVERT_Y = True
# Calibrated 2026-10-24 with the console upright in its playing position.
MOVEMENT_ZERO_MG = (53, -988, 104)
MOVEMENT_DEAD_ZONE_MG = 20
# Movement axis and sign that tilt the target right / down on screen.
# Upright console: gravity is on -Y, so left/right roll shows on ax, forward/back on az.
TILT_X = ("ax", -1)
TILT_Y = ("az", 1)

LIMITS = {
    "connected": (0, 7), "buttons": (0, 15),
    "x": (-127, 128), "y": (-127, 128),
    "ax": (-16000, 16000), "ay": (-16000, 16000), "az": (-16000, 16000),
}


def validate(inputs):
    for key, (low, high) in LIMITS.items():
        value = inputs[key]
        if type(value) is not int or not low <= value <= high:
            raise ValueError(f"Invalid arcade input: {key}")


def stick(inputs):
    """Calibrated joystick (x, y) in -128..128, screen-oriented (+y is down)."""
    connected = inputs["connected"]
    x = inputs["x"] if connected & 2 else 0
    y = inputs["y"] if connected & 2 else 0
    x = 0 if abs(x) < DEAD_ZONE else x
    y = 0 if abs(y) < DEAD_ZONE else y
    if INVERT_X:
        x = -x
    if INVERT_Y:
        y = -y
    return x, y


def pressed_buttons(inputs):
    connected = inputs["connected"]
    return inputs["buttons"] & ((7 if connected & 1 else 0) | (8 if connected & 2 else 0))


def movement(inputs):
    """Movement change from the calibrated zero, in mg, per axis (ax, ay, az)."""
    deltas = []
    for key, zero in zip(("ax", "ay", "az"), MOVEMENT_ZERO_MG):
        delta = inputs[key] - zero if inputs["connected"] & 4 else 0
        deltas.append(0 if abs(delta) < MOVEMENT_DEAD_ZONE_MG
                      else max(-16000, min(16000, delta)))
    return deltas


def controls(inputs):
    """Validated controls for the game: stick, tilt (screen x, y in mg), buttons, connected."""
    validate(inputs)
    deltas = dict(zip(("ax", "ay", "az"), movement(inputs)))
    tilt = (TILT_X[1] * deltas[TILT_X[0]], TILT_Y[1] * deltas[TILT_Y[0]])
    return stick(inputs), tilt, pressed_buttons(inputs), inputs["connected"]


def frame_values(inputs):
    validate(inputs)
    x, y = stick(inputs)
    return (
        max(20, min(460, 240 + round(x * 220 / 128))),
        max(168, min(300, 234 + round(y * 66 / 128))),
        pressed_buttons(inputs), *movement(inputs), inputs["connected"],
    )
