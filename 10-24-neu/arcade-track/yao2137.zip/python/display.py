"""Batched drawing through the sketch's arcade_draw display list (see sketch.ino)."""

# Palette indices; the RGB565 values live in PALETTE in sketch.ino.
(BLACK, CYAN, YELLOW, PURPLE, GREEN, RED, BLUE, ORANGE,
 GRAY, WHITE, DARK, LIGHT, BROWN, DARK_GREEN, NAVY, MAGENTA) = range(16)

# Tiles drawn by the sketch's drawTile(); 1-7 are the Tetris colours.
T_EMPTY, T_GHOST, T_FLASH = 0, 8, 9
T_WALL, T_FLOOR, T_GOAL, T_BOX, T_BOX_ON_GOAL, T_PLAYER, T_PLAYER_ON_GOAL = range(10, 17)
T_SNAKE, T_SNAKE_HEAD, T_APPLE = 17, 18, 19
T_HIDDEN, T_OPEN = 20, 21  # Minesweeper; 22-29 are open cells showing 1-8
T_FLAG, T_MINE_HIT, T_MINE, T_WRONG_FLAG = 30, 31, 32, 33

OP_CLEAR, OP_FILL, OP_FRAME, OP_TEXT, OP_DISC, OP_TILE = range(1, 7)
WIDTH, HEIGHT = 480, 320
MAX_MESSAGE = 200  # the Bridge buffer is 256 bytes including the RPC envelope


def _u16(value):
    value = max(0, min(65535, int(value)))
    return value & 0xFF, value >> 8


class Display:
    def __init__(self, bridge):
        self.bridge = bridge
        self.ops = []
        self.epoch = None
        self.lost = True  # the screen content is unknown: redraw everything

    def clear(self, color=BLACK):
        self.ops.append(bytes((OP_CLEAR, color)))

    def fill(self, x, y, w, h, color):
        self.ops.append(bytes((OP_FILL, *_u16(x), *_u16(y), *_u16(w), *_u16(h), color)))

    def frame(self, x, y, w, h, color):
        self.ops.append(bytes((OP_FRAME, *_u16(x), *_u16(y), *_u16(w), *_u16(h), color)))

    def text(self, x, y, text, size=2, fg=WHITE, bg=BLACK):
        """bg == fg draws transparent text; otherwise each character clears its cell."""
        data = str(text).encode("ascii", "replace")[:150]
        self.ops.append(bytes((OP_TEXT, *_u16(x), *_u16(y), size, fg, bg, len(data))) + data)

    def disc(self, x, y, r, color):
        self.ops.append(bytes((OP_DISC, *_u16(x), *_u16(y), r, color)))

    def tile(self, x, y, size, tile):
        self.ops.append(bytes((OP_TILE, *_u16(x), *_u16(y), size, tile)))

    def flush(self):
        """Send queued drawing; always sends at least once so the MCU knows the app is alive."""
        ops, self.ops = self.ops, []
        message = b""
        for op in ops:
            if len(message) + len(op) > MAX_MESSAGE:
                self._send(message)
                message = b""
            message += op
        self._send(message)

    def _send(self, message):
        epoch = self.bridge.call("arcade_draw", message)
        if epoch != self.epoch:
            # The MCU drew its own screen (waiting / RetroArch) since our last frame.
            if self.epoch is not None:
                self.lost = True
            self.epoch = epoch


class GridView:
    """Draws a grid of tiles, sending only the cells that changed since the last frame."""

    def __init__(self, cols, rows, x, y, size):
        self.cols, self.rows, self.x, self.y, self.size = cols, rows, x, y, size
        self.shown = None

    def cell_xy(self, index):
        return self.x + (index % self.cols) * self.size, self.y + (index // self.cols) * self.size

    def draw(self, d, tiles, full):
        """full: the screen was just cleared, so empty (black) cells need no drawing."""
        old = None if full else self.shown
        for i, tile in enumerate(tiles):
            if (old is None and (tile != T_EMPTY or not full)) or (old is not None and old[i] != tile):
                d.tile(*self.cell_xy(i), self.size, tile)
        self.shown = list(tiles)
