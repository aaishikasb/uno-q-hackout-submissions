import json
import time

from arduino.app_utils import App, Bridge
from arcade import BUTTON_A, StickRepeat
from breakout import Breakout
from display import CYAN, GRAY, WHITE, YELLOW, BLACK, Display
from minesweeper import Minesweeper
from preview import controls
from snake import Snake
from sokoban import Sokoban
from tetris import Tetris

GAMES = [Tetris(), Snake(), Breakout(), Sokoban(), Minesweeper()]
DEFAULT_GAME = 1  # Snake opens at power-on; B on its Ready screen goes to the menu
MENU_Y, MENU_DY = 78, 42

display = Display(Bridge)
menu_stick = StickRepeat(0.3, 0.2)
current = GAMES[DEFAULT_GAME]  # the game being played; None shows the menu
selected = DEFAULT_GAME
prev_buttons = 0
menu_shown = None
last_time = None
last_status = "start"


def draw_menu(full):
    """Redraw only the rows whose selection or best score changed."""
    global menu_shown
    if full:
        display.clear()
        display.text(132, 24, "UNO Q ARCADE", 3, YELLOW)
        display.fill(40, 60, 400, 1, GRAY)
        display.text(102, 294, "Stick: choose   A: play", 2, GRAY)
        menu_shown = [None] * len(GAMES)
    for i, game in enumerate(GAMES):
        row = (i == selected, game.best_text())
        if menu_shown[i] == row:
            continue
        y = MENU_Y + i * MENU_DY
        on = i == selected
        display.frame(40, y - 9, 400, 34, CYAN if on else BLACK)
        display.text(56, y, ("> " if on else "  ") + game.NAME.ljust(12), 2, WHITE if on else GRAY)
        display.text(272, y, game.best_text().ljust(13), 2, WHITE if on else GRAY)
        menu_shown[i] = row


def update_menu(dt, stick, buttons, lost):
    """Stick up/down picks a game, A starts it."""
    global selected, prev_buttons, current
    pressed = buttons & ~prev_buttons
    prev_buttons = buttons
    step = menu_stick.update(dt, stick)
    if step and step[1]:
        selected = (selected + step[1]) % len(GAMES)
    if pressed & BUTTON_A:
        current = GAMES[selected]
        current.prev_buttons = buttons  # the A that chose the game must not also start it
        current.wants_menu = False
        current.drawn_key = None
        return
    draw_menu(lost or menu_shown is None)


def loop():
    global last_time, last_status, current, prev_buttons, menu_shown
    try:
        response = Bridge.call("arcade_read_inputs")
        if not isinstance(response, (str, bytes, bytearray)):
            raise TypeError("Expected JSON text from arcade_read_inputs")
        inputs = json.loads(response)
        if inputs.get("video", 0):
            last_time = None
            display.lost = True
            time.sleep(0.5)
            return
        now = time.monotonic()
        dt = 0.0 if last_time is None else now - last_time
        last_time = now
        stick, tilt, buttons, connected = controls(inputs)

        lost, display.lost = display.lost, False
        if current is None:
            update_menu(dt, stick, buttons, lost)
        else:
            current.update(dt, stick, tilt, buttons, connected)
            if current.wants_menu:
                current.wants_menu = False
                current = None
                prev_buttons = buttons
                menu_shown = None
            else:
                current.render(display, lost)
        display.flush()
    except Exception as error:
        # Without fresh frames the MCU shows "Waiting for App Lab..." after 1.5 seconds.
        print(f"Arcade connection/input error: {error}")
        last_time = None
        display.ops.clear()
        display.lost = True
        time.sleep(1)
        return

    key = (current.NAME, current.state) if current else None
    if key != last_status:
        print(current.status() if current else "Menu")  # log screen and state changes
    last_status = key
    time.sleep(0.005)


print("UNO Q Arcade: choose a game with the stick, press A to play.")
App.run(user_loop=loop)
