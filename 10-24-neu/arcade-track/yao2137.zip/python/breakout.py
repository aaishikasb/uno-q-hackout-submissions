"""Breakout: move the paddle with the stick or by tilting, clear every brick, keep the ball alive."""

import math

from arcade import BUTTON_A, PLAYING, ArcadeGame, hud, hud_value
from display import (BLACK, BLUE, CYAN, GRAY, GREEN, LIGHT, ORANGE, RED, WHITE, YELLOW)

FIELD_TOP = 30
BRICK_COLS, BRICK_ROWS = 10, 6
BRICK_W, BRICK_H, BRICK_X, BRICK_Y, BRICK_DX, BRICK_DY = 44, 14, 8, 50, 47, 18
ROW_COLORS = (RED, ORANGE, YELLOW, GREEN, CYAN, BLUE)
ROW_POINTS = (6, 5, 4, 3, 2, 1)
TOUGH = LIGHT  # colour of a brick that needs two hits (from level 2)
PADDLE_Y, PADDLE_H = 296, 8
PADDLE_W = (72, 64, 56)  # shrinks on later levels
PADDLE_SPEED = 380.0     # px/s at full stick deflection
TILT_GAIN = 0.6          # px/s per mg of left/right tilt
BALL_R = 4
BALL_SPEED, BALL_SPEED_STEP, BALL_SPEED_HIT, BALL_SPEED_MAX = 230.0, 25.0, 5.0, 420.0
MAX_BOUNCE_DEG = 60
SUBSTEP_PX = 3
LIVES = 3
HINT = "A: launch"
HINT_X, HINT_Y = 240 - 6 * len(HINT), 240


def clamp(value, low, high):
    return max(low, min(high, value))


def brick_rect(index):
    col, row = index % BRICK_COLS, index // BRICK_COLS
    return BRICK_X + col * BRICK_DX, BRICK_Y + row * BRICK_DY, BRICK_W, BRICK_H


def overlaps(a, b):
    return a[0] < b[0] + b[2] and b[0] < a[0] + a[2] and a[1] < b[1] + b[3] and b[1] < a[1] + a[3]


class Breakout(ArcadeGame):
    NAME = "BREAKOUT"
    HELP = ("Stick or tilt: paddle", "A: launch the ball", "Clear all bricks")

    def __init__(self, rng=None):
        self.shown = {}
        super().__init__(rng)

    def reset(self):
        self.score = 0
        self.lives = LIVES
        self.level = 1
        self._build_level()

    def _build_level(self):
        # hits left per brick; from level 2 the top row needs two hits
        self.bricks = [2 if (self.level >= 2 and i < BRICK_COLS) else 1
                       for i in range(BRICK_COLS * BRICK_ROWS)]
        self.paddle_w = PADDLE_W[min(self.level, len(PADDLE_W)) - 1]
        self.px = 240.0
        self.speed = BALL_SPEED + BALL_SPEED_STEP * (self.level - 1)
        self._attach()
        self.redraw = True

    def _attach(self):
        self.attached = True
        self.bx, self.by = self.px, PADDLE_Y - BALL_R - 1
        self.vx = self.vy = 0.0

    def record(self):
        self.best = max(self.best or 0, self.score)

    def result_lines(self):
        best = self.best or 0
        return [("GAME OVER", RED), (f"Score: {self.score}", WHITE),
                (f"Best:  {best}", GREEN if self.score >= best > 0 else WHITE),
                (f"Level: {self.level}", GRAY)]

    def status(self):
        return f"{super().status()} score={self.score} level={self.level} lives={self.lives}"

    def play(self, dt, stick, tilt, pressed, buttons):
        half = self.paddle_w / 2
        velocity = stick[0] / 128 * PADDLE_SPEED + tilt[0] * TILT_GAIN
        self.px = clamp(self.px + velocity * dt, half, 480 - half)
        if self.attached:
            self.bx = self.px
            if pressed & BUTTON_A:
                self.attached = False
                self._launch(self.rng.uniform(-0.4, 0.4))
            return
        distance = self.speed * dt
        steps = max(1, math.ceil(distance / SUBSTEP_PX))
        for _ in range(steps):
            self._move(dt / steps)
            if self.attached or self.state != PLAYING:
                return

    def _launch(self, offset):
        """offset -1..1 across the paddle sets the bounce angle."""
        angle = math.radians(clamp(offset, -1, 1) * MAX_BOUNCE_DEG)
        self.vx = self.speed * math.sin(angle)
        self.vy = -self.speed * math.cos(angle)

    def _ball_rect(self):
        return self.bx - BALL_R, self.by - BALL_R, 2 * BALL_R + 1, 2 * BALL_R + 1

    def _hit_brick(self):
        ball = self._ball_rect()
        for i, hits in enumerate(self.bricks):
            if hits and overlaps(ball, brick_rect(i)):
                self.bricks[i] -= 1
                if not self.bricks[i]:
                    self.score += ROW_POINTS[i // BRICK_COLS] * self.level
                return True
        return False

    def _move(self, dt):
        self.bx += self.vx * dt
        if self._hit_brick():
            self.bx -= self.vx * dt
            self.vx = -self.vx
        if self.bx < BALL_R or self.bx > 479 - BALL_R:
            self.bx = clamp(self.bx, BALL_R, 479 - BALL_R)
            self.vx = -self.vx

        self.by += self.vy * dt
        if self._hit_brick():
            self.by -= self.vy * dt
            self.vy = -self.vy
        if self.by < FIELD_TOP + BALL_R:
            self.by = FIELD_TOP + BALL_R
            self.vy = abs(self.vy)
        half = self.paddle_w / 2
        if (self.vy > 0 and PADDLE_Y <= self.by + BALL_R <= PADDLE_Y + PADDLE_H
                and abs(self.bx - self.px) <= half + BALL_R):
            self.by = PADDLE_Y - BALL_R - 1
            self.speed = min(BALL_SPEED_MAX, self.speed + BALL_SPEED_HIT)
            self._launch((self.bx - self.px) / half)

        if not any(self.bricks):
            self.score += 50 * self.level
            self.level += 1
            self._build_level()
        elif self.by - BALL_R > 320:
            self.lives -= 1
            if self.lives:
                self._attach()
            else:
                self.finish()

    # ---- screen ----
    def _brick_color(self, i):
        return TOUGH if self.bricks[i] > 1 else ROW_COLORS[i // BRICK_COLS]

    def _draw_brick(self, d, i):
        x, y, w, h = brick_rect(i)
        d.fill(x, y, w, h, self._brick_color(i) if self.bricks[i] else BLACK)

    def draw_screen(self, d, full):
        shown = self.shown
        if full:
            shown = self.shown = {"bricks": [0] * len(self.bricks)}
            d.fill(0, FIELD_TOP - 2, 480, 1, GRAY)
            for x, label in ((6, "SCORE"), (150, "BEST"), (294, "LIVES"), (402, "LV")):
                hud(d, x, label, "")
        colors = [self._brick_color(i) if hits else BLACK for i, hits in enumerate(self.bricks)]
        for i, color in enumerate(colors):
            if shown["bricks"][i] != color:
                self._draw_brick(d, i)
        shown["bricks"] = colors

        # Paddle: paint only the strips that changed.
        half = self.paddle_w / 2
        new = (round(self.px - half), round(self.px + half))
        old = shown.get("paddle")
        if old != new:
            if old is None or old[1] <= new[0] or new[1] <= old[0]:
                if old:
                    d.fill(old[0], PADDLE_Y, old[1] - old[0], PADDLE_H, BLACK)
                d.fill(new[0], PADDLE_Y, new[1] - new[0], PADDLE_H, WHITE)
            elif new[0] > old[0]:
                d.fill(old[0], PADDLE_Y, new[0] - old[0], PADDLE_H, BLACK)
                d.fill(old[1], PADDLE_Y, new[1] - old[1], PADDLE_H, WHITE)
            else:
                d.fill(new[1], PADDLE_Y, old[1] - new[1], PADDLE_H, BLACK)
                d.fill(new[0], PADDLE_Y, old[0] - new[0], PADDLE_H, WHITE)
            shown["paddle"] = new

        ball = (round(self.bx), round(self.by))
        if shown.get("ball") != ball:
            old_ball = shown.get("ball")
            if old_ball and old_ball[1] - BALL_R < 320:
                erase = (old_ball[0] - BALL_R, old_ball[1] - BALL_R, 2 * BALL_R + 1,
                         min(2 * BALL_R + 1, 320 - (old_ball[1] - BALL_R)))
                d.fill(*erase, BLACK)
                # Repair anything the erase square cut into.
                for i, hits in enumerate(self.bricks):
                    if hits and overlaps(erase, brick_rect(i)):
                        self._draw_brick(d, i)
                if erase[1] + erase[3] > PADDLE_Y:
                    d.fill(new[0], PADDLE_Y, new[1] - new[0], PADDLE_H, WHITE)
            if ball[1] + BALL_R < 320:  # below that the ball is leaving the screen
                d.disc(ball[0], ball[1], BALL_R, YELLOW)
            shown["ball"] = ball

        if shown.get("hint") != self.attached:
            if self.attached:
                d.text(HINT_X, HINT_Y, HINT, 2, GRAY)
            elif "hint" in shown:
                d.fill(HINT_X, HINT_Y, 12 * len(HINT), 16, BLACK)
            shown["hint"] = self.attached

        values = {"score": self.score, "best": max(self.best or 0, self.score),
                  "lives": self.lives, "level": self.level}
        for key, x, label, width in (("score", 6, "SCORE", 5), ("best", 150, "BEST", 5),
                                     ("lives", 294, "LIVES", 1), ("level", 402, "LV", 2)):
            if shown.get(key) != values[key]:
                hud_value(d, x, label, values[key], WHITE, width)
                shown[key] = values[key]
