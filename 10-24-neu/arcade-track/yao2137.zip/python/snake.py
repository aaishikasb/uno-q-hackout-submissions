"""Snake: eat apples, do not hit the walls or yourself; tilt forward to boost for double points."""

from arcade import PLAYING, READY, ArcadeGame, StickRepeat, hud, hud_value
from display import (CYAN, GRAY, GREEN, RED, WHITE, YELLOW, T_APPLE, T_EMPTY, T_SNAKE, T_SNAKE_HEAD,
                     GridView)

CELL = 16
COLS, ROWS = 30, 18          # 480 x 288 field below the HUD
FIELD_Y = 32
# Difficulty: (name, seconds per step at the start, fastest step). Higher = faster snake.
SPEEDS = [("Slow", 0.32, 0.18), ("Easy", 0.26, 0.14), ("Normal", 0.20, 0.10),
          ("Fast", 0.15, 0.07), ("Insane", 0.10, 0.05)]
DEFAULT_SPEED = 1            # Easy
STEP_SPEEDUP = 0.02          # each apple shortens the step by 2 %
BOOST_FACTOR = 0.5           # step time while boosting
TILT_BOOST_MG = 350
STICK_THRESHOLD = 64
MAX_QUEUED_TURNS = 2


class Snake(ArcadeGame):
    NAME = "SNAKE"
    HELP = ("Stick: steer", "Tilt forward: boost", "Boosted apples = x2")

    def __init__(self, rng=None):
        self.view = GridView(COLS, ROWS, 0, FIELD_Y, CELL)
        self.shown = {}
        self.speed = DEFAULT_SPEED
        self.bests = {}  # best score per difficulty
        self.ready_stick = StickRepeat(0.3, 0.2)
        super().__init__(rng)

    def update(self, dt, stick, tilt, buttons, connected):
        if self.state == READY:  # stick left/right picks the difficulty
            step = self.ready_stick.update(dt, stick)
            if step and step[0]:
                speed = max(0, min(len(SPEEDS) - 1, self.speed + step[0]))
                if speed != self.speed:
                    self.speed = speed
                    self.redraw = True
        super().update(dt, stick, tilt, buttons, connected)

    def box_lines(self):
        if self.state == READY and not self.missing:
            name = SPEEDS[self.speed][0]
            return [(self.NAME, YELLOW), ("Stick: steer", WHITE),
                    ("Tilt fwd: boost, x2 pts", WHITE),
                    (f"< Speed {self.speed + 1}/{len(SPEEDS)}: {name} >", CYAN),
                    ("A: start    B: menu", GREEN)]
        return super().box_lines()

    def best_score(self):
        return self.bests.get(self.speed, 0)

    def best_text(self):
        if not self.bests:
            return "-"
        speed = max(self.bests, key=lambda s: (self.bests[s], s))
        return f"{self.bests[speed]} ({SPEEDS[speed][0]})"

    def reset(self):
        row = ROWS // 2
        self.body = [(8, row), (7, row), (6, row)]  # head first
        self.direction = (1, 0)
        self.turns = []
        self.stick_dir = None
        self.timer = 0.0
        self.score = 0
        self.boost = False
        self._place_apple()

    def record(self):
        self.bests[self.speed] = max(self.best_score(), self.score)

    def result_lines(self):
        best = self.best_score()
        return [("YOU WIN!" if self.won else "GAME OVER", GREEN if self.won else RED),
                (f"Score:  {self.score}", WHITE),
                (f"Best:   {best}", GREEN if self.score >= best > 0 else WHITE),
                (f"Length {len(self.body)}  {SPEEDS[self.speed][0]}", GRAY)]

    def status(self):
        return (f"{super().status()} speed={SPEEDS[self.speed][0]} score={self.score} "
                f"length={len(self.body)}")

    def _place_apple(self):
        free = [(x, y) for y in range(ROWS) for x in range(COLS) if (x, y) not in self.body]
        self.apple = self.rng.choice(free) if free else None

    def _step_s(self):
        _, start, fastest = SPEEDS[self.speed]
        step = max(fastest, start * (1 - STEP_SPEEDUP) ** (len(self.body) - 3))
        return step * BOOST_FACTOR if self.boost else step

    def play(self, dt, stick, tilt, pressed, buttons):
        x, y = stick
        if abs(x) >= abs(y) and abs(x) > STICK_THRESHOLD:
            wanted = (1 if x > 0 else -1, 0)
        elif abs(y) > STICK_THRESHOLD:
            wanted = (0, 1 if y > 0 else -1)
        else:
            wanted = None
        # Queue each new stick direction so quick double turns are not lost.
        if wanted and wanted != self.stick_dir and len(self.turns) < MAX_QUEUED_TURNS:
            self.turns.append(wanted)
        self.stick_dir = wanted
        self.boost = tilt[1] > TILT_BOOST_MG

        self.timer += dt
        while self.timer >= self._step_s() and self.state == PLAYING:
            self.timer -= self._step_s()
            self._step()

    def _step(self):
        while self.turns:
            turn = self.turns.pop(0)
            if turn != self.direction and turn != (-self.direction[0], -self.direction[1]):
                self.direction = turn  # a reversal would bite the neck, so it is ignored
                break
        hx, hy = self.body[0]
        head = (hx + self.direction[0], hy + self.direction[1])
        eating = head == self.apple
        body = self.body if eating else self.body[:-1]
        if not (0 <= head[0] < COLS and 0 <= head[1] < ROWS) or head in body:
            self.finish()
            return
        self.body = [head] + body
        if eating:
            self.score += 2 if self.boost else 1
            self._place_apple()
            if self.apple is None:
                self.finish(won=True)

    def draw_screen(self, d, full):
        tiles = [T_EMPTY] * (COLS * ROWS)
        for x, y in self.body[1:]:
            tiles[y * COLS + x] = T_SNAKE
        hx, hy = self.body[0]
        tiles[hy * COLS + hx] = T_SNAKE_HEAD
        if self.apple:
            tiles[self.apple[1] * COLS + self.apple[0]] = T_APPLE
        self.view.draw(d, tiles, full)

        if full:
            self.shown = {}
            d.fill(0, FIELD_Y - 2, 480, 1, GRAY)
            hud(d, 6, "SCORE", "")
            hud(d, 150, "BEST", "")
            hud(d, 282, "LEN", "")
        values = {"score": self.score, "best": max(self.best_score(), self.score),
                  "len": len(self.body), "boost": self.boost}
        for key, x, label in (("score", 6, "SCORE"), ("best", 150, "BEST"), ("len", 282, "LEN")):
            if self.shown.get(key) != values[key]:
                hud_value(d, x, label, values[key], WHITE, 4)
        if self.shown.get("boost") != self.boost:
            d.text(396, 6, "BOOST" if self.boost else "     ", 2, CYAN)
        self.shown = values
