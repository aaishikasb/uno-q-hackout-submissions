"""Tetris: classic rules (7-bag, hold, ghost, lock delay) plus a tilt-forward hard drop."""

from arcade import BUTTON_A, BUTTON_B, BUTTON_C, BUTTON_STICK, OVER, ArcadeGame
from display import GRAY, GREEN, RED, WHITE, YELLOW, T_EMPTY, T_FLASH, T_GHOST, GridView

COLS, ROWS = 10, 20
CELL, BOARD_X, BOARD_Y = 14, 170, 26  # 140 x 280 pixel board in the middle of the screen
PIECES = "IOTSZJL"  # tile index = position + 1
SHAPES = {  # (box size, cells at rotation 0)
    "I": (4, [(0, 1), (1, 1), (2, 1), (3, 1)]),
    "O": (2, [(0, 0), (1, 0), (0, 1), (1, 1)]),
    "T": (3, [(1, 0), (0, 1), (1, 1), (2, 1)]),
    "S": (3, [(1, 0), (2, 0), (0, 1), (1, 1)]),
    "Z": (3, [(0, 0), (1, 0), (1, 1), (2, 1)]),
    "J": (3, [(0, 0), (0, 1), (1, 1), (2, 1)]),
    "L": (3, [(2, 0), (0, 1), (1, 1), (2, 1)]),
}
KICKS = [(0, 0), (-1, 0), (1, 0), (0, -1), (-2, 0), (2, 0)]
LINE_SCORES = (0, 100, 300, 500, 800)

STICK_THRESHOLD = 64
DAS_S, ARR_S = 0.25, 0.10    # sideways auto-repeat: first delay, then repeat interval
SOFT_DROP_S = 0.05
LOCK_S, MAX_LOCK_RESETS = 0.5, 15
CLEAR_FLASH_S = 0.2
TILT_SLAM_MG, TILT_REARM_MG = 450, 200


def rotated_cells(kind, rotation):
    size, cells = SHAPES[kind]
    for _ in range(rotation % 4):
        cells = [(size - 1 - y, x) for x, y in cells]  # clockwise
    return cells


def gravity_s(level):
    """Seconds per row, following the guideline curve."""
    return max(0.03, (0.8 - (level - 1) * 0.007) ** (level - 1))


def preview_tiles(kind):
    """A 4 x 2 preview of a piece in its spawn rotation."""
    tiles = [T_EMPTY] * 8
    if kind:
        for x, y in rotated_cells(kind, 0):
            row = y - 1 if kind == "I" else y
            tiles[row * 4 + x + (1 if kind == "O" else 0)] = PIECES.index(kind) + 1
    return tiles


class Tetris(ArcadeGame):
    NAME = "TETRIS"
    HELP = ("Stick: move/soft drop", "A/C: rotate  B: hold", "Press/tilt fwd: slam")

    def __init__(self, rng=None):
        self.board_view = GridView(COLS, ROWS, BOARD_X, BOARD_Y, CELL)
        self.next_view = GridView(4, 2, 332, 54, CELL)
        self.hold_view = GridView(4, 2, 16, 54, CELL)
        self.shown = {}
        super().__init__(rng)

    def reset(self):
        self.board = [[0] * COLS for _ in range(ROWS)]
        self.score = 0
        self.lines = 0
        self.level = 1
        self.bag = []
        self.queue = [self._from_bag()]
        self.hold = None
        self.hold_used = False
        self.hdir = 0
        self.das = 0.0
        self.fall = 0.0
        self.lock_timer = 0.0
        self.lock_resets = 0
        self.clearing = []
        self.clear_timer = 0.0
        self.tilt_armed = True
        self.piece = None
        self._spawn()

    def record(self):
        self.best = max(self.best or 0, self.score)

    def result_lines(self):
        best = self.best or 0
        return [("GAME OVER", RED), (f"Score: {self.score}", WHITE),
                (f"Best:  {best}", GREEN if self.score >= best > 0 else WHITE),
                (f"Lines: {self.lines}  Lv {self.level}", GRAY)]

    def status(self):
        return f"{super().status()} score={self.score} lines={self.lines}"

    # ---- rules ----
    def _from_bag(self):
        if not self.bag:
            self.bag = list(PIECES)
            self.rng.shuffle(self.bag)
        return self.bag.pop()

    def _spawn(self, kind=None):
        if kind is None:
            kind = self.queue.pop(0)
            self.queue.append(self._from_bag())
        self.piece = [kind, 0, 4 if kind == "O" else 3, 0]  # kind, rotation, x, y
        self.fall = 0.0
        self.lock_timer = 0.0
        self.lock_resets = 0
        if not self._fits(*self.piece):
            self.finish()

    def _fits(self, kind, rotation, x, y):
        for cx, cy in rotated_cells(kind, rotation):
            col, row = x + cx, y + cy
            if not (0 <= col < COLS and 0 <= row < ROWS) or self.board[row][col]:
                return False
        return True

    def _grounded(self):
        kind, rotation, x, y = self.piece
        return not self._fits(kind, rotation, x, y + 1)

    def _try(self, rotation_delta, dx, dy, kicks=((0, 0),)):
        kind, rotation, x, y = self.piece
        rotation += rotation_delta
        for kx, ky in kicks:
            if self._fits(kind, rotation, x + dx + kx, y + dy + ky):
                self.piece = [kind, rotation % 4, x + dx + kx, y + dy + ky]
                # Moving a landed piece buys more lock time, a limited number of times.
                if self._grounded() and self.lock_resets < MAX_LOCK_RESETS:
                    self.lock_timer = 0.0
                    self.lock_resets += 1
                return True
        return False

    def play(self, dt, stick, tilt, pressed, buttons):
        if self.clearing:
            self.clear_timer -= dt
            if self.clear_timer <= 0:
                self._collapse()
            return

        direction = -1 if stick[0] < -STICK_THRESHOLD else 1 if stick[0] > STICK_THRESHOLD else 0
        if direction != self.hdir:
            self.hdir = direction
            self.das = DAS_S
            if direction:
                self._try(0, direction, 0)
        elif direction:
            self.das -= dt
            while self.das <= 0:
                self._try(0, direction, 0)
                self.das += ARR_S

        if pressed & BUTTON_A:
            self._try(1, 0, 0, KICKS)
        if pressed & BUTTON_C:
            self._try(-1, 0, 0, KICKS)
        if pressed & BUTTON_B and not self.hold_used:
            self._hold()
            return

        slam = bool(pressed & BUTTON_STICK)
        if self.tilt_armed and tilt[1] > TILT_SLAM_MG:
            slam = True
            self.tilt_armed = False
        elif tilt[1] < TILT_REARM_MG:
            self.tilt_armed = True
        if slam:
            rows = 0
            while self._try(0, 0, 1):
                rows += 1
            self.score += 2 * rows
            self._lock()
            return

        soft = stick[1] > STICK_THRESHOLD
        interval = min(SOFT_DROP_S, gravity_s(self.level)) if soft else gravity_s(self.level)
        self.fall += dt
        while self.fall >= interval:
            self.fall -= interval
            if not self._try(0, 0, 1):
                self.fall = 0.0
                break
            if soft:
                self.score += 1

        if self._grounded():
            self.lock_timer += dt
            if self.lock_timer >= LOCK_S:
                self._lock()
        else:
            self.lock_timer = 0.0

    def _hold(self):
        kind = self.piece[0]
        if self.hold is None:
            self.hold = kind
            self._spawn()
        else:
            self.hold, kind = kind, self.hold
            self._spawn(kind)
        self.hold_used = True

    def _lock(self):
        kind, rotation, x, y = self.piece
        for cx, cy in rotated_cells(kind, rotation):
            self.board[y + cy][x + cx] = PIECES.index(kind) + 1
        self.hold_used = False
        self.piece = None
        self.clearing = [row for row in range(ROWS) if all(self.board[row])]
        if self.clearing:
            self.clear_timer = CLEAR_FLASH_S
        else:
            self._spawn()

    def _collapse(self):
        count = len(self.clearing)
        self.board = [row for i, row in enumerate(self.board) if i not in self.clearing]
        self.board = [[0] * COLS for _ in range(count)] + self.board
        self.score += LINE_SCORES[count] * self.level
        self.lines += count
        self.level = 1 + self.lines // 10
        self.clearing = []
        self._spawn()

    # ---- screen ----
    def grid(self):
        cells = [color for row in self.board for color in row]
        for row in self.clearing:
            cells[row * COLS:(row + 1) * COLS] = [T_FLASH] * COLS
        if self.piece and self.state != OVER:
            kind, rotation, x, y = self.piece
            ghost_y = y
            while self._fits(kind, rotation, x, ghost_y + 1):
                ghost_y += 1
            shape = rotated_cells(kind, rotation)
            for cx, cy in shape:
                cells[(ghost_y + cy) * COLS + x + cx] = T_GHOST
            for cx, cy in shape:
                cells[(y + cy) * COLS + x + cx] = PIECES.index(kind) + 1
        return cells

    def draw_screen(self, d, full):
        if full:
            self.shown = {}
            d.frame(BOARD_X - 2, BOARD_Y - 2, COLS * CELL + 4, ROWS * CELL + 4, GRAY)
            for x, y, label in ((12, 30, "HOLD"), (12, 110, "SCORE"), (12, 170, "BEST"),
                                (12, 230, "LINES"), (326, 30, "NEXT"), (326, 110, "LEVEL")):
                d.text(x, y, label, 2, GRAY)
            for row, line in enumerate(("A / C   rotate", "B       hold", "Stick   move / drop",
                                        "Press   slam", "Tilt fwd  slam")):
                d.text(326, 190 + row * 14, line, 1, GRAY)
        self.board_view.draw(d, self.grid(), full)
        self.next_view.draw(d, preview_tiles(self.queue[0]), full)
        hold = preview_tiles(self.hold)
        if self.hold_used:
            hold = [T_GHOST if t else T_EMPTY for t in hold]  # outlined: already used
        self.hold_view.draw(d, hold, full)
        for key, x, y, value in (("score", 12, 132, self.score),
                                 ("best", 12, 192, max(self.best or 0, self.score)),
                                 ("lines", 12, 252, self.lines), ("level", 326, 132, self.level)):
            if self.shown.get(key) != value:
                d.text(x, y, str(value).ljust(7), 2, YELLOW if key == "score" else WHITE)
                self.shown[key] = value
