"""Sokoban: push every box onto a goal. Boxes can only be pushed, never pulled."""

from arcade import BUTTON_B, BUTTON_C, READY, ArcadeGame, StickRepeat, hud, hud_value
from display import (GRAY, GREEN, WHITE, YELLOW, T_BOX, T_BOX_ON_GOAL, T_EMPTY, T_FLOOR, T_GOAL,
                     T_PLAYER, T_PLAYER_ON_GOAL, T_WALL, GridView)

# '#' wall, '.' goal, '$' box, '*' box on goal, '@' player, '+' player on goal.
LEVELS = [
    ["#####",
     "#@  #",
     "# $ #",
     "#  .#",
     "#####"],
    ["######",
     "#    #",
     "# $$ #",
     "# .. #",
     "#  @ #",
     "######"],
    ["####",
     "# .#",
     "#  ###",
     "#*@  #",
     "#  $ #",
     "#  ###",
     "####"],
    ["######",
     "#    #",
     "# #@ #",
     "# $* #",
     "# .* #",
     "#    #",
     "######"],
    ["  ####",
     "###  ####",
     "#     $ #",
     "# #  #$ #",
     "# . .#@ #",
     "#########"],
    [" #######",
     " #     #",
     " # .$. #",
     "## $@$ #",
     "#  .$. #",
     "#      #",
     "########"],
]
FIELD_Y, FIELD_H = 32, 288
MAX_CELL = 32


def parse(level):
    walls, goals, boxes, player = set(), set(), set(), None
    for y, row in enumerate(level):
        for x, ch in enumerate(row):
            if ch == "#":
                walls.add((x, y))
            if ch in ".*+":
                goals.add((x, y))
            if ch in "$*":
                boxes.add((x, y))
            if ch in "@+":
                player = (x, y)
    # Floor is what the player can reach; spaces outside the walls are drawn as nothing.
    floor, todo = set(), [player]
    while todo:
        cell = todo.pop()
        if cell in floor or cell in walls:
            continue
        floor.add(cell)
        x, y = cell
        todo += [(x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)]
    cols = max(len(row) for row in level)
    return walls, goals, boxes, player, floor, cols, len(level)


class Sokoban(ArcadeGame):
    NAME = "SOKOBAN"

    def __init__(self, rng=None):
        self.level_index = 0
        self.unlocked = 0  # highest level index that may be chosen
        self.solved_index = 0
        self.ready_stick = StickRepeat(0.3, 0.2)
        self.shown = {}
        super().__init__(rng)

    def reset(self):
        level = LEVELS[self.level_index]
        (self.walls, self.goals, self.boxes, self.player, self.floor,
         self.cols, self.rows) = parse(level)
        self.moves = 0
        self.pushes = 0
        self.history = []
        self.stick = StickRepeat(0.25, 0.15)
        size = min(MAX_CELL, 456 // self.cols, FIELD_H // self.rows)
        self.view = GridView(self.cols, self.rows, (480 - self.cols * size) // 2,
                             FIELD_Y + (FIELD_H - self.rows * size) // 2, size)

    def update(self, dt, stick, tilt, buttons, connected):
        if self.state == READY:  # choose any level already reached
            step = self.ready_stick.update(dt, stick)
            if step and step[0]:
                index = max(0, min(self.unlocked, self.level_index + step[0]))
                if index != self.level_index:
                    self.level_index = index
                    self.reset()
                    self.redraw = True
        was = self.state
        super().update(dt, stick, tilt, buttons, connected)
        if was != READY and self.state == READY:
            self.reset()  # show the next level behind the Ready box

    def record(self):
        if self.won:
            self.unlocked = min(len(LEVELS) - 1, max(self.unlocked, self.level_index + 1))
            self.best = max(self.best or 0, self.level_index + 1)
            self.solved_index = self.level_index
            self.level_index = (self.level_index + 1) % len(LEVELS)

    def best_text(self):
        return "-" if self.best is None else f"{self.best}/{len(LEVELS)} levels"

    def box_lines(self):
        if self.state == READY and not self.missing:
            return [(self.NAME, YELLOW), ("Stick: walk and push", WHITE),
                    ("B: undo   C: restart", WHITE),
                    (f"< Level {self.level_index + 1}/{len(LEVELS)} >", GRAY),
                    ("A: start    B: menu", GREEN)]
        return super().box_lines()

    def result_lines(self):
        all_done = self.solved_index == len(LEVELS) - 1
        return [("ALL LEVELS CLEAR!" if all_done else f"LEVEL {self.solved_index + 1} CLEAR!", GREEN),
                (f"Moves:  {self.moves}", WHITE), (f"Pushes: {self.pushes}", WHITE),
                ("C: play next level", GRAY)]

    def status(self):
        return f"{super().status()} level={self.level_index + 1} moves={self.moves}"

    def play(self, dt, stick, tilt, pressed, buttons):
        if pressed & BUTTON_B and self.history:
            self.player, self.boxes, self.moves, self.pushes = self.history.pop()
            return
        if pressed & BUTTON_C:
            self.reset()
            return
        step = self.stick.update(dt, stick)
        if not step:
            return
        x, y = self.player
        target = (x + step[0], y + step[1])
        if target in self.walls:
            return
        boxes = self.boxes
        if target in boxes:
            beyond = (target[0] + step[0], target[1] + step[1])
            if beyond in self.walls or beyond in boxes:
                return
            boxes = (boxes - {target}) | {beyond}
        self.history.append((self.player, self.boxes, self.moves, self.pushes))
        if boxes is not self.boxes:
            self.pushes += 1
        self.boxes = boxes
        self.player = target
        self.moves += 1
        if self.boxes <= self.goals:
            self.finish(won=True)

    def tiles(self):
        tiles = []
        for y in range(self.rows):
            for x in range(self.cols):
                cell = (x, y)
                goal = cell in self.goals
                if cell in self.walls:
                    tile = T_WALL
                elif cell == self.player:
                    tile = T_PLAYER_ON_GOAL if goal else T_PLAYER
                elif cell in self.boxes:
                    tile = T_BOX_ON_GOAL if goal else T_BOX
                elif goal:
                    tile = T_GOAL
                elif cell in self.floor:
                    tile = T_FLOOR
                else:
                    tile = T_EMPTY
                tiles.append(tile)
        return tiles

    def draw_screen(self, d, full):
        if full:
            self.shown = {}
            d.fill(0, FIELD_Y - 2, 480, 1, GRAY)
            for x, label in ((6, "LEVEL"), (186, "MOVES"), (342, "PUSH")):
                hud(d, x, label, "")
        self.view.draw(d, self.tiles(), full)
        values = {"level": f"{self.level_index + 1}/{len(LEVELS)}", "moves": self.moves,
                  "push": self.pushes}
        for key, x, label, width in (("level", 6, "LEVEL", 5), ("moves", 186, "MOVES", 4),
                                     ("push", 342, "PUSH", 4)):
            if self.shown.get(key) != values[key]:
                hud_value(d, x, label, values[key], WHITE, width)
                self.shown[key] = values[key]
