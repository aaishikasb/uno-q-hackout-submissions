"""Minesweeper: open every safe cell. The first cell is always safe; tilt forward for a hint."""

from arcade import BUTTON_A, BUTTON_B, BUTTON_C, OVER, PLAYING, ArcadeGame, StickRepeat, hud, hud_value
from display import (CYAN, GRAY, GREEN, RED, WHITE, YELLOW, T_FLAG, T_HIDDEN, T_MINE, T_MINE_HIT,
                     T_OPEN, T_WRONG_FLAG, GridView)

COLS, ROWS, MINES = 16, 10, 25
CELL, GRID_X, GRID_Y = 28, 16, 34
HINTS = 3
HINT_PENALTY_S = 10
TILT_HINT_MG, TILT_REARM_MG = 600, 250


class Minesweeper(ArcadeGame):
    NAME = "MINESWEEPER"
    HELP = ("A: open   B: flag", "C: open around a number", "Tilt forward: hint (3)")

    def __init__(self, rng=None):
        self.view = GridView(COLS, ROWS, GRID_X, GRID_Y, CELL)
        self.shown = {}
        super().__init__(rng)

    def reset(self):
        self.mines = set()
        self.opened = set()
        self.flags = set()
        self.exploded = None
        self.cursor = (COLS // 2, ROWS // 2)
        self.stick = StickRepeat(0.25, 0.1)
        self.elapsed = 0.0
        self.started = False
        self.hints = HINTS
        self.tilt_armed = True

    def record(self):
        if self.won:
            seconds = int(self.elapsed)
            self.best = seconds if self.best is None else min(self.best, seconds)

    def best_text(self):
        return "-" if self.best is None else f"{self.best}s"

    def result_lines(self):
        if self.won:
            return [("CLEARED!", GREEN), (f"Time: {int(self.elapsed)}s", WHITE),
                    (f"Best: {self.best}s", GREEN if int(self.elapsed) == self.best else WHITE),
                    (f"Hints used: {HINTS - self.hints}", GRAY)]
        left = len(self.mines - self.flags)
        return [("BOOM!", RED), (f"Time: {int(self.elapsed)}s", WHITE),
                (f"Mines left: {left}", WHITE), ("Best: " + self.best_text(), GRAY)]

    def status(self):
        return f"{super().status()} time={int(self.elapsed)} opened={len(self.opened)}"

    # ---- rules ----
    @staticmethod
    def neighbours(cell):
        x, y = cell
        return [(x + dx, y + dy) for dy in (-1, 0, 1) for dx in (-1, 0, 1)
                if (dx or dy) and 0 <= x + dx < COLS and 0 <= y + dy < ROWS]

    def count(self, cell):
        return sum(n in self.mines for n in self.neighbours(cell))

    def _lay_mines(self, first):
        safe = set(self.neighbours(first)) | {first}
        cells = [(x, y) for y in range(ROWS) for x in range(COLS) if (x, y) not in safe]
        self.mines = set(self.rng.sample(cells, MINES))
        self.started = True

    def _open(self, cell):
        if cell in self.opened or cell in self.flags:
            return
        if cell in self.mines:
            self.exploded = cell
            self.finish()
            return
        todo = [cell]
        while todo:  # flood-fill through cells with no neighbouring mines
            current = todo.pop()
            if current in self.opened or current in self.flags:
                continue
            self.opened.add(current)
            if self.count(current) == 0:
                todo += [n for n in self.neighbours(current) if n not in self.opened]

    def _check_win(self):
        if self.state == PLAYING and len(self.opened) == COLS * ROWS - MINES:
            self.flags = set(self.mines)
            self.finish(won=True)

    def play(self, dt, stick, tilt, pressed, buttons):
        if self.started:
            self.elapsed += dt
        step = self.stick.update(dt, stick)
        if step:
            x, y = self.cursor
            self.cursor = (max(0, min(COLS - 1, x + step[0])), max(0, min(ROWS - 1, y + step[1])))

        if pressed & BUTTON_A:
            if not self.started:
                self._lay_mines(self.cursor)
            self._open(self.cursor)
        elif pressed & BUTTON_B and self.cursor not in self.opened:
            self.flags ^= {self.cursor}
        elif pressed & BUTTON_C and self.cursor in self.opened:
            around = self.neighbours(self.cursor)
            if sum(n in self.flags for n in around) == self.count(self.cursor):
                for n in around:
                    if self.state == PLAYING:
                        self._open(n)

        if self.tilt_armed and tilt[1] > TILT_HINT_MG:
            self.tilt_armed = False
            self._hint()
        elif tilt[1] < TILT_REARM_MG:
            self.tilt_armed = True
        self._check_win()

    def _hint(self):
        if not self.started or not self.hints:
            return
        safe = [(x, y) for y in range(ROWS) for x in range(COLS)
                if (x, y) not in self.mines and (x, y) not in self.opened]
        if safe:
            self.hints -= 1
            self.elapsed += HINT_PENALTY_S
            # Prefer a cell next to what is already open: that is where players get stuck.
            near = [c for c in safe if any(n in self.opened for n in self.neighbours(c))]
            self.cursor = self.rng.choice(near or safe)
            self.flags.discard(self.cursor)
            self._open(self.cursor)

    # ---- screen ----
    def tiles(self):
        over = self.state == OVER
        tiles = []
        for y in range(ROWS):
            for x in range(COLS):
                cell = (x, y)
                if cell in self.opened:
                    n = self.count(cell)
                    tile = T_OPEN + n if n else T_OPEN  # 22-29 show the number
                elif over and cell == self.exploded:
                    tile = T_MINE_HIT
                elif cell in self.flags:
                    tile = T_WRONG_FLAG if over and cell not in self.mines else T_FLAG
                elif over and cell in self.mines:
                    tile = T_MINE
                else:
                    tile = T_HIDDEN
                tiles.append(tile)
        return tiles

    def draw_screen(self, d, full):
        if full:
            self.shown = {}
            for x, label in ((6, "MINES"), (162, "TIME"), (306, "HINTS")):
                hud(d, x, label, "")
        tiles = self.tiles()
        old_cursor = self.shown.get("cursor")
        index = self.cursor[1] * COLS + self.cursor[0]
        if old_cursor is not None and old_cursor != self.cursor and self.view.shown:
            self.view.shown[old_cursor[1] * COLS + old_cursor[0]] = None  # repaint, removing the frame
        tile_changed = not self.view.shown or self.view.shown[index] != tiles[index]
        self.view.draw(d, tiles, full)
        if full or tile_changed or old_cursor != self.cursor:
            x, y = self.view.cell_xy(index)
            d.frame(x, y, CELL, CELL, YELLOW)
            d.frame(x + 1, y + 1, CELL - 2, CELL - 2, YELLOW)
            self.shown["cursor"] = self.cursor

        values = {"mines": MINES - len(self.flags), "time": int(self.elapsed), "hints": self.hints}
        for key, x, label, width, color in (("mines", 6, "MINES", 3, RED), ("time", 162, "TIME", 4, WHITE),
                                            ("hints", 306, "HINTS", 1, CYAN)):
            if self.shown.get(key) != values[key]:
                hud_value(d, x, label, values[key], color, width)
                self.shown[key] = values[key]
