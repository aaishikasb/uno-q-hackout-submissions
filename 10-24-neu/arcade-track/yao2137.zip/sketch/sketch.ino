#include <Arduino.h>
#include <Arduino_RouterBridge.h>
#include <Arduino_Modulino.h>
#include <DIYables_TFT_Touch_Shield.h>
#include <math.h>
#include "video_protocol.h"

#if !defined(ARDUINO_UNO_Q)
#error "Select Arduino UNO Q for this starter."
#endif

// Hosts select the controller fitted to their preassembled consoles.
#ifndef ARCADE_TFT_HX8357D
#define ARCADE_TFT_HX8357D 1
#endif
#if ARCADE_TFT_HX8357D
DIYables_TFT_HX8357D_Shield display;
#else
DIYables_TFT_RM68140_Shield display;
#endif

const uint8_t BUTTONS_ADDRESS = 0x3E;
const uint8_t JOYSTICK_ADDRESS = 0x2C;
ModulinoButtons buttons(BUTTONS_ADDRESS);
ModulinoMovement movement;
bool movementReady = false;

const uint16_t TFT_BLACK = 0x0000;
const uint16_t TFT_WHITE = 0xFFFF;
const uint16_t TFT_CYAN = 0x07FF;
unsigned long lastFrameAt = 0;
bool waiting = true;
int videoSession = 0;
int nextVideoSession = 0;
int lastX = -1;
int lastY = -1;

// The Python games draw through arcade_draw; any screen the MCU draws itself bumps the
// epoch so Python knows its picture was replaced and redraws everything.
bool pythonScreen = false;
int screenEpoch = 0;

bool readPacket(uint8_t address, uint8_t payload[3]) {
  // update() means "changed", not "read succeeded"; reject incomplete wire packets.
  int count = Wire1.requestFrom(address, (uint8_t)4);
  if (count != 4) {
    while (Wire1.available()) Wire1.read();
    return false;
  }
  Wire1.read();  // Modulino pinstrap address precedes the three input bytes.
  for (int i = 0; i < 3; ++i) payload[i] = Wire1.read();
  return true;
}

String readInputs() {
  uint8_t buttonData[3] = {};
  uint8_t stickData[3] = {};
  bool buttonsOk = readPacket(BUTTONS_ADDRESS, buttonData);
  bool joystickOk = readPacket(JOYSTICK_ADDRESS, stickData);
  bool movementOk = movementReady && movement.update();
  float ax = movementOk ? movement.getX() : 0;
  float ay = movementOk ? movement.getY() : 0;
  float az = movementOk ? movement.getZ() : 0;
  movementOk = movementOk && isfinite(ax) && isfinite(ay) && isfinite(az);
  int connected = (buttonsOk ? 1 : 0) | (joystickOk ? 2 : 0) | (movementOk ? 4 : 0);
  int pressed = 0;
  if (buttonsOk) {
    for (int i = 0; i < 3; ++i) if (buttonData[i]) pressed |= 1 << i;
    buttons.setLeds(buttonData[0], buttonData[1], buttonData[2]);
  }
  if (joystickOk && stickData[2]) pressed |= 8;
  char json[180];
  snprintf(json, sizeof(json),
           "{\"video\":%d,\"connected\":%d,\"buttons\":%d,\"x\":%d,\"y\":%d,"
           "\"ax\":%d,\"ay\":%d,\"az\":%d}",
           videoSession, connected, pressed,
           joystickOk ? 128 - (int)stickData[0] : 0,
           joystickOk ? 128 - (int)stickData[1] : 0,
           movementOk ? (int)(constrain(ax, -16.0f, 16.0f) * 1000) : 0,
           movementOk ? (int)(constrain(ay, -16.0f, 16.0f) * 1000) : 0,
           movementOk ? (int)(constrain(az, -16.0f, 16.0f) * 1000) : 0);
  return String(json);
}

void textLine(int y, const char* text) {
  display.setCursor(12, y);
  display.setTextColor(TFT_WHITE, TFT_BLACK);
  display.print(text);
}

void showWaiting() {
  screenEpoch++;
  display.setTextSize(2);
  if (videoSession || pythonScreen) {
    videoSession = 0;
    pythonScreen = false;
    display.fillScreen(TFT_BLACK);
    textLine(10, "UNO Q arcade starter");
    display.drawRect(12, 160, 456, 148, TFT_WHITE);
  }
  display.fillRect(12, 36, 456, 112, TFT_BLACK);
  textLine(36, "Waiting for App Lab...");
  if (lastX >= 0) display.fillCircle(lastX, lastY, 6, TFT_BLACK);
  lastX = -1;
  waiting = true;
}

bool drawFrame(int x, int y, int pressed, int ax, int ay, int az, int connected) {
  if (videoSession) return false;  // RetroArch owns the display until release/timeout.
  if (pythonScreen) showWaiting();  // restore the preview layout
  // Bound every RPC input before using it for drawing or bit masks.
  x = constrain(x, 20, 460);
  y = constrain(y, 168, 300);
  pressed &= 15;
  connected &= 7;
  if (!(connected & 1)) pressed &= 8;
  if (!(connected & 2)) { pressed &= 7; x = 240; y = 234; }
  if (!(connected & 4)) { ax = 0; ay = 0; az = 0; }
  ax = constrain(ax, -16000, 16000);
  ay = constrain(ay, -16000, 16000);
  az = constrain(az, -16000, 16000);
  if (waiting) display.fillRect(12, 36, 456, 112, TFT_BLACK);
  char line[40];
  snprintf(line, sizeof(line), "Buttons:%s Stick:%s IMU:%s  ",
           connected & 1 ? "OK" : "--", connected & 2 ? "OK" : "--",
           connected & 4 ? "OK" : "--");
  textLine(36, line);
  snprintf(line, sizeof(line), "A:%d  B:%d  C:%d  Stick press:%d ",
           !!(pressed & 1), !!(pressed & 2), !!(pressed & 4), !!(pressed & 8));
  textLine(64, line);
  textLine(92, "Motion from neutral (mg)");
  snprintf(line, sizeof(line), "%6d / %6d / %6d   ", ax, ay, az);
  textLine(120, line);
  if (lastX >= 0) display.fillCircle(lastX, lastY, 6, TFT_BLACK);
  display.fillCircle(x, y, 6, pressed ? TFT_WHITE : TFT_CYAN);
  lastX = x;
  lastY = y;
  lastFrameAt = millis();
  waiting = false;
  return true;
}

int beginVideo() {
  if (videoSession) return 0;  // Only one stream may own the display.
  nextVideoSession = nextVideoSession == 2147483647 ? 1 : nextVideoSession + 1;
  videoSession = nextVideoSession;
  pythonScreen = false;
  screenEpoch++;
  display.setTextSize(2);
  display.fillScreen(TFT_BLACK);
  textLine(10, "RetroArch / TFT bridge");
  textLine(294, "C + stick press: menu");
  lastX = -1;
  lastFrameAt = millis();
  waiting = false;
  return videoSession;
}

String pollVideo(int session) {
  if (!videoSession || session != videoSession) return String("");
  String inputs = readInputs();
  lastFrameAt = millis();
  return inputs;
}

String videoTile(int session, int tile, MsgPack::bin_t<uint8_t> data) {
  static uint16_t pixels[ArcadeVideo::TILE_PIXELS * 4];
  if (!videoSession || session != videoSession ||
      !ArcadeVideo::decode(tile, data.data(), data.size(), pixels)) return String("");
  display.drawRGBBitmap(80 + (tile % 10) * 32, 40 + (tile / 10) * 16, pixels, 32, 16);
  return pollVideo(session);  // Return fresh controls after each acknowledged tile.
}

bool endVideo(int session) {
  if (!videoSession || session != videoSession) return false;
  showWaiting();
  return true;
}

// ---- Display list renderer: the games in python/ draw every screen through this. ----
// Indices match python/display.py.
const uint16_t PALETTE[16] = {
    0x0000, 0x07FF, 0xFFE0, 0xA01F, 0x07E0, 0xF800, 0x235F, 0xFC00,  // black cyan yellow purple green red blue orange
    0x8410, 0xFFFF, 0x4208, 0xC618, 0x9A60, 0x0400, 0x000F, 0xF81F,  // gray white dark light brown dkgreen navy magenta
};
enum { C_BLACK, C_CYAN, C_YELLOW, C_PURPLE, C_GREEN, C_RED, C_BLUE, C_ORANGE,
       C_GRAY, C_WHITE, C_DARK, C_LIGHT, C_BROWN, C_DARK_GREEN, C_NAVY, C_MAGENTA };
enum { OP_CLEAR = 1, OP_FILL, OP_FRAME, OP_TEXT, OP_DISC, OP_TILE };
enum { T_EMPTY = 0, T_GHOST = 8, T_FLASH = 9, T_WALL, T_FLOOR, T_GOAL, T_BOX, T_BOX_ON_GOAL,
       T_PLAYER, T_PLAYER_ON_GOAL, T_SNAKE, T_SNAKE_HEAD, T_APPLE, T_HIDDEN, T_OPEN,
       T_FLAG = 30, T_MINE_HIT, T_MINE, T_WRONG_FLAG };
const uint8_t NUMBER_COLORS[8] = {C_BLUE, C_GREEN, C_RED, C_MAGENTA, C_ORANGE, C_CYAN, C_WHITE, C_LIGHT};

uint16_t color(uint8_t index) { return PALETTE[index & 15]; }
uint16_t u16(const uint8_t* p) { return p[0] | (p[1] << 8); }

bool clipRect(int& x, int& y, int& w, int& h) {
  if (x < 0) { w += x; x = 0; }
  if (y < 0) { h += y; y = 0; }
  if (x + w > 480) w = 480 - x;
  if (y + h > 320) h = 320 - y;
  return w > 0 && h > 0;
}

void raisedCell(int x, int y, int s) {
  display.fillRect(x, y, s, s, color(C_LIGHT));
  display.drawFastHLine(x, y, s, color(C_WHITE));
  display.drawFastVLine(x, y, s, color(C_WHITE));
  display.drawFastHLine(x, y + s - 1, s, color(C_GRAY));
  display.drawFastVLine(x + s - 1, y, s, color(C_GRAY));
}

void openCell(int x, int y, int s) {
  display.fillRect(x, y, s, s, color(C_DARK));
  display.drawRect(x, y, s, s, color(C_BLACK));
}

void goalMark(int x, int y, int s) {
  int c = s / 2, r = s / 4;
  display.drawRect(x + c - r, y + c - r, 2 * r + 1, 2 * r + 1, color(C_YELLOW));
  display.drawRect(x + c - r + 1, y + c - r + 1, 2 * r - 1, 2 * r - 1, color(C_YELLOW));
}

void drawTile(int x, int y, int s, uint8_t tile) {
  if (x < 0 || y < 0 || s < 6 || x + s > 480 || y + s > 320) return;
  int c = s / 2;
  if (tile >= 22 && tile <= 29) {  // open Minesweeper cell showing 1-8
    openCell(x, y, s);
    int size = s >= 24 ? 2 : 1;
    display.drawChar(x + (s - 5 * size) / 2, y + (s - 7 * size) / 2, '1' + tile - 22,
                     color(NUMBER_COLORS[tile - 22]), color(C_DARK), size);
    return;
  }
  if (tile >= 1 && tile <= T_FLASH && tile != T_GHOST) {  // Tetris blocks
    display.fillRect(x, y, s, s, color(C_BLACK));
    display.fillRect(x + 1, y + 1, s - 2, s - 2, color(tile == T_FLASH ? C_WHITE : tile));
    return;
  }
  switch (tile) {
    case T_GHOST:
      display.fillRect(x, y, s, s, color(C_BLACK));
      display.drawRect(x + 1, y + 1, s - 2, s - 2, color(C_GRAY));
      break;
    case T_WALL:  // bricks
      display.fillRect(x, y, s, s, color(C_GRAY));
      display.drawRect(x, y, s, s, color(C_DARK));
      display.drawFastHLine(x, y + c, s, color(C_DARK));
      display.drawFastVLine(x + s / 3, y, c, color(C_DARK));
      display.drawFastVLine(x + 2 * s / 3, y + c, s - c, color(C_DARK));
      break;
    case T_FLOOR:
      display.fillRect(x, y, s, s, color(C_BLACK));
      display.fillRect(x + c - 1, y + c - 1, 2, 2, color(C_DARK));
      break;
    case T_GOAL:
      display.fillRect(x, y, s, s, color(C_BLACK));
      goalMark(x, y, s);
      break;
    case T_BOX:
    case T_BOX_ON_GOAL: {
      uint16_t fill = color(tile == T_BOX ? C_BROWN : C_DARK_GREEN);
      uint16_t edge = color(tile == T_BOX ? C_ORANGE : C_GREEN);
      display.fillRect(x, y, s, s, color(C_BLACK));
      display.fillRect(x + 2, y + 2, s - 4, s - 4, fill);
      display.drawRect(x + 2, y + 2, s - 4, s - 4, edge);
      display.drawLine(x + 3, y + 3, x + s - 4, y + s - 4, edge);
      display.drawLine(x + s - 4, y + 3, x + 3, y + s - 4, edge);
      break;
    }
    case T_PLAYER:
    case T_PLAYER_ON_GOAL:
      display.fillRect(x, y, s, s, color(C_BLACK));
      if (tile == T_PLAYER_ON_GOAL) goalMark(x, y, s);
      display.fillCircle(x + c, y + c, s / 2 - 3, color(C_CYAN));
      display.fillRect(x + c - 3, y + c - 2, 2, 2, color(C_BLACK));
      display.fillRect(x + c + 2, y + c - 2, 2, 2, color(C_BLACK));
      break;
    case T_SNAKE:
    case T_SNAKE_HEAD:
      display.fillRect(x, y, s, s, color(C_BLACK));
      display.fillRect(x + 1, y + 1, s - 2, s - 2, color(tile == T_SNAKE ? C_DARK_GREEN : C_GREEN));
      if (tile == T_SNAKE_HEAD) {
        display.fillRect(x + s / 3 - 1, y + s / 3, 2, 2, color(C_BLACK));
        display.fillRect(x + 2 * s / 3, y + s / 3, 2, 2, color(C_BLACK));
      }
      break;
    case T_APPLE:
      display.fillRect(x, y, s, s, color(C_BLACK));
      display.fillCircle(x + c, y + c + 1, s / 2 - 3, color(C_RED));
      display.fillRect(x + c, y + 1, 2, 3, color(C_GREEN));
      break;
    case T_HIDDEN:
      raisedCell(x, y, s);
      break;
    case T_OPEN:
      openCell(x, y, s);
      break;
    case T_FLAG:
      raisedCell(x, y, s);
      display.drawFastVLine(x + c, y + s / 4, s / 2, color(C_BLACK));
      display.fillTriangle(x + c, y + s / 4, x + c, y + s / 2, x + c - s / 3, y + 3 * s / 8, color(C_RED));
      display.drawFastHLine(x + s / 4, y + 3 * s / 4, s / 2, color(C_BLACK));
      break;
    case T_MINE_HIT:
    case T_MINE:
      if (tile == T_MINE_HIT) display.fillRect(x, y, s, s, color(C_RED));
      else openCell(x, y, s);
      display.fillCircle(x + c, y + c, s / 4 + 1, color(C_BLACK));
      break;
    case T_WRONG_FLAG:
      raisedCell(x, y, s);
      display.drawLine(x + 4, y + 4, x + s - 5, y + s - 5, color(C_RED));
      display.drawLine(x + s - 5, y + 4, x + 4, y + s - 5, color(C_RED));
      break;
    default:  // T_EMPTY and unknown tiles
      display.fillRect(x, y, s, s, color(C_BLACK));
  }
}

// data: a sequence of ops, little-endian 16-bit coordinates (see python/display.py).
int arcadeDraw(MsgPack::bin_t<uint8_t> data) {
  if (videoSession) return -1;  // RetroArch owns the display until release/timeout.
  pythonScreen = true;
  lastX = -1;  // the preview marker is gone
  const uint8_t* p = data.data();
  size_t n = data.size(), i = 0;
  while (i < n) {
    uint8_t op = p[i];
    size_t need = op == OP_CLEAR ? 2 : (op == OP_FILL || op == OP_FRAME) ? 10
                : (op == OP_DISC || op == OP_TILE) ? 7 : op == OP_TEXT ? 9 : 0;
    if (!need || i + need > n) break;
    if (op == OP_TEXT) {
      need += p[i + 8];
      if (i + need > n) break;
    }
    const uint8_t* a = p + i + 1;
    int x = u16(a), y = u16(a + 2);
    switch (op) {
      case OP_CLEAR:
        display.fillScreen(color(a[0]));
        break;
      case OP_FILL:
      case OP_FRAME: {
        int w = u16(a + 4), h = u16(a + 6);
        if (!clipRect(x, y, w, h)) break;
        if (op == OP_FILL) display.fillRect(x, y, w, h, color(a[8]));
        else display.drawRect(x, y, w, h, color(a[8]));
        break;
      }
      case OP_TEXT: {
        int size = constrain(a[4], 1, 4);
        display.setTextSize(size);
        if (a[5] == a[6]) display.setTextColor(color(a[5]));  // transparent
        else display.setTextColor(color(a[5]), color(a[6]));
        display.setCursor(x, y);
        for (int k = 0; k < a[7]; ++k) display.write(a[8 + k]);
        break;
      }
      case OP_DISC: {
        int r = constrain(a[4], 1, 40);
        if (x >= r && y >= r && x + r < 480 && y + r < 320) display.fillCircle(x, y, r, color(a[5]));
        break;
      }
      case OP_TILE:
        drawTile(x, y, a[4], a[5]);
        break;
    }
    i += need;
  }
  display.setTextSize(2);
  lastFrameAt = millis();
  waiting = false;
  return screenEpoch;
}

void setup() {
  display.begin();
  display.setRotation(1);  // Landscape: 480 x 320.
  display.fillScreen(TFT_BLACK);
  display.setTextSize(2);
  display.setTextWrap(false);
  textLine(10, "UNO Q arcade starter");
  // Boot stages stay on screen so a hang shows where it stopped.
  textLine(36, "1/3 Starting Bridge...");
  // Register RPC methods before the Modulinos so a slow I2C bus cannot hide them from Python.
  bool bridgeOk = Bridge.begin();
  if (bridgeOk) {
    Bridge.provide_safe("arcade_read_inputs", readInputs);
    Bridge.provide_safe("arcade_draw_frame", drawFrame);
    Bridge.provide_safe("arcade_draw", arcadeDraw);
    Bridge.provide_safe("arcade_video_begin", beginVideo);
    Bridge.provide_safe("arcade_video_tile", videoTile);
    Bridge.provide_safe("arcade_video_poll", pollVideo);
    Bridge.provide_safe("arcade_video_end", endVideo);
  }
  textLine(36, "2/3 Starting Modulinos...");
  Modulino.begin(Wire1);
  buttons.begin();
  movementReady = movement.begin();
  textLine(36, "3/3 Ready                 ");
  display.drawRect(12, 160, 456, 148, TFT_WHITE);
  showWaiting();
  if (!bridgeOk) textLine(36, "Bridge failed: restart app");
}

void loop() {
  if (!waiting && millis() - lastFrameAt > 1500) showWaiting();
  delay(5);
}
