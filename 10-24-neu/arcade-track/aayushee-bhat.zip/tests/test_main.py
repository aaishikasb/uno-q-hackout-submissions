import json
from pathlib import Path
import runpy
import sys
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, call, patch


PYTHON = Path(__file__).resolve().parents[1] / "python"
INPUTS = {"connected": 3, "buttons": 0, "x": 0, "y": 0}


class ControlLoopTests(unittest.TestCase):
    def setUp(self):
        self.now = 100.0
        self.response = json.dumps(INPUTS)
        self.draw_result = True
        self.bridge = Mock()
        self.bridge.call.side_effect = self.rpc
        self.app = Mock()
        self.output = self.enterContext(patch("builtins.print"))
        game_module = SimpleNamespace(**runpy.run_path(str(PYTHON / "game.py")))
        app_utils = SimpleNamespace(App=self.app, Bridge=self.bridge)
        with patch.dict(sys.modules, {"arduino.app_utils": app_utils,
                                      "game": game_module}), \
                patch("time.monotonic", return_value=self.now):
            self.loop = runpy.run_path(str(PYTHON / "main.py"))["loop"]
        self.sleep = Mock()
        self.loop.__globals__["time"] = SimpleNamespace(
            sleep=self.sleep, monotonic=lambda: self.now)
        self.game = self.loop.__globals__["game"]
        self.game.rng.seed(7)
        self.game.reset()
        self.output.reset_mock()

    def rpc(self, name, *args):
        if name == "read_inputs":
            if isinstance(self.response, Exception):
                raise self.response
            return self.response
        if name == "draw_snake":
            return self.draw_result
        self.fail(f"Unexpected RPC: {name}")

    def frame(self, elapsed=0, **inputs):
        self.now += elapsed
        self.response = json.dumps({**INPUTS, **inputs})
        self.loop()

    def start(self):
        self.frame()
        self.frame(buttons=1)
        self.frame()
        self.assertEqual(self.game.state, "playing")

    def assert_recovery_gate(self, board):
        self.assertEqual(self.game.state, "paused")
        self.assertFalse(self.loop.__globals__["controls_ready"])
        self.frame(buttons=1, x=70, elapsed=10)
        self.assertEqual(self.game.state, "paused")
        self.assertFalse(self.loop.__globals__["controls_ready"])
        self.frame()
        self.assertTrue(self.loop.__globals__["controls_ready"])
        self.frame(elapsed=10)
        self.assertEqual(self.game.state, "paused")
        self.assertEqual(self.game.board(), board)
        self.frame(buttons=1)
        self.assertEqual(self.game.state, "playing")
        self.assertEqual(self.game.board(), board)
        self.frame()

    def test_startup_waits_for_released_buttons_and_neutral_stick(self):
        self.app.run.assert_called_once_with(user_loop=self.loop)
        board = self.game.board()
        for inputs in ({"buttons": 1}, {"x": 70}, {"buttons": 8}, {"buttons": 4}):
            self.frame(elapsed=10, **inputs)
            self.assertFalse(self.loop.__globals__["controls_ready"])
            self.assertEqual(self.game.state, "ready")
            self.assertEqual(self.game.board(), board)
        self.frame(x=25, y=-25)
        self.assertTrue(self.loop.__globals__["controls_ready"])
        self.assertEqual(len(board), 264)
        packed = self.game.packed_board()
        self.assertEqual(len(packed), 132)
        self.assertLessEqual(set(packed), set("ABCDEFGHIJKLMNOPQRSTUVWXY"))
        self.bridge.call.assert_called_with("draw_snake", packed, 0, 0, 0, 0, 7)

    def test_a_and_stick_press_toggle_only_on_new_press(self):
        self.frame()
        self.frame(buttons=1)
        self.frame(buttons=1)
        self.assertEqual(self.game.state, "playing")
        self.frame()
        self.frame(buttons=8)
        self.frame(buttons=8)
        self.assertEqual(self.game.state, "paused")
        self.frame()
        self.frame(buttons=8)
        self.assertEqual(self.game.state, "playing")

    def test_pause_and_resume_restart_the_step_clock(self):
        self.start()
        board = self.game.board()
        self.frame(elapsed=0.2)
        self.frame(buttons=1)
        self.frame(elapsed=20)
        self.assertEqual(self.game.state, "paused")
        self.assertEqual(self.game.board(), board)
        self.frame(buttons=1)
        self.frame(elapsed=0.2)
        self.assertEqual(self.game.state, "playing")
        self.assertEqual(self.game.board(), board)
        self.frame(elapsed=0.1)
        self.assertEqual(self.game.snake[0], 144)

    def test_restart_takes_priority_and_preserves_best(self):
        self.start()
        self.game.score, self.game.best = 20, 30
        self.frame(buttons=15, x=70, elapsed=10)
        self.assertEqual((self.game.state, self.game.score, self.game.best),
                         ("ready", 0, 30))
        board = self.game.board()
        self.frame(buttons=15, elapsed=10)
        self.assertEqual(self.game.state, "ready")
        self.assertEqual(self.game.board(), board)
        self.frame()
        self.frame(buttons=1)
        self.assertEqual(self.game.state, "playing")

    def test_joystick_uses_calibrated_axes_dead_zone_and_dominant_axis(self):
        self.start()
        with patch.object(self.game, "turn", return_value=True) as turn:
            self.frame(x=25, y=-25)
            turn.assert_not_called()
            for inputs in ({"x": 26}, {"x": -70}, {"y": 70}, {"y": -70},
                           {"x": -70, "y": -70}, {"x": 50, "y": 80}):
                self.frame(**inputs)
            self.assertEqual(turn.call_args_list,
                             [call(0), call(2), call(3), call(1), call(2), call(3)])

    def test_missing_controls_pause_and_require_neutral_then_explicit_resume(self):
        self.start()
        board = self.game.board()
        for connected in (0, 1, 2):
            with self.subTest(connected=connected):
                self.frame(connected=connected, buttons=15, x=70, elapsed=10)
                self.bridge.call.assert_called_with(
                    "draw_snake", self.game.packed_board(), 0, 0, 0, 2, connected)
                self.assert_recovery_gate(board)

    def test_invalid_input_pauses_and_requires_neutral_then_explicit_resume(self):
        invalid = [None, 7, {}, [], "not JSON", "[]", "null", "{}",
                   OSError("bridge unavailable")]
        for key, low, high in (("connected", 0, 3), ("buttons", 0, 15),
                               ("x", -127, 128), ("y", -127, 128)):
            for value in (low - 1, high + 1, True, 0.0, "0", None):
                invalid.append(json.dumps({**INPUTS, key: value}))
        self.start()
        board = self.game.board()
        for response in invalid:
            with self.subTest(response=response):
                self.bridge.reset_mock()
                self.output.reset_mock()
                self.response = response
                self.loop()
                self.bridge.call.assert_called_once_with("read_inputs")
                self.sleep.assert_called_with(1)
                self.assertTrue(self.output.call_args.args[0].startswith(
                    "Poison Snake connection/input error:"))
                self.assert_recovery_gate(board)

    def test_delayed_frame_advances_only_one_cell(self):
        self.start()
        self.frame(elapsed=60)
        self.assertEqual(self.game.snake[0], 144)
        self.frame()
        self.assertEqual(self.game.snake[0], 144)
        self.frame(elapsed=self.game.interval)
        self.assertEqual(self.game.snake[0], 145)

    def test_rejected_draw_pauses_and_requires_neutral_then_explicit_resume(self):
        self.start()
        board = self.game.board()
        for rejected in (False, None, 1, "true"):
            with self.subTest(rejected=rejected):
                self.draw_result = rejected
                self.frame()
                self.sleep.assert_called_with(1)
                self.output.assert_called_with(
                    "Poison Snake connection/input error: TFT rejected the snake frame",
                    flush=True)
                self.draw_result = True
                self.assert_recovery_gate(board)

    def test_unchanged_frames_send_heartbeat_and_all_states_are_encoded(self):
        board = self.game.packed_board()
        encoded = json.dumps(INPUTS).encode()
        for response in (encoded.decode(), encoded, bytearray(encoded)):
            self.response = response
            self.loop()
        self.assertEqual(self.bridge.call.call_args_list, [
            item for _ in range(3) for item in (
                call("read_inputs"), call("draw_snake", board, 0, 0, 0, 0, 7))])
        self.assertEqual(self.sleep.call_args_list, [call(0.03)] * 3)
        self.output.assert_not_called()
        for state, reason, code in (("playing", "", 1), ("paused", "", 2),
                                    ("over", "wall", 3), ("over", "body", 4),
                                    ("over", "poison", 5), ("won", "", 6)):
            with self.subTest(state=state, reason=reason):
                self.game.state, self.game.reason = state, reason
                self.frame()
                self.bridge.call.assert_called_with(
                    "draw_snake", board, 0, 0, 0, code, 7)


if __name__ == "__main__":
    unittest.main()
