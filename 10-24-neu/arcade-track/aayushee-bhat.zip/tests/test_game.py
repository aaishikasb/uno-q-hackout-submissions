from pathlib import Path
import random
import sys
import unittest


sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "python"))
from game import COLS, ROWS, Game


class GameTests(unittest.TestCase):
    def setUp(self):
        self.game = Game(random.Random(7))

    def assert_spawns_valid(self):
        game = self.game
        self.assertEqual(len(game.snake), len(set(game.snake)))
        self.assertEqual(len(game.poisons), len(set(game.poisons)))
        self.assertFalse(set(game.snake) & set(game.poisons))
        if game.fruit is not None:
            self.assertNotIn(game.fruit, game.snake + game.poisons)
        self.assertTrue(all(0 <= c < COLS * ROWS for c in game.snake + game.poisons))

    def assert_packed_round_trip(self):
        packed = self.game.packed_board()
        self.assertEqual(len(packed.encode("ascii")), 132)
        self.assertTrue(all("A" <= cell <= "Y" for cell in packed))
        decoded = "".join(".sHfp"[(ord(cell) - 65) // 5] + ".sHfp"[(ord(cell) - 65) % 5]
                          for cell in packed)
        self.assertEqual(decoded, self.game.board())

    def test_packed_board_covers_all_twenty_five_pairs(self):
        pairs = "".join(a + b for a in ".sHfp" for b in ".sHfp")
        self.game.board = lambda: pairs + "." * (COLS * ROWS - len(pairs))
        self.assertEqual(self.game.packed_board()[:25], "ABCDEFGHIJKLMNOPQRSTUVWXY")
        self.assert_packed_round_trip()

    def test_packed_board_round_trips_ready_and_growing_games(self):
        for seed in range(100):
            self.game = Game(random.Random(seed))
            self.assert_packed_round_trip()
            self.game.start_pause()
            self.game.fruit = self.game.snake[0] + 1
            self.game.step()
            self.assert_packed_round_trip()

    def test_initial_board_is_ready_and_centered(self):
        game = self.game
        self.assertEqual(game.state, "ready")
        self.assertEqual(game.snake, [143, 142, 141, 140, 139])
        self.assertEqual((game.direction, game.score, game.best, game.reason), (0, 0, 0, ""))
        self.assertEqual(len(game.poisons), 3)
        self.assertFalse(set(game.poisons) & {144, 145, 146})
        self.assert_spawns_valid()
        board = game.board()
        self.assertEqual(len(board), COLS * ROWS)
        self.assertEqual((board.count("H"), board.count("s"), board.count("f")), (1, 4, 1))
        self.assertLessEqual(set(board), set(".sHfp"))

    def test_seeded_randomness_is_repeatable(self):
        self.assertEqual(self.game.fruit, Game(random.Random(7)).fruit)

    def test_initial_spawns_are_disjoint_and_leave_runway_across_seeds(self):
        for seed in range(100):
            self.game = Game(random.Random(seed))
            self.assert_spawns_valid()
            self.assertEqual(len(self.game.poisons), 3)
            self.assertFalse(set(self.game.poisons) & {144, 145, 146})

    def test_inactive_step_and_pause_do_not_move(self):
        game = self.game
        before = game.board()
        self.assertFalse(game.step())
        game.start_pause()
        self.assertEqual(game.state, "playing")
        game.start_pause()
        self.assertEqual(game.state, "paused")
        self.assertFalse(game.step())
        self.assertFalse(game.turn(1))
        self.assertEqual(game.board(), before)
        game.start_pause()
        game.fruit = 0
        self.assertTrue(game.step())
        self.assertEqual(game.snake, [144, 143, 142, 141, 140])

    def test_one_turn_per_step_and_no_reverse(self):
        game = self.game
        game.start_pause()
        self.assertFalse(game.turn(2))
        self.assertTrue(game.turn(0))
        self.assertTrue(game.turn(1))
        self.assertFalse(game.turn(2))
        self.assertEqual(game.direction, 1)
        game.fruit = 0
        game.step()
        self.assertEqual(game.snake[0], 165)
        self.assertTrue(game.turn(2))
        game.step()
        self.assertEqual(game.snake[0], 164)

    def test_turn_rejects_invalid_values(self):
        for value in (-1, 4, "1", 1.0, None, True):
            with self.subTest(value=value):
                self.assertFalse(self.game.turn(value))
        self.assertEqual(self.game.direction, 0)

    def test_fruit_grows_and_updates_score_and_best(self):
        game = self.game
        game.start_pause()
        game.fruit = 144
        game.step()
        self.assertEqual((game.snake[0], len(game.snake), game.score, game.best), (144, 6, 10, 10))
        self.assertEqual(len(game.poisons), 3)
        self.assert_spawns_valid()

    def test_poison_every_second_fruit_caps_at_eight(self):
        game = self.game
        game.rng.choice = lambda cells: cells[-1]
        game.snake = [4, 3, 2, 1, 0]
        game.poisons = [COLS * ROWS - 1, COLS * ROWS - 2, COLS * ROWS - 3]
        game.start_pause()
        for eaten in range(1, 18):
            game.fruit = game.snake[0] + 1
            game.step()
            self.assertEqual(game.state, "playing")
            self.assertEqual(len(game.poisons), min(8, 3 + eaten // 2))
            self.assertEqual(game.score, eaten * 10)
            self.assert_spawns_valid()
        self.assertEqual(game.board().count("p"), 8)

    def test_spawned_poison_does_not_land_in_next_step(self):
        game = self.game
        game.snake = [4, 3, 2, 1, 0]
        game.poisons = []
        game.score = 10
        game.fruit = 5
        picks = iter((100, 6))

        def choose(cells):
            preferred = next(picks)
            return preferred if preferred in cells else cells[0]

        game.rng.choice = choose
        game.start_pause()
        game.step()
        self.assertEqual(game.fruit, 100)
        self.assertNotIn(6, game.poisons)
        self.assert_spawns_valid()

    def test_wall_collisions_do_not_wrap_or_modify_board(self):
        for head, direction in ((21, 0), (COLS * ROWS - 1, 1), (22, 2), (1, 3)):
            with self.subTest(head=head, direction=direction):
                game = Game(random.Random(7))
                game.snake = [head]
                game.poisons = []
                game.direction = direction
                game.fruit = 100
                game.start_pause()
                before = game.board()
                game.step()
                self.assertEqual((game.state, game.reason), ("over", "wall"))
                self.assertEqual(game.board(), before)
                self.assertFalse(game.step())
                self.assertFalse(game.turn((direction + 1) % 4))

    def test_body_collision(self):
        game = self.game
        game.snake = [24, 23, 45, 46, 47]
        game.poisons = []
        game.direction = 1
        game.fruit = 100
        game.start_pause()
        game.step()
        self.assertEqual((game.state, game.reason), ("over", "body"))

    def test_vacating_tail_is_legal(self):
        game = self.game
        game.snake = [24, 23, 45, 46]
        game.poisons = []
        game.direction = 1
        game.fruit = 100
        game.start_pause()
        game.step()
        self.assertEqual(game.state, "playing")
        self.assertEqual(game.snake, [46, 24, 23, 45])

    def test_poison_collision(self):
        game = self.game
        game.poisons = [144]
        game.fruit = 0
        game.start_pause()
        game.step()
        self.assertEqual((game.state, game.reason), ("over", "poison"))
        self.assertEqual(game.score, 0)

    def test_tail_does_not_vacate_when_growing(self):
        game = self.game
        game.snake = [24, 23, 45, 46]
        game.direction = 1
        game.poisons = []
        game.fruit = 46
        game.start_pause()
        game.step()
        self.assertEqual((game.state, game.reason), ("over", "body"))

    def test_reset_preserves_best_and_clears_round(self):
        game = self.game
        game.start_pause()
        game.fruit = 144
        game.step()
        game.poisons = [145]
        game.step()
        game.start_pause()
        self.assertEqual((game.state, game.score, game.best, game.reason), ("ready", 0, 10, ""))
        self.assertEqual(len(game.poisons), 3)
        self.assertEqual(len(game.snake), 5)
        self.assertTrue(game.turn(1))
        game.reset()
        self.assertTrue(game.turn(3))
        self.assert_spawns_valid()

    def test_filling_last_free_cell_wins(self):
        game = self.game
        game.snake = [0] + list(range(2, COLS * ROWS))
        game.poisons = []
        game.fruit = 1
        game.start_pause()
        game.step()
        self.assertEqual((game.state, game.reason), ("won", ""))
        self.assertIsNone(game.fruit)
        self.assertEqual(len(game.snake), COLS * ROWS)
        self.assertEqual(game.score, 10)
        self.assertEqual(game.board().count("."), 0)
        self.assert_packed_round_trip()
        self.assertFalse(game.step())
        game.start_pause()
        self.assertEqual((game.state, game.best), ("ready", 10))

    def test_last_free_fruit_is_not_replaced_with_poison(self):
        game = self.game
        game.snake = [0] + list(range(3, COLS * ROWS))
        game.poisons = []
        game.score = 10
        game.fruit = 1
        game.start_pause()
        game.step()
        self.assertEqual((game.state, game.fruit, game.poisons), ("playing", 2, []))
        game.step()
        self.assertEqual(game.state, "won")

    def test_speed_increases_gently_and_has_a_floor(self):
        game = self.game
        self.assertEqual(game.interval, 0.25)
        game.score = 50
        self.assertAlmostEqual(game.interval, 0.20)
        game.score = 1000
        self.assertEqual(game.interval, 0.14)


if __name__ == "__main__":
    unittest.main()
