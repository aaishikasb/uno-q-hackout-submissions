# Poison Snake

A tiny garden adventure for the UNO Q arcade console: a mint-green snake with rosy cheeks, shiny red berries, spotted purple mushrooms, and a gentle blink. The TFT shows the game at 480×320 with a 22×12 playfield.

Eat berries to grow and earn 10 points. Avoid the fence, your body, and the purple mushrooms. Three mushrooms start in the garden; another grows after every two berries, up to eight. New mushrooms leave your next step clear. Speed increases gradually from four to about seven steps per second.

| Control | Action |
| --- | --- |
| Joystick | Steer; immediate reverse turns are blocked |
| A or joystick press | Start, pause, resume, or try again |
| C | Return to a fresh garden and the start screen |

Your best score lasts for the current app session. Both the joystick and A/B/C module must be connected. Missing controls or communication errors pause the game; center the stick, release the buttons, then press A to resume. Reconnect physical modules with power off.

## Hardware and deployment

This is a standalone App Lab app. It uses the same `Wire1` control reads and **HX8357D** display driver verified by Tic Tac Toe on the connected console. An RM68140 kit needs `ARCADE_TFT_HX8357D = 0` in `sketch/sketch.ino`. Keep the pinned Zephyr 1.0.0 core and the libraries in `sketch.yaml`. Joystick orientation and dead zone are at the top of `python/main.py`.

From this directory, package the app for App Lab:

```sh
zip -r /tmp/uno-q-poison-snake.zip app.yaml python sketch \
  -x '*/__pycache__/*' '*.pyc' '*/.DS_Store'
```

Import that ZIP, select the board, stop any other running app, and run Poison Snake. The first compile may take several minutes. Tic Tac Toe remains installed and can be started again from App Lab.

To update the installed `/home/arduino/ArduinoApps/poison-snake` app, save any board-only edits first, then run from this directory:

```sh
adb -s SERIAL shell -T 'TMPDIR=/tmp arduino-app-cli app stop user:poison-snake'
adb -s SERIAL push app.yaml python sketch /home/arduino/ArduinoApps/poison-snake/
adb -s SERIAL shell -T 'TMPDIR=/tmp arduino-app-cli app start user:poison-snake'
adb -s SERIAL shell -T 'TMPDIR=/tmp arduino-app-cli app logs user:poison-snake --tail 40'
```

Replace `SERIAL` with the value from `adb devices -l`. These commands replace that app's source. Only one App Lab app can run at a time.

## Implementation and checks

Python owns movement, timing, scoring, and collision rules. The 264-cell map is encoded as 132 ASCII characters (two cells per character) to fit the pinned Bridge library's 256-byte RPC limit. The MCU validates frames and redraws only changed cells during play; title and result panels redraw on state changes. A missing heartbeat shows a waiting screen after 1.5 seconds. Slow frames never cause multiple hidden movement steps.

```sh
python3 -B -m unittest discover -s tests -v
```

Tests cover seeded spawning, growth, poison/body/wall collisions, legal movement into a vacating tail, reversal prevention, one turn per step, victory, session best, input validation, button edges, timing, and reconnect behavior. On hardware, check steering in all directions, a berry, a mushroom collision, pause/resume, and restart.

All graphics are drawn with simple TFT shapes; there are no downloaded art assets. Touch, sound, and persistent score storage are not used.
