#include <Arduino.h>
#include <Arduino_RouterBridge.h>
#include <Arduino_Modulino.h>
#include <DIYables_TFT_Touch_Shield.h>

#if !defined(ARDUINO_UNO_Q)
#error "Select Arduino UNO Q."
#endif
// HX8357D was verified on this console; select 0 only for an RM68140 kit.
#ifndef ARCADE_TFT_HX8357D
#define ARCADE_TFT_HX8357D 1
#endif
#if ARCADE_TFT_HX8357D
DIYables_TFT_HX8357D_Shield display;
#else
DIYables_TFT_RM68140_Shield display;
#endif

const uint8_t BUTTONS_ADDRESS = 0x3E;
const uint8_t JOYSTICK_ADDRESS = 0x2C;
ModulinoButtons buttons(BUTTONS_ADDRESS);

const uint16_t BACKGROUND = 0x194A;
const uint16_t FOREGROUND = 0xFF9A;
const uint16_t FIELD = 0xEF75;
const uint16_t FIELD_ALT = 0xE754;
const uint16_t INK = 0x1949;
const uint16_t BORDER = 0x7D32;
const uint16_t SNAKE = 0x56B2;
const uint16_t SNAKE_LIGHT = 0x97D8;
const uint16_t SNAKE_OUTLINE = 0x2389;
const uint16_t BERRY = 0xF32D;
const uint16_t BLUSH = 0xFCB4;
const uint16_t POISON = 0xA3D9;
const uint16_t POISON_LIGHT = 0xE67F;
const uint16_t STEM = 0xFF39;
// Twenty-pixel sprites fit a 22 x 12 garden inside the 480 x 320 TFT.
const int COLS = 22;
const int ROWS = 12;
const int CELL = 20;
const int FIELD_X = 20;
const int FIELD_Y = 56;

String drawnBoard;
int drawnDirection = -1;
int drawnScore = -1;
int drawnBest = -1;
int drawnState = -1;
int drawnControls = -1;
bool drawnBlink = false;
bool waiting = true;
unsigned long lastFrameAt = 0;

bool readPacket(uint8_t address, uint8_t payload[3]) {
  int count = Wire1.requestFrom(address, (uint8_t)4);
  if (count != 4) {
    while (Wire1.available()) Wire1.read();
    return false;
  }
  Wire1.read();  // Modulino pinstrap address precedes the three input bytes.
  for (int i = 0; i < 3; ++i) payload[i] = Wire1.read();
  return true;
}

String readInputs() {
  uint8_t buttonData[3] = {};
  uint8_t stickData[3] = {};
  bool buttonsOk = readPacket(BUTTONS_ADDRESS, buttonData);
  bool joystickOk = readPacket(JOYSTICK_ADDRESS, stickData);
  int pressed = 0;
  if (buttonsOk) {
    for (int i = 0; i < 3; ++i) if (buttonData[i]) pressed |= 1 << i;
    buttons.setLeds(buttonData[0], buttonData[1], buttonData[2]);
  }
  if (joystickOk && stickData[2]) pressed |= 8;
  char json[96];
  snprintf(json, sizeof(json), "{\"connected\":%d,\"buttons\":%d,\"x\":%d,\"y\":%d}",
           (buttonsOk ? 1 : 0) | (joystickOk ? 2 : 0), pressed,
           joystickOk ? 128 - (int)stickData[0] : 0,
           joystickOk ? 128 - (int)stickData[1] : 0);
  return String(json);
}

void textAt(int x, int y, const char* text, int size, uint16_t color, uint16_t background) {
  display.setCursor(x, y);
  display.setTextSize(size);
  display.setTextColor(color, background);
  display.print(text);
}

void centered(int y, const char* text, int size) {
  textAt((480 - (int)strlen(text) * 6 * size) / 2, y, text, size, INK, FOREGROUND);
}

void face(int x, int y, int size, int direction, bool blink, bool dizzy) {
  display.fillRoundRect(x, y, size, size, size / 3, SNAKE);
  display.fillRoundRect(x + 3, y + 2, size - 6, size / 3, size / 6, SNAKE_LIGHT);
  display.drawRoundRect(x, y, size, size, size / 3, SNAKE_OUTLINE);
  int cx = x + size / 2;
  int cy = y + size / 2;
  int dx = direction == 0 ? 1 : direction == 2 ? -1 : 0;
  int dy = direction == 1 ? 1 : direction == 3 ? -1 : 0;
  int radius = size / 7;
  for (int sign = -1; sign <= 1; sign += 2) {
    int ex = cx + dx * (size / 5) + (dy ? sign * (size / 4) : 0);
    int ey = cy + dy * (size / 5) + (dx ? sign * (size / 4) : 0);
    if (dizzy) {
      display.drawLine(ex - radius, ey - radius, ex + radius, ey + radius, INK);
      display.drawLine(ex - radius, ey + radius, ex + radius, ey - radius, INK);
    } else if (blink) {
      display.drawFastHLine(ex - radius, ey, radius * 2 + 1, INK);
    } else {
      display.fillCircle(ex, ey, radius + 1, FOREGROUND);
      display.fillCircle(ex + dx, ey + dy, radius / 2 + 1, INK);
    }
    display.fillCircle(ex - dx * (radius + 3), ey - dy * (radius + 3), size / 12 + 1, BLUSH);
  }
}

void drawCell(int i, char item, int direction, bool blink, bool dizzy) {
  int x = FIELD_X + (i % COLS) * CELL;
  int y = FIELD_Y + (i / COLS) * CELL;
  uint16_t ground = ((i % COLS + i / COLS) & 1) ? FIELD_ALT : FIELD;
  display.fillRect(x, y, CELL, CELL, ground);
  if (item == 'H') {
    face(x + 1, y + 1, 18, direction, blink, dizzy);
  } else if (item == 's') {
    display.fillRoundRect(x + 1, y + 1, 18, 18, 6, SNAKE);
    display.fillRoundRect(x + 4, y + 3, 10, 4, 2, SNAKE_LIGHT);
    display.drawRoundRect(x + 1, y + 1, 18, 18, 6, SNAKE_OUTLINE);
    display.drawFastHLine(x + 6, y + 15, 7, BORDER);
  } else if (item == 'f') {
    display.fillCircle(x + 8, y + 12, 6, BERRY);
    display.fillCircle(x + 13, y + 12, 5, BERRY);
    display.drawLine(x + 10, y + 7, x + 12, y + 3, INK);
    display.fillTriangle(x + 11, y + 6, x + 14, y + 1, x + 18, y + 4, BORDER);
    display.fillCircle(x + 6, y + 10, 2, FOREGROUND);
  } else if (item == 'p') {
    display.fillCircle(x + 10, y + 9, 8, POISON);
    display.fillRect(x + 2, y + 10, 17, 9, ground);
    display.fillRoundRect(x + 7, y + 10, 7, 8, 2, STEM);
    display.fillRect(x + 2, y + 9, 17, 4, POISON);
    display.fillCircle(x + 7, y + 6, 2, POISON_LIGHT);
    display.fillCircle(x + 14, y + 9, 2, POISON_LIGHT);
    display.drawPixel(x + 9, y + 15, INK);
    display.drawPixel(x + 12, y + 15, INK);
  }
}

void drawHeader(int score, int best) {
  display.fillRect(0, 0, 480, 48, BACKGROUND);
  face(12, 12, 26, 0, false, false);
  textAt(48, 10, "POISON SNAKE", 2, FOREGROUND, BACKGROUND);
  textAt(48, 33, "a tiny garden adventure", 1, SNAKE_LIGHT, BACKGROUND);
  char label[12];
  textAt(298, 10, "SCORE", 1, SNAKE_LIGHT, BACKGROUND);
  snprintf(label, sizeof(label), "%04d", score);
  textAt(298, 24, label, 2, FOREGROUND, BACKGROUND);
  textAt(400, 10, "BEST", 1, SNAKE_LIGHT, BACKGROUND);
  snprintf(label, sizeof(label), "%04d", best);
  textAt(400, 24, label, 2, FOREGROUND, BACKGROUND);
}

void drawPanel(int state, int controls, int score) {
  const char* title = "HELLO, LITTLE SNAKE!";
  const char* detail = "Eat red berries. Dodge purple mushrooms.";
  const char* action = "A: LET'S PLAY";
  if ((controls & 3) != 3) {
    title = "GARDEN ON HOLD";
    detail = controls & 1 ? "Joystick missing. Power off to reconnect." : "Buttons missing. Power off to reconnect.";
    action = "CHECK CONTROLS";
  } else if (!(controls & 4)) {
    title = "GET COMFY";
    detail = "Release the buttons and center the stick.";
    action = "READY WHEN YOU ARE";
  } else if (state == 2) {
    title = "TAKING A TINY BREAK";
    detail = "Your berries are safe right here.";
    action = "A: KEEP WIGGLING";
  } else if (state >= 3) {
    title = state == 3 ? "BONK!" : state == 4 ? "A LITTLE TANGLE" : state == 5 ? "SPICY MUSHROOM!" : "GARDEN CHAMPION!";
    detail = state == 3 ? "Mind the garden fence, little friend." : state == 4 ? "Oops, that was your own tail." : state == 5 ? "Purple mushrooms are for admiring." : "You filled the whole garden. Amazing!";
    action = "A: ONE MORE TRY";
  }
  display.fillRoundRect(76, 96, 336, 176, 14, BORDER);
  display.fillRoundRect(72, 92, 336, 176, 14, FOREGROUND);
  centered(108, title, 2);
  for (int i = 0; i < 3; ++i)
    display.fillRoundRect(174 + i * 17, 157, 23, 26, 10, i % 2 ? SNAKE_LIGHT : SNAKE);
  face(225, 142, 42, 0, false, state >= 3 && state <= 5);
  centered(194, detail, 1);
  centered(216, action, 2);
  char footer[48];
  if (state >= 3 && (controls & 7) == 7)
    snprintf(footer, sizeof(footer), "You picked %d berries. C: fresh garden", score / 10);
  else
    snprintf(footer, sizeof(footer), "Stick to steer  /  C: fresh garden");
  centered(248, footer, 1);
}

void showWaiting() {
  display.fillScreen(BACKGROUND);
  drawHeader(0, 0);
  display.fillRoundRect(48, 112, 384, 96, 16, FOREGROUND);
  centered(132, "WAKING UP THE GARDEN", 2);
  centered(172, "Restart the app if this persists.", 1);
  drawnBoard = "";
  waiting = true;
}

bool drawSnake(String packedBoard, int direction, int score, int best, int state, int controls) {
  if (packedBoard.length() != COLS * ROWS / 2 || direction < 0 || direction > 3 ||
      score < 0 || score > 9999 || best < score || best > 9999 ||
      state < 0 || state > 6 || controls < 0 || controls > 7) return false;
  // Two cells per A-Y character keep the frame below Bridge's message limit.
  const char* types = ".sHfp";
  String board;
  board.reserve(COLS * ROWS);
  for (int i = 0; i < COLS * ROWS / 2; ++i) {
    int pair = packedBoard[i] - 'A';
    if (pair < 0 || pair >= 25) return false;
    board += types[pair / 5];
    board += types[pair % 5];
  }
  int heads = 0;
  for (int i = 0; i < COLS * ROWS; ++i) {
    if (board[i] == 'H') ++heads;
  }
  if (heads != 1) return false;
  bool panel = state != 1 || controls != 7;
  bool full = waiting || drawnBoard.length() != COLS * ROWS || state != drawnState ||
              controls != drawnControls || (panel && board != drawnBoard);
  bool blink = state == 1 && millis() % 4200 < 140;
  if (full) {
    display.fillScreen(BACKGROUND);
    display.fillRoundRect(16, 52, 448, 248, 8, BORDER);
    textAt(141, 307, "STICK steer   A pause   C restart", 1, FOREGROUND, BACKGROUND);
  }
  if (full || score != drawnScore || best != drawnBest) drawHeader(score, best);
  if (full || !panel) {
    for (int i = 0; i < COLS * ROWS; ++i) {
      if (full || board[i] != drawnBoard[i] ||
          (board[i] == 'H' && (direction != drawnDirection || blink != drawnBlink)))
        drawCell(i, board[i], direction, blink, state >= 3 && state <= 5);
    }
  }
  if (panel && full) drawPanel(state, controls, score);
  drawnBoard = board;
  drawnDirection = direction;
  drawnScore = score;
  drawnBest = best;
  drawnState = state;
  drawnControls = controls;
  drawnBlink = blink;
  lastFrameAt = millis();
  waiting = false;
  return true;
}

void setup() {
  Modulino.begin(Wire1);
  buttons.begin();
  display.begin();
  display.setRotation(1);
  display.setTextWrap(false);
  showWaiting();
  if (Bridge.begin()) {
    Bridge.provide_safe("read_inputs", readInputs);
    Bridge.provide_safe("draw_snake", drawSnake);
  } else {
    textAt(48, 220, "Bridge failed: restart app", 2, FOREGROUND, BACKGROUND);
  }
}

void loop() {
  if (!waiting && millis() - lastFrameAt > 1500) showWaiting();
  delay(5);
}
