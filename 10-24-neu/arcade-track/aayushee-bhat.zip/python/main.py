import json
import time

from arduino.app_utils import App, Bridge
from game import Game

DEAD_ZONE = 26
INVERT_X = False
INVERT_Y = True

game = Game()
previous_buttons = 0
controls_ready = False
last_step = time.monotonic()


def loop():
    global previous_buttons, controls_ready, last_step
    try:
        response = Bridge.call("read_inputs")
        if not isinstance(response, (str, bytes, bytearray)):
            raise TypeError("Expected JSON text from read_inputs")
        inputs = json.loads(response)
        for key, low, high in (("connected", 0, 3), ("buttons", 0, 15),
                               ("x", -127, 128), ("y", -127, 128)):
            value = inputs[key]
            if type(value) is not int or not low <= value <= high:
                raise ValueError(f"Invalid control reading: {key}")
        connected = inputs["connected"]
        buttons = inputs["buttons"] & ((7 if connected & 1 else 0)
                                       | (8 if connected & 2 else 0))
        x = inputs["x"] * (-1 if INVERT_X else 1)
        y = inputs["y"] * (-1 if INVERT_Y else 1)
        neutral = abs(x) < DEAD_ZONE and abs(y) < DEAD_ZONE
        pressed = buttons & ~previous_buttons
        previous_buttons = buttons
        now = time.monotonic()

        if connected != 3:
            controls_ready = False
            if game.state == "playing":
                game.start_pause()
        elif not controls_ready:
            controls_ready = neutral and not buttons
            last_step = now
        elif pressed & 4:
            game.reset()
            last_step = now
        elif pressed & 9:
            if game.state in ("over", "won"):
                game.reset()
            game.start_pause()
            last_step = now
        elif game.state == "playing":
            if not neutral:
                direction = (0 if x > 0 else 2) if abs(x) >= abs(y) else (1 if y > 0 else 3)
                game.turn(direction)
            if now - last_step >= game.interval:
                game.step()
                # Never catch up missed ticks: a slow frame must not skip past input.
                last_step = now

        state = {"ready": 0, "playing": 1, "paused": 2, "won": 6}.get(game.state)
        if state is None:
            state = {"wall": 3, "body": 4, "poison": 5}[game.reason]
        if Bridge.call("draw_snake", game.packed_board(), game.direction, game.score,
                       game.best, state, connected | (4 if controls_ready else 0)) is not True:
            raise RuntimeError("TFT rejected the snake frame")
    except Exception as error:
        controls_ready = False
        if game.state == "playing":
            game.start_pause()
        print(f"Poison Snake connection/input error: {error}", flush=True)
        time.sleep(1)
        return
    time.sleep(0.03)


print("Poison Snake: stick steers; A/stick starts or pauses; C restarts. Avoid purple mushrooms!", flush=True)
App.run(user_loop=loop)
