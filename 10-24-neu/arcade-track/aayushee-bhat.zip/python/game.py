"""Poison Snake rules, independent of the display and joystick."""

import random


COLS, ROWS = 22, 12
OFFSETS = ((1, 0), (0, 1), (-1, 0), (0, -1))


class Game:
    def __init__(self, rng=None):
        self.rng = rng if rng is not None else random.Random()
        self.best = 0
        self.reset()

    def reset(self):
        head = (ROWS // 2) * COLS + COLS // 2
        self.snake = [head - i for i in range(5)]
        self.direction = 0
        self._turned = False
        self.poisons = []
        self.score = 0
        self.state = "ready"
        self.reason = ""
        self.fruit = None
        self.fruit = self._choose_free()
        for _ in range(3):
            self.poisons.append(self._choose_free(exclude=range(head + 1, head + 4)))

    @property
    def interval(self):
        return max(0.14, 0.25 - self.score * 0.001)

    def start_pause(self):
        if self.state in ("over", "won"):
            self.reset()
        elif self.state == "playing":
            self.state = "paused"
        else:
            self.state = "playing"

    def turn(self, direction):
        if (type(direction) is not int or direction not in range(4)
                or self.state not in ("ready", "playing")):
            return False
        if direction == self.direction:
            return True
        if self._turned or direction == (self.direction + 2) % 4:
            return False
        self.direction = direction
        self._turned = True
        return True

    def _next(self):
        dx, dy = OFFSETS[self.direction]
        x = self.snake[0] % COLS + dx
        y = self.snake[0] // COLS + dy
        return y * COLS + x if 0 <= x < COLS and 0 <= y < ROWS else None

    def _choose_free(self, exclude=()):
        occupied = set(self.snake) | set(self.poisons) | {self.fruit}
        occupied.update(exclude)
        cells = [cell for cell in range(COLS * ROWS) if cell not in occupied]
        return self.rng.choice(cells) if cells else None

    def step(self):
        if self.state != "playing":
            return False
        self._turned = False
        cell = self._next()
        grows = cell == self.fruit
        if cell is None:
            self.reason = "wall"
        elif cell in self.poisons:
            self.reason = "poison"
        elif cell in (self.snake if grows else self.snake[:-1]):
            self.reason = "body"
        if self.reason:
            self.state = "over"
            return True
        self.snake.insert(0, cell)
        if not grows:
            self.snake.pop()
            return True
        self.score += 10
        self.best = max(self.best, self.score)
        self.fruit = None
        self.fruit = self._choose_free()
        if self.fruit is None:
            self.state = "won"
        elif self.score % 20 == 0 and len(self.poisons) < 8:
            # Leave the next step clear so a newly spawned hazard is avoidable.
            poison = self._choose_free(exclude=(self._next(),))
            if poison is not None:
                self.poisons.append(poison)
        return True

    def board(self):
        cells = ["."] * (COLS * ROWS)
        for cell in self.poisons:
            cells[cell] = "p"
        if self.fruit is not None:
            cells[self.fruit] = "f"
        for cell in self.snake[1:]:
            cells[cell] = "s"
        cells[self.snake[0]] = "H"
        return "".join(cells)

    def packed_board(self):
        # Two cells per ASCII byte keep the frame within Bridge's message limit.
        board, types = self.board(), ".sHfp"
        return "".join(chr(65 + types.index(board[i]) * 5 + types.index(board[i + 1]))
                       for i in range(0, len(board), 2))
